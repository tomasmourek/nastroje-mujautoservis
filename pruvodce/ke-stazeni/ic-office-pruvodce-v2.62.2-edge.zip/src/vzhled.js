// Vzhled podle grafických přehledů IC Office. Na hostitelských webech se barvy
// aplikují pouze uvnitř Shadow DOM průvodce.
(() => {
  'use strict';
  if (globalThis.ICOP2_VZHLED) return;

  const svetly = `
    --ic-scheme: light;
    --ic-plane: #f4f4f1;
    --ic-surface: #fff;
    --ic-surface-2: #f7f7f4;
    --ic-ink: #1b1c17;
    --ic-ink-2: #56574f;
    --ic-hair: #e6e5dd;
    --ic-hair-2: #d4d3c9;
    --ic-guide-red: #c71938;
    --ic-guide-hover: #a9132e;
    --ic-band: #496949;
    --ic-band-ink: #fff;
    --ic-primary: #496949;
    --ic-primary-hover: #385638;
    --ic-on-primary: #fff;
    --ic-accent: #2a78d6;
    --ic-accent-ink: #17568f;
    --ic-accent-bg: #e8f0fc;
    --ic-good: #24633d;
    --ic-good-bg: #e4f4eb;
    --ic-warn: #805107;
    --ic-warn-bg: #fbf0da;
    --ic-crit: #a62b2b;
    --ic-crit-bg: #fae6e6;
    --ic-shadow: 0 1px 2px rgba(27,28,23,.05), 0 3px 10px rgba(27,28,23,.05);`;
  const tmavy = `
    --ic-scheme: dark;
    --ic-plane: #1c201c;
    --ic-surface: #272c27;
    --ic-surface-2: #30372f;
    --ic-ink: #f2f3eb;
    --ic-ink-2: #c1c6ba;
    --ic-hair: #454c42;
    --ic-hair-2: #66705f;
    --ic-guide-red: #d22946;
    --ic-guide-hover: #b51c38;
    --ic-band: #364f3a;
    --ic-band-ink: #f2f7ef;
    --ic-primary: #a7c9a5;
    --ic-primary-hover: #bdd9b8;
    --ic-on-primary: #182c1c;
    --ic-accent: #84b8f1;
    --ic-accent-ink: #afd1f9;
    --ic-accent-bg: #26394d;
    --ic-good: #9dd4b1;
    --ic-good-bg: #283e30;
    --ic-warn: #f0cd87;
    --ic-warn-bg: #443823;
    --ic-crit: #f6b4b1;
    --ic-crit-bg: #4c3030;
    --ic-shadow: 0 1px 2px rgba(0,0,0,.18), 0 3px 10px rgba(0,0,0,.16);`;

  const css = `
    :root, :host {
      --ic-font: "Open Sans", Arial, Helvetica, sans-serif;
      --ic-radius: 10px;
      --ic-control-radius: 8px;
      ${svetly}
      color-scheme: var(--ic-scheme);
    }
    @media (prefers-color-scheme: dark) {
      :root, :host { ${tmavy} }
    }
    :root[data-icop-motiv="light"], :host([data-icop-motiv="light"]) { ${svetly} }
    :root[data-icop-motiv="dark"], :host([data-icop-motiv="dark"]) { ${tmavy} }
    .icop-titul { display: flex; align-items: center; flex-wrap: wrap; gap: 6px 12px; min-width: 0; }
    .icop-logo {
      flex: none; display: block; box-sizing: border-box; width: 132px; height: auto;
      padding: 5px 8px; border-radius: 4px; background-color: #fff;
      forced-color-adjust: none;
    }
    .icop-znak {
      display: inline-grid; place-items: center; flex: none; box-sizing: border-box;
      width: 25px; height: 25px; border: 1px solid #fff; border-radius: 50%;
      background: var(--ic-guide-red); color: #fff; font: 800 16px/1 var(--ic-font);
      pointer-events: none;
    }
    .icop-znak::before { content: "?"; }`;

  function motiv(el) {
    if (!el) return;
    for (const atribut of ['data-theme', 'data-bs-theme']) {
      const hodnota = el.getAttribute(atribut);
      if (hodnota === 'light' || hodnota === 'dark') return hodnota;
    }
  }

  function pripoj(host) {
    // Stejná reakce na změnu volby i v prohlížečích bez :host-context().
    function obnov() {
      const volba = motiv(document.body) || motiv(document.documentElement);
      if (volba) host.setAttribute('data-icop-motiv', volba);
      else host.removeAttribute('data-icop-motiv');
    }
    const pozorovatel = new MutationObserver(obnov);
    const nastaveni = { attributes: true, attributeFilter: ['data-theme', 'data-bs-theme'] };
    pozorovatel.observe(document.documentElement, nastaveni);
    if (document.body) pozorovatel.observe(document.body, nastaveni);
    obnov();
    return () => pozorovatel.disconnect();
  }

  globalThis.ICOP2_VZHLED = Object.freeze({ css, pripoj });
  if (document.currentScript?.hasAttribute('data-icop-stranka')) {
    const styl = document.createElement('style');
    styl.textContent = css;
    document.head.append(styl);
    if (document.body) pripoj(document.documentElement);
    else {
      const pocatecniMotiv = motiv(document.documentElement);
      if (pocatecniMotiv) document.documentElement.setAttribute('data-icop-motiv', pocatecniMotiv);
      document.addEventListener('DOMContentLoaded', () => pripoj(document.documentElement), { once: true });
    }
  }
})();
