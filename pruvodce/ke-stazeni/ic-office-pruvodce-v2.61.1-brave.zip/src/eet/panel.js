(() => {
  'use strict';
  const povolena = () => globalThis.ICOP2_EET_WEB?.povolena(location.href) === true;
  if (window !== window.top || !povolena()) return false;
  if (globalThis.ICOP2_EET_PANEL?.otevri()) return true;

  const { vytvor, tlacitko, pridejStyl, zobraz } = globalThis.ICOP2_EET_PRUVODCE;
  const host = document.createElement('div');
  host.id = 'icop2-eet-panel';
  host.lang = 'cs';
  const stin = host.attachShadow({ mode: 'closed' });
  const css = `:host { all: initial !important; color-scheme: light dark !important; position: fixed !important; bottom: max(10px, env(safe-area-inset-bottom)) !important; right: max(10px, env(safe-area-inset-right)) !important; z-index: 2147483647 !important; width: max-content !important; max-width: calc(100vw - 20px) !important; }
* { box-sizing: border-box; }
[hidden] { display: none !important; }
aside, .roleta { font: 15px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif; color: #202733; background: #fff; border: 1px solid #a9b3c0; border-top: 3px solid #b51d2b; box-shadow: 0 6px 28px #18233038; border-radius: 10px; }
aside { display: flex; flex-direction: column; width: min(26rem,calc(100vw - 20px)); max-height: min(74vh,38rem); max-height: min(74dvh,38rem); overflow: hidden; }
header { display: flex; align-items: center; gap: 4px; flex: none; padding: 3px 9px; border-bottom: 1px solid #ccd3db; flex-wrap: wrap; }
header strong { margin-right: auto; font-size: 13px; }
header button, .roleta { cursor: pointer; }
header button { font: inherit; font-size: 13px; border: 0; background: transparent; color: inherit; padding: 6px; min-height: 36px; text-decoration: underline; text-underline-offset: 2px; }
.roleta { padding: 8px 15px; min-height: 44px; font-weight: 650; }
.list { padding: 12px 16px; overflow-y: auto; overscroll-behavior: contain; }
.list.eet-kroky { font-size: 15px; }
.list.eet-kroky h2 { font-size: 1.28em; }
:focus-visible { outline: 3px solid #2677b8; outline-offset: 1px; }
@media (prefers-color-scheme: dark) { aside, .roleta { color: #f0f3f7; background: #232932; border-color: #657384; border-top-color: #ff7e89; } header { border-color: #4b5561; } }
@media (max-width: 480px) { aside { max-height: 59vh; max-height: 59dvh; } .list { padding: 10px 12px; } }`;
  pridejStyl(stin, css);
  const panel = vytvor('aside');
  panel.setAttribute('aria-label', 'IC Office Průvodce – aktivace EET');
  const lista = vytvor('header');
  const nazev = vytvor('strong', 'IC Office Průvodce · EET');
  const sbalit = tlacitko('Sbalit', 'sbalit');
  sbalit.setAttribute('aria-expanded', 'true');
  const zavrit = tlacitko('Zavřít', 'zavrit');
  const rozbalit = tlacitko('Otevřít návod EET', 'rozbalit', 'roleta');
  rozbalit.setAttribute('aria-expanded', 'false');
  rozbalit.hidden = true;
  const obsah = vytvor('div', '', 'list');
  lista.append(nazev, sbalit, zavrit);
  panel.append(lista, obsah);
  stin.append(panel, rozbalit);
  document.documentElement.append(host);
  let aktivni = true;
  let kontrolaUrl;
  let ovladani;
  function zrus() {
    if (!aktivni) return;
    aktivni = false;
    clearInterval(kontrolaUrl);
    window.removeEventListener('popstate', over);
    window.removeEventListener('hashchange', over);
    window.removeEventListener('pagehide', zrus);
    document.removeEventListener('visibilitychange', sleduj);
    ovladani?.zrus();
    host.remove();
    delete globalThis.ICOP2_EET_PANEL;
  }
  function over() {
    if (aktivni && (!povolena() || !host.isConnected)) zrus();
    return aktivni;
  }
  function sleduj() {
    clearInterval(kontrolaUrl);
    if (over() && !document.hidden) kontrolaUrl = setInterval(over, 500);
  }
  function otevri() {
    if (!over()) return false;
    panel.hidden = false;
    rozbalit.hidden = true;
    return true;
  }
  stin.addEventListener('click', (event) => {
    if (!event.isTrusted || !over()) {
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    if (event.target === zavrit) zrus();
    else if (event.target === sbalit) {
      panel.hidden = true;
      rozbalit.hidden = false;
      rozbalit.focus({ preventScroll: true });
    } else if (event.target === rozbalit) {
      otevri();
      sbalit.focus({ preventScroll: true });
    }
  }, true);
  stin.addEventListener('keydown', (event) => {
    if (event.isTrusted && event.key === 'Escape' && over() && !panel.hidden) {
      event.stopPropagation();
      panel.hidden = true;
      rozbalit.hidden = false;
      rozbalit.focus({ preventScroll: true });
    }
  });
  // Popstate nezachytí pushState měnící trasu v jedné stránce. Na bankovní
  // ani jiné nepovolené cestě panel nesmí zůstat po navigaci nebo přijmout akci.
  window.addEventListener('popstate', over);
  window.addEventListener('hashchange', over);
  window.addEventListener('pagehide', zrus);
  document.addEventListener('visibilitychange', sleduj);
  sleduj();
  ovladani = zobraz(obsah, { plati: over, nadpis: 'h2' });
  globalThis.ICOP2_EET_PANEL = Object.freeze({ otevri });
  return true;
})();
