(() => {
  'use strict';
  const obal = document.getElementById('eet-pruvodce');
  const seznam = document.querySelector('#prehled ol');
  let ovladani;
  function spust() {
    ovladani?.zrus();
    if (!globalThis.ICOP2_EET_KROKY?.length || !globalThis.ICOP2_EET_PRUVODCE) {
      obal.textContent = 'Kroky návodu se nepodařilo načíst. Znovu otevřete doplněk.';
      return;
    }
    ovladani = globalThis.ICOP2_EET_PRUVODCE.zobraz(obal);
    seznam.replaceChildren();
    globalThis.ICOP2_EET_KROKY.forEach((krok, index) => {
      const polozka = document.createElement('li');
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = krok.titulek;
      btn.addEventListener('click', () => {
        ovladani.ukaz(index);
        obal.scrollIntoView({ block: 'start' });
      });
      polozka.append(btn);
      seznam.append(polozka);
    });
  }
  spust();
  window.addEventListener('pageshow', (e) => { if (e.persisted) spust(); });
})();
