// Dočasné oprávnění aktivní karty používá jen panel vyvolaný uživatelem.
(() => {
  function povolena(adresa) {
    let url;
    try { url = new URL(adresa); } catch { return false; }
    if (url.username || url.password) return false;
    switch (url.origin) {
      case 'https://ic-office.eu':
        return /^\/(?:settings|help)\/eet\/?$/.test(url.pathname);
      case 'https://mojedane.gov.cz':
      case 'https://adisspr.mfcr.cz':
        return /^\/pmd(?:\/|$)/.test(url.pathname);
      case 'https://eet.gov.cz':
        return url.pathname.startsWith('/cs/');
      case 'https://podpora.mojedane.gov.cz':
        return /^\/cs\/seznam-okruhu\/elektronicka-evidence-trzeb-2-0(?:\/|$)/.test(url.pathname);
      default:
        return false;
    }
  }
  globalThis.ICOP2_EET_WEB = Object.freeze({ povolena });
})();
