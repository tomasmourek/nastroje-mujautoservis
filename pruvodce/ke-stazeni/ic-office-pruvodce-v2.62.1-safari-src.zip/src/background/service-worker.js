// IC Office Průvodce — service worker
//
// Ve výchozím stavu nedělá NIC a neprovádí žádnou síťovou komunikaci.
//
// Jedinou výjimkou je odeslání žádosti o pomoc na hotline, a to jen tehdy,
// když je v src/content/tours.js vyplněný `PODPORA.endpoint`. Dokud je prázdný,
// obsluha níže se nikdy nespustí — content skript místo toho otevře
// předvyplněný e-mail. Odesílání běží tady (ne v content skriptu), aby bylo
// oprávnění k cizí adrese vidět v manifestu.
//
// Až endpoint budete mít, přidejte jeho původ do "host_permissions"
// v manifest.json — jinak fetch skončí chybou a průvodce se vrátí k e-mailu.
// Chromium používá service worker, Firefox a Safari načítají stejné soubory jako background.scripts.
if (typeof importScripts === 'function') {
  importScripts(chrome.runtime.getURL('src/eet/web.js'), chrome.runtime.getURL('src/eet/kroky.js'));
}
chrome.runtime.onInstalled.addListener(() => {
  // nic — veškerá logika běží v content skriptu, data v chrome.storage.local
});

// Stažení obsahu ze serveru (viz FORMAT.md §12). Vypnuté, dokud není v
// `tours.js` vyplněná `obsahUrl` a její původ v "host_permissions".
//
// Stahují se JEN DATA. Vzdálený kód je v Manifestu V3 zakázaný a v Chrome Web
// Store důvod k zamítnutí — formát obsahu je proto deklarativní.
//
// Stažený obsah se ukládá do cache a průvodce ji použije při dalším načtení
// stránky. Bez cache by průvodce nefungoval offline nebo když server mlčí.
const OBSAH_KEY = 'icop2:obsah';
const OBSAH_META = 'icop2:obsahMeta';
const OBSAH_FORMAT = 1;
const OBSAH_INTERVAL = 60 * 60 * 1000;   // nejvýš jednou za hodinu

function obsahPouzitelny(d) {
  return !!(d && typeof d === 'object' && d.format === OBSAH_FORMAT
    && Array.isArray(d.scenarios) && d.scenarios.length);
}

async function stahniObsah(url, vynutit) {
  if (!url) return { ok: false, duvod: 'adresa obsahu není nastavená' };
  const ulozeno = await chrome.storage.local.get([OBSAH_META]);
  const meta = ulozeno[OBSAH_META] || {};
  if (!vynutit && meta.kdy && Date.now() - meta.kdy < OBSAH_INTERVAL) {
    return { ok: true, zmena: false, duvod: 'čerstvé' };
  }
  const hlavicky = {};
  if (meta.etag) hlavicky['If-None-Match'] = meta.etag;
  const r = await fetch(url, { headers: hlavicky, cache: 'no-cache' });
  if (r.status === 304) {
    await chrome.storage.local.set({ [OBSAH_META]: Object.assign({}, meta, { kdy: Date.now() }) });
    return { ok: true, zmena: false, duvod: 'beze změny' };
  }
  if (!r.ok) return { ok: false, duvod: 'server odpověděl ' + r.status };
  const d = await r.json();
  if (!obsahPouzitelny(d)) return { ok: false, duvod: 'stažený obsah neodpovídá formátu ' + OBSAH_FORMAT };
  await chrome.storage.local.set({
    [OBSAH_KEY]: d,
    [OBSAH_META]: { kdy: Date.now(), etag: r.headers.get('ETag') || '', verze: d.version || '' }
  });
  return { ok: true, zmena: true, verze: d.version || '' };
}

// Každá živá prezentace patří jediné kartě. Pozadí zná skutečné ID karty
// i při duplikování stránky, kdy prohlížeč může zkopírovat sessionStorage.
const akcePrezentace = new Set([
  'demoBehStart', 'demoBehOver', 'demoBehSmaz',
  'demoTelefonNastav', 'demoTelefonCti', 'demoTelefonSmaz'
]);
const uuidBehu = /^[\da-f]{8}(?:-[\da-f]{4}){3}-[\da-f]{12}$/i;
const telefonPrezentace = /^\+?[1-9]\d{6,14}$/;
const docasneBehy = new Map();
let poradiBehu = Promise.resolve();

function vPoradiBehu(akce) {
  const vysledek = poradiBehu.then(akce);
  poradiBehu = vysledek.catch(() => {});
  return vysledek;
}

async function ulozBeh(klic, stav) {
  // storage.session je soukromá paměť rozšíření. Starší prostředí může
  // zapomenout běh při uspání pozadí, což automatické úkony bezpečně zastaví.
  const pamet = chrome.storage.session;
  if (stav) {
    if (pamet) await pamet.set({ [klic]: stav });
    else docasneBehy.set(klic, stav);
  } else {
    if (pamet) await pamet.remove(klic);
    else docasneBehy.delete(klic);
  }
}

function klicKarty(tabId) {
  return 'icop2:prezentace:' + tabId;
}

async function obsluzPrezentaci(msg, sender) {
  const tabId = sender.tab?.id;
  if (!Number.isInteger(tabId) || tabId < 0 || sender.frameId !== 0 ||
      !sender.url?.startsWith('https://ic-office.eu/') ||
      typeof msg.beh !== 'string' || !uuidBehu.test(msg.beh)) return { ok: false };

  const klic = klicKarty(tabId);
  const pamet = chrome.storage.session;
  const stav = pamet ? (await pamet.get(klic))[klic] : docasneBehy.get(klic);
  const plati = stav?.beh === msg.beh;
  if (msg.action === 'demoBehStart') {
    if (!plati) await ulozBeh(klic, { beh: msg.beh });
    return { ok: true };
  }
  if (msg.action === 'demoBehOver') return { ok: true, plati };
  if (!plati) return { ok: false, telefon: '' };

  switch (msg.action) {
    case 'demoBehSmaz':
      await ulozBeh(klic, null);
      break;
    case 'demoTelefonNastav':
      if (typeof msg.telefon !== 'string' || !telefonPrezentace.test(msg.telefon)) return { ok: false };
      await ulozBeh(klic, { beh: msg.beh, telefon: msg.telefon });
      break;
    case 'demoTelefonCti':
      return { ok: true, telefon: stav.telefon || '' };
    case 'demoTelefonSmaz':
      await ulozBeh(klic, { beh: msg.beh });
      break;
  }
  return { ok: true };
}

function zapomenKartu(tabId) {
  vPoradiBehu(() => ulozBeh(klicKarty(tabId), null)).catch(() => {});
}
chrome.tabs.onRemoved.addListener(tabId => {
  zapomenKartu(tabId);
  veFronteEet(() => odstranPredani(prefixPredani + tabId)).catch(() => {});
});
chrome.tabs.onUpdated.addListener((tabId, zmena) => {
  if (zmena.url && !zmena.url.startsWith('https://ic-office.eu/')) zapomenKartu(tabId);
});

const KLIC_EET = 'icop2:eet-krok';
let frontaEet = Promise.resolve();

// Předání identifikátorů do jedné nově otevřené karty. Zpráva z příjemce
// prochází stejnou frontou jako založení, i když je stránka už v mezipaměti.
const cilPredani = 'https://ic-office.eu/settings/eet';
const prefixPredani = 'icop2:eet-predani:';
const dobaPredani = 15 * 60 * 1000;
const akcePredani = new Set(['eetPredat', 'eetJePredani', 'eetPrevzit', 'eetUkoncitPredani']);
const nahradniPredani = new Map();
const predaniApi = globalThis.browser || chrome;

function veFronteEet(akce) {
  const vysledek = frontaEet.then(akce);
  frontaEet = vysledek.catch(() => {});
  return vysledek;
}

async function odstranPredani(klic) {
  const pamet = predaniApi.storage.session;
  if (pamet) {
    try { await pamet.remove(klic); }
    catch { await pamet.set({ [klic]: null }); }
  } else nahradniPredani.delete(klic);
  await predaniApi.alarms?.clear(klic).catch(() => {});
}

async function otevriPredani(msg, sender) {
  if (sender.url !== chrome.runtime.getURL('src/eet/pruvodce.html') &&
      !globalThis.ICOP2_EET_WEB.povolena(sender.url)) return { ok: false };
  if (typeof msg.provozovna !== 'string' || typeof msg.pokladna !== 'string') return { ok: false };
  const provozovna = msg.provozovna.trim();
  const pokladna = msg.pokladna.trim();
  if (!/^\d{0,128}$/.test(provozovna) || pokladna.length > 20 || /[\u0000-\u001f\u007f-\u009f]/u.test(pokladna)) return { ok: false };

  const volby = { url: cilPredani };
  if (Number.isInteger(sender.tab.windowId)) volby.windowId = sender.tab.windowId;
  const karta = await predaniApi.tabs.create(volby);
  if (!provozovna && !pokladna) return { ok: true };
  if (!Number.isInteger(karta?.id)) return { ok: true, prenosSelhal: true };
  const klic = prefixPredani + karta.id;
  const stav = { provozovna, pokladna, predaniId: crypto.randomUUID(), do: Date.now() + dobaPredani };
  try {
    await predaniApi.alarms.create(klic, { when: stav.do });
    const pamet = predaniApi.storage.session;
    if (pamet) await pamet.set({ [klic]: stav });
    else nahradniPredani.set(klic, stav);
  } catch {
    await odstranPredani(klic).catch(() => {});
    return { ok: true, prenosSelhal: true };
  }
  return { ok: true };
}

async function obsluzPredani(msg, sender) {
  if (sender.id !== chrome.runtime.id || sender.frameId !== 0 || !Number.isInteger(sender.tab?.id)) return { ok: false };
  if (msg.action === 'eetPredat') return otevriPredani(msg, sender);
  const url = new URL(sender.url);
  if (!globalThis.ICOP2_EET_WEB.povolena(url.href) || url.origin !== 'https://ic-office.eu' ||
      !/^\/settings\/eet\/?$/.test(url.pathname)) return { ok: false };
  const klic = prefixPredani + sender.tab.id;
  const pamet = predaniApi.storage.session;
  const stav = pamet ? (await pamet.get(klic))[klic] : nahradniPredani.get(klic);
  const ukoncuje = msg.action === 'eetUkoncitPredani';
  if (!stav) return { ok: ukoncuje };
  if (Date.now() >= stav.do) {
    await odstranPredani(klic);
    return { ok: ukoncuje };
  }
  if (msg.action === 'eetJePredani') return { ok: true };
  if (msg.action === 'eetUkoncitPredani') {
    if (msg.predaniId !== stav.predaniId) return { ok: false };
    await odstranPredani(klic);
    return { ok: true };
  }
  return { ok: true, provozovna: stav.provozovna, pokladna: stav.pokladna, predaniId: stav.predaniId, vyprsi: stav.do };
}

predaniApi.alarms?.onAlarm.addListener(({ name }) => {
  if (name.startsWith(prefixPredani)) veFronteEet(() => odstranPredani(name)).catch(() => {});
});

async function zmenPostupEet(msg, sender) {
  if (sender.id !== chrome.runtime.id || (sender.frameId != null && sender.frameId !== 0)) return { ok: false };
  if (msg.action === 'eetSmazPostup') {
    if (sender.url !== chrome.runtime.getURL('src/popup/popup.html')) return { ok: false };
    await chrome.storage.local.remove(KLIC_EET);
    return { ok: true };
  }
  const celaStranka = sender.url === chrome.runtime.getURL('src/eet/pruvodce.html');
  const panel = Number.isInteger(sender.tab?.id) && sender.tab.id >= 0 && sender.frameId === 0
    && globalThis.ICOP2_EET_WEB.povolena(sender.url);
  if (!celaStranka && !panel) return { ok: false };

  const kroky = globalThis.ICOP2_EET_KROKY.map(krok => krok.id);
  const posledni = kroky.length;
  kroky.push('hotovo');
  const z = kroky.indexOf(msg.ocekavany);
  const na = kroky.indexOf(msg.cil);
  if (z < 0 || na < 0) return { ok: false };
  const povoleno = (msg.volba === 'dalsi' && na === z + 1)
    || (msg.volba === 'navazat' && celaStranka && z < na && na < posledni)
    || (msg.volba === 'znovu' && z === posledni && na === 0);
  if (!povoleno) return { ok: false };

  // Čtení, porovnání i zápis probíhají uvnitř jedné úlohy sdílené všemi kartami.
  const ulozeny = (await chrome.storage.local.get(KLIC_EET))[KLIC_EET];
  const soucasny = kroky.includes(ulozeny) ? ulozeny : kroky[0];
  if (soucasny !== msg.ocekavany) return { ok: true, krok: soucasny, soubeh: true };
  await chrome.storage.local.set({ [KLIC_EET]: msg.cil });
  return { ok: true, krok: msg.cil };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.ns === 'icop2' && (akcePredani.has(msg.action) || msg.action === 'eetPotvrdKrok' || msg.action === 'eetSmazPostup')) {
    const zapis = veFronteEet(() => akcePredani.has(msg.action) ? obsluzPredani(msg, sender) : zmenPostupEet(msg, sender));
    zapis.then(sendResponse, () => sendResponse({ ok: false }));
    return true;
  }
  if (msg?.ns === 'icop2' && msg.action === 'otevriEetNavod') {
    if (!Number.isInteger(sender.tab?.id) || sender.frameId !== 0 || !sender.url?.startsWith('https://ic-office.eu/')) {
      sendResponse({ ok: false });
      return;
    }
    chrome.tabs.create({ url: chrome.runtime.getURL('src/eet/pruvodce.html') }, () => {
      sendResponse({ ok: !chrome.runtime.lastError });
    });
    return true;
  }
  if (msg?.ns === 'icop2' && akcePrezentace.has(msg.action)) {
    vPoradiBehu(() => obsluzPrezentaci(msg, sender))
      .then(sendResponse, () => sendResponse({ ok: false }));
    return true;
  }
  if (msg && msg.ns === 'icop2' && msg.action === 'obsah') {
    stahniObsah(msg.url, !!msg.vynutit)
      .then((v) => sendResponse(v))
      .catch((e) => sendResponse({ ok: false, duvod: String(e && e.message) }));
    return true;
  }
  if (!msg || msg.ns !== 'icop2' || msg.action !== 'sos') return;
  if (!msg.endpoint) { sendResponse({ ok: false, duvod: 'endpoint není nastaven' }); return true; }
  fetch(msg.endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(msg.payload || {})
  })
    .then((r) => sendResponse({ ok: r.ok, status: r.status }))
    .catch((e) => sendResponse({ ok: false, duvod: String(e && e.message) }));
  return true;   // odpověď přijde asynchronně
});
