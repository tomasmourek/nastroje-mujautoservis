/* Cvičná zakázka má vlastní DOM a její údaje žijí jen po dobu otevření. */
(() => {
  'use strict';

  const kroky = [
    {
      titul: 'Vyberte zákazníka', popis: 'Zákazník přivezl auto do servisu. Vyberte, na koho bude zakázka vedená.',
      pole: 'Zákazník', moznosti: ['Eva Ukázková', 'Adam Cvičný']
    },
    {
      titul: 'Přiřaďte vozidlo', popis: 'K zákazníkovi přiřaďte vůz. V zakázce pak uvidíte, kterého auta se práce týká.',
      pole: 'Vozidlo', moznosti: ['Škoda Fabia · CVIČNÉ A', 'Ford Focus · CVIČNÉ B']
    },
    {
      titul: 'Zapište požadovanou práci', popis: 'Vyberte, co zákazník potřebuje. Mechanik tento požadavek uvidí v zakázce.',
      pole: 'Požadavek', moznosti: ['Výměna oleje a filtru', 'Kontrola brzd']
    }
  ];
  const styl = `<style>
    .prvni { padding: 16px; color: var(--ic-ink); background: var(--ic-surface); line-height: 1.5; }
    .prvni p { margin: 0 0 12px; color: var(--ic-ink-2); }
    .prvni h3 { margin: 0 0 6px; font-size: 16px; font-weight: 700; line-height: 1.4; color: inherit; }
    .prvni small { display: block; margin-bottom: 4px; font-size: 12px; color: var(--ic-ink-2); font-variant-numeric: tabular-nums; }
    .prvni progress { display: block; appearance: none; width: 100%; height: 5px; margin: 0 0 16px; background: var(--ic-plane); border: 0; border-radius: 3px; overflow: hidden; }
    .prvni progress::-webkit-progress-bar { background: var(--ic-plane); }
    .prvni progress::-webkit-progress-value { background: var(--ic-primary); }
    .prvni progress::-moz-progress-bar { background: var(--ic-primary); }
    .prvni fieldset { margin: 16px 0; padding: 0; border: 0; min-width: 0; }
    .prvni legend { padding: 0 0 6px; font-weight: 700; font-size: 14px; }
    .prvni label { display: flex; gap: 10px; align-items: center; padding: 8px 12px; min-height: 40px; border: 1px solid var(--ic-hair); border-radius: var(--ic-control-radius); cursor: pointer; }
    .prvni label + label { margin-top: 6px; }
    .prvni label:hover { background: var(--ic-surface-2); }
    .prvni label:has(input:checked) { background: var(--ic-accent-bg); border-color: var(--ic-accent); color: var(--ic-accent-ink); }
    .prvni input[type="radio"] { margin: 0; accent-color: var(--ic-accent-ink); }
    .prvni dl { display: grid; grid-template-columns: auto 1fr; gap: 4px 12px; margin: 12px 0; padding: 10px 12px; background: var(--ic-surface-2); border: 1px solid var(--ic-hair); border-radius: var(--ic-control-radius); }
    .prvni dt { font-size: 13px; color: var(--ic-ink-2); }
    .prvni dd { min-width: 0; overflow-wrap: anywhere; margin: 0; font-weight: 600; }
    .prvni .prvni-akce { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-top: 12px; }
    .prvni button { min-height: 38px; white-space: normal; }
    .prvni .nenapadny { background: transparent; border: 0; padding: 6px 4px; color: var(--ic-accent-ink); text-decoration: underline; text-underline-offset: 2px; cursor: pointer; font: inherit; }
    .prvni-nabidka p { color: var(--ic-ink); }
    .wlist > .prvni-nabidka { padding: 8px 0 14px; }
    @media (max-width: 480px), (max-height: 620px) {
      .welcome.prvni-menu { overflow-y: auto; }
      .welcome.prvni-menu > * { flex-shrink: 0; }
      .welcome.prvni-menu .wlist { overflow: visible; }
      .welcome.prvni-menu .whead { position: sticky; top: 0; z-index: 1; }
    }
  </style>`;

  function nabidkaHtml(predKontaktem, beziPrezentace) {
    const rucne = predKontaktem
      ? '<button type="button" class="nenapadny" data-a="prvni-rucne">Přejít na krokové návody</button>' : '';
    return `<div class="prvni prvni-nabidka">
      <p>${beziPrezentace ? 'Cvičnou zakázku si můžete projít po ukončení běžící prezentace.' : 'Za dvě minuty si vyzkoušíte příjem auta na fiktivních údajích.' + (predKontaktem ? ' Zákaznické číslo můžete doplnit později.' : '')}</p>
      <div class="prvni-akce"><button type="button" class="b main" data-a="prvni-start" ${beziPrezentace ? 'disabled' : ''}>Ukázka první zakázky</button>${rucne}</div>
    </div>`;
  }

  function spustit(panel, { servis, menu, dostupnyScenar }) {
    let index = 0;
    let vyber = [0, 0, 0];
    let casovac = null;
    let bezi = false;
    let ukoncena = false;
    function zastavit() {
      clearTimeout(casovac);
      casovac = null;
      bezi = false;
    }
    function naplanovat() {
      clearTimeout(casovac);
      // Tři čitelné zastávky, závěr čeká na rozhodnutí člověka.
      if (bezi && !ukoncena) casovac = setTimeout(() => prejit(index + 1), 35000);
    }
    function prejit(novy) {
      index = novy;
      if (index === kroky.length) zastavit();
      vykreslit();
      naplanovat();
    }
    function souhrn(pocet) {
      return '<dl>' + kroky.slice(0, pocet).map((krok, i) =>
        `<dt>${krok.pole}</dt><dd>${krok.moznosti[vyber[i]]}</dd>`).join('') + '</dl>';
    }
    function vykreslit() {
      const hotovo = index === kroky.length;
      const krok = kroky[index];
      const volby = hotovo ? '' : krok.moznosti.map((v, i) =>
        `<label><input type="radio" name="prvni-volba" value="${i}" ${vyber[index] === i ? 'checked' : ''}>${v}</label>`).join('');
      panel.innerHTML = `<section class="prvni" data-prvni-krok="${index + 1}">
        <small>${hotovo ? 'Výsledek cvičné zakázky' : `Cvičná zakázka · ${index + 1} ze 3`}</small>
        <progress max="${kroky.length}" value="${hotovo ? kroky.length : index + 1}" aria-hidden="true"></progress>
        <h3 tabindex="-1">${hotovo ? 'Cvičná zakázka CV-001 je připravená' : krok.titul}</h3>
        <p>${hotovo ? 'Takhle vypadá předání požadavku mechanikovi. Údaje zůstávají jen v této ukázce.' : krok.popis}</p>
        ${index ? souhrn(index) : ''}
        ${hotovo ? '' : `<fieldset><legend>${krok.pole}</legend>${volby}</fieldset>`}
        <div class="prvni-akce">${hotovo ? `
            ${dostupnyScenar ? '<button type="button" class="b main" data-prvni="servis">Projít ve vlastním servisu</button>' : ''}
            <button type="button" class="b ghost" data-prvni="opakovat">Opakovat ukázku</button>` : `
            <button type="button" class="b main" data-prvni="dalsi">${index === 2 ? 'Vytvořit cvičnou zakázku' : 'Další'}</button>
            <button type="button" class="b ghost" data-prvni="auto" aria-pressed="${bezi}">${bezi ? 'Pozastavit přehrávání' : 'Přehrát automaticky'}</button>`}
            ${index ? '<button type="button" class="nenapadny" data-prvni="zpet">Zpět</button>' : ''}
            <button type="button" class="nenapadny" data-prvni="preskocit">${hotovo ? 'Zpět na krokové návody' : 'Přeskočit na krokové návody'}</button>
        </div></section>`;
      panel.querySelector('h3').focus();
    }
    function prepnoutPrehravani() {
      if (bezi) zastavit();
      else { bezi = true; naplanovat(); }
      const tlacitko = panel.querySelector('[data-prvni="auto"]');
      if (tlacitko) {
        tlacitko.textContent = bezi ? 'Pozastavit přehrávání' : 'Přehrát automaticky';
        tlacitko.setAttribute('aria-pressed', String(bezi));
      }
    }
    function klik(e) {
      const tlacitko = e.target.closest('[data-prvni]');
      if (!tlacitko || !panel.contains(tlacitko)) return;
      switch (tlacitko.dataset.prvni) {
        case 'dalsi': zastavit(); prejit(index + 1); break;
        case 'zpet': zastavit(); prejit(index - 1); break;
        case 'auto': prepnoutPrehravani(); break;
        case 'opakovat': zastavit(); vyber = [0, 0, 0]; prejit(0); break;
        case 'preskocit': menu(); break;
        case 'servis': if (dostupnyScenar) servis(); break;
      }
    }
    function zmena(e) {
      if (e.target.name !== 'prvni-volba') return;
      vyber[index] = Number(e.target.value);
      if (bezi) prepnoutPrehravani();
    }
    function viditelnost() {
      if (document.hidden && bezi) prepnoutPrehravani();
    }
    function uklidit() {
      ukoncena = true;
      zastavit();
      panel.removeEventListener('click', klik);
      panel.removeEventListener('change', zmena);
      document.removeEventListener('visibilitychange', viditelnost);
      window.removeEventListener('pagehide', uklidit);
    }
    panel.addEventListener('click', klik);
    panel.addEventListener('change', zmena);
    document.addEventListener('visibilitychange', viditelnost);
    window.addEventListener('pagehide', uklidit);
    vykreslit();
    return uklidit;
  }

  window.ICOP2_PRVNI_ZAKAZKA = { styl, nabidkaHtml, spustit };
})();
