// Sdílené úložiště postupu pro obsahový skript a popup. Kontakt má vlastní místní klíč.
(() => {
  'use strict';
  const key = 'icop2:state';
  const cas = (stav) => Number.isFinite(stav?.casZapisu) ? stav.casZapisu : 0;
  const novejsi = (sync, local) => !sync || cas(local) > cas(sync) ? local : sync;

  function precti(oblast, cb) {
    if (!oblast) { cb(null); return; }
    try {
      oblast.get([key], (r) => cb(chrome.runtime.lastError ? null : r?.[key]));
    } catch (e) { cb(null); }
  }

  function nacti(cb) {
    precti(chrome.storage.sync, (sync) => {
      precti(chrome.storage.local, (local) => cb(novejsi(sync, local) || null));
    });
  }

  function uloz(stav, cb) {
    // Obě operace zahájit ještě před případnou navigací. Překročení kvóty sync
    // neznehodnotí místní zápis a po opětovném načtení rozhodne jeho revize.
    const oblasti = [chrome.storage.local, chrome.storage.sync].filter(Boolean);
    let zbyva = oblasti.length;
    const hotovo = () => { if (--zbyva === 0 && cb) cb(); };
    for (const oblast of oblasti) {
      try {
        oblast.set({ [key]: stav }, () => { void chrome.runtime.lastError; hotovo(); });
      } catch (e) { hotovo(); }
    }
  }

  window.ICOP2_STAV = { cas, nacti, uloz, dalsiCas: (stav) => Math.max(Date.now(), cas(stav) + 1) };
})();
