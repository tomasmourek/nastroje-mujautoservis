(() => {
  'use strict';
  const povolena = () => globalThis.ICOP2_EET_WEB?.povolena(location.href) === true;
  if (window !== window.top || !povolena()) return false;
  if (globalThis.ICOP2_EET_PANEL?.otevri()) return true;

  const { vytvor, tlacitko, pridejStyl, zobraz } = globalThis.ICOP2_EET_PRUVODCE;
  const host = document.createElement('div');
  host.id = 'icop2-eet-panel';
  host.lang = 'cs';
  const stin = host.attachShadow({ mode: 'closed' });
  const css = `:host { all: initial !important; color-scheme: var(--ic-scheme, light dark) !important; position: fixed !important; bottom: max(10px, env(safe-area-inset-bottom)) !important; right: max(10px, env(safe-area-inset-right)) !important; z-index: 2147483647 !important; width: max-content !important; max-width: calc(100vw - 20px) !important; }
* { box-sizing: border-box; }
[hidden] { display: none !important; }
aside, .roleta { font: 14px/1.5 var(--ic-font); border: 1px solid var(--ic-hair); border-radius: var(--ic-radius); color: var(--ic-ink); background: var(--ic-surface); box-shadow: var(--ic-shadow); }
aside { display: flex; flex-direction: column; width: min(416px, calc(100vw - 20px)); max-height: min(74vh, 610px); max-height: min(74dvh, 610px); overflow: hidden; }
header { display: flex; align-items: center; gap: 4px; flex: none; padding: 3px 8px 3px 14px; flex-wrap: wrap; background: var(--ic-band); color: var(--ic-band-ink); }
header strong { margin-inline-end: auto; font-size: 16px; font-weight: 700; }
header button, .roleta { cursor: pointer; }
header button { font: inherit; font-size: 13px; font-weight: 600; border-radius: var(--ic-control-radius); border: 0; background: transparent; color: inherit; padding: 6px; min-height: 38px; }
header button:hover { text-decoration: underline; text-underline-offset: 2px; }
.roleta { background: var(--ic-band); border-color: var(--ic-band); color: var(--ic-band-ink); font-weight: 700; padding: 8px 14px; min-height: 44px; }
.list { padding: 14px; overflow-y: auto; overscroll-behavior: contain; }
.list.eet-kroky { font-size: 14px; }
.list.eet-kroky h2 { font-size: 17px; }
:focus-visible { outline: 2px solid var(--ic-accent); outline-offset: 2px; }
header button:focus-visible { outline-color: var(--ic-band-ink); outline-offset: -2px; }
@media (max-width: 480px) { aside { max-height: 59vh; max-height: 59dvh; } .list { padding: 12px; } }
@media (pointer: coarse) { header button { min-height: 44px; } }`;
  pridejStyl(stin, globalThis.ICOP2_VZHLED.css);
  pridejStyl(stin, css);
  const panel = vytvor('aside');
  panel.setAttribute('aria-label', 'IC Office Průvodce – aktivace EET');
  const lista = vytvor('header');
  const nazev = vytvor('strong', 'IC Office Průvodce · EET');
  const sbalit = tlacitko('Sbalit', 'sbalit');
  sbalit.setAttribute('aria-expanded', 'true');
  const zavrit = tlacitko('Zavřít', 'zavrit');
  const rozbalit = tlacitko('Otevřít návod EET', 'rozbalit', 'roleta');
  rozbalit.setAttribute('aria-expanded', 'false');
  rozbalit.hidden = true;
  const obsah = vytvor('div', '', 'list');
  lista.append(nazev, sbalit, zavrit);
  panel.append(lista, obsah);
  stin.append(panel, rozbalit);
  document.documentElement.append(host);
  const odpojMotiv = globalThis.ICOP2_VZHLED.pripoj(host);
  let aktivni = true;
  let kontrolaUrl;
  let ovladani;
  function zrus() {
    if (!aktivni) return;
    aktivni = false;
    clearInterval(kontrolaUrl);
    window.removeEventListener('popstate', over);
    window.removeEventListener('hashchange', over);
    window.removeEventListener('pagehide', zrus);
    document.removeEventListener('visibilitychange', sleduj);
    ovladani?.zrus();
    odpojMotiv();
    host.remove();
    delete globalThis.ICOP2_EET_PANEL;
  }
  function over() {
    if (aktivni && (!povolena() || !host.isConnected)) zrus();
    return aktivni;
  }
  function sleduj() {
    clearInterval(kontrolaUrl);
    if (over() && !document.hidden) kontrolaUrl = setInterval(over, 500);
  }
  function otevri() {
    if (!over()) return false;
    panel.hidden = false;
    rozbalit.hidden = true;
    return true;
  }
  stin.addEventListener('click', (event) => {
    if (!event.isTrusted || !over()) {
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    if (event.target === zavrit) zrus();
    else if (event.target === sbalit) {
      panel.hidden = true;
      rozbalit.hidden = false;
      rozbalit.focus({ preventScroll: true });
    } else if (event.target === rozbalit) {
      otevri();
      sbalit.focus({ preventScroll: true });
    }
  }, true);
  stin.addEventListener('keydown', (event) => {
    if (event.isTrusted && event.key === 'Escape' && over() && !panel.hidden) {
      event.stopPropagation();
      panel.hidden = true;
      rozbalit.hidden = false;
      rozbalit.focus({ preventScroll: true });
    }
  });
  // Popstate nezachytí pushState měnící trasu v jedné stránce. Na bankovní
  // ani jiné nepovolené cestě panel nesmí zůstat po navigaci nebo přijmout akci.
  window.addEventListener('popstate', over);
  window.addEventListener('hashchange', over);
  window.addEventListener('pagehide', zrus);
  document.addEventListener('visibilitychange', sleduj);
  sleduj();
  ovladani = zobraz(obsah, { plati: over, nadpis: 'h2' });
  globalThis.ICOP2_EET_PANEL = Object.freeze({ otevri });
  return true;
})();
