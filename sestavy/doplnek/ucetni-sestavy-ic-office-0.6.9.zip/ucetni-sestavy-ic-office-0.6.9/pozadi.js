const api = globalThis.browser ?? globalThis.chrome;
// Stáhne exporty za zvolené období z otevřené a přihlášené karty IC Office a vrátí je stránce sestav.
// Doklady ani heslo neukládá; před zápisem uchová v IC Office pouze ID nepotvrzeného pohybu.
const IC_OFFICE = "https://ic-office.eu";
const POVOLENY_PUVOD = "https://nastroje.mujautoservis.eu";

// Signály tlačítek „Export Excel“ na stránce Přehledy (/overview/). Pořadí odpovídá druhům v sestavách:
// faktury, položky faktur, pokladna, naskladněné zboží, vydané zboží, mechanici.
const EXPORTY = [
  "exportInvoicesExcel",
  "exportInvoicesItemsExcel",
  "exportCashboxExcel",
  "exportGoodsImportExcel",
  "exportGoodsMinusExcel",
  "exportMechanicsItemsContracts",
];
const KONTROLNI_EXPORTY = new Map([
  ["prijate-faktury", "exportIncomingInvoicesExcel"],
  ["chyby-eet", "exportEETExcel"],
]);

let bezi = false;

// Firefox nemusí vyplnit origin. URL dodává prohlížeč, nikdy samotná zpráva stránky.
// Přijímáme pouze hlavní rámec sestav; případný neprůhledný či cizí origin odmítneme.
function zeSestav(odesilatel) {
  try {
    const url = new URL(odesilatel.url);
    return (
      url.origin === POVOLENY_PUVOD &&
      url.pathname.startsWith("/sestavy/") &&
      odesilatel.frameId === 0 &&
      (odesilatel.origin === undefined || odesilatel.origin === POVOLENY_PUVOD)
    );
  } catch {
    return false;
  }
}

api.runtime.onMessage.addListener((zprava, odesilatel, odpovedet) => {
  if (!["nacist", "nacist-katalog", "nacist-rozpracovanost", "nacist-kontrolni-export"].includes(zprava?.typ)) return;
  const katalog = zprava.typ === "nacist-katalog";
  const rozpracovanost = zprava.typ === "nacist-rozpracovanost";
  const kontrola = zprava.typ === "nacist-kontrolni-export";
  if (!zeSestav(odesilatel)) {
    odpovedet({
      ok: false,
      chyba: "Žádost nepřišla ze stránky Účetních sestav.",
    });
    return;
  }
  if (!katalog && !rozpracovanost && !platneObdobi(zprava.od, zprava.do)) {
    odpovedet({ ok: false, chyba: "Neplatné období." });
    return;
  }
  const signal = kontrola ? KONTROLNI_EXPORTY.get(zprava.druh) : undefined;
  if (kontrola && !signal) {
    odpovedet({ ok: false, chyba: "Neznámý druh kontrolního exportu." });
    return;
  }
  // Druhý souběžný běh by v IC Office přepsal období prvnímu.
  if (bezi) {
    odpovedet({ ok: false, chyba: "Načítání z IC Office už probíhá." });
    return;
  }
  bezi = true;
  const doplnitDoklady = zprava.typ === "nacist" && zprava.doplnitDoklady === true && zprava.automaticky !== true;
  // Do karty jdou z voleb rozpracovanosti jen dvě pravdivostní hodnoty.
  const volbyRozpracovanosti = { polozky: zprava.polozky === true, nakupniCeny: zprava.nakupniCeny === true };
  nacist(zprava.od, zprava.do, doplnitDoklady, katalog, rozpracovanost, signal, volbyRozpracovanosti)
    .then(odpovedet, (e) => odpovedet({ ok: false, chyba: e.message }))
    .finally(() => {
      bezi = false;
    });
  return true;
});

// Období ve tvaru RRRR-MM-DD, skutečná data a začátek nejpozději v den konce.
function platneObdobi(od, doDne) {
  const datum = (d) =>
    typeof d === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(d) &&
    Number.isFinite(Date.parse(`${d}T00:00:00Z`)) &&
    new Date(`${d}T00:00:00Z`).toISOString().startsWith(d);
  return datum(od) && datum(doDne) && od <= doDne;
}

async function nacist(od, doDne, doplnitDoklady = false, katalog = false, rozpracovanost = false, kontrolniSignal, volbyRozpracovanosti) {
  // Filtry Evidence zakázek nastavuje skript stránky až po načtení.
  if (rozpracovanost) return nacistVNoveKarte(od, doDne, false, false, true, undefined, volbyRozpracovanosti);
  // Uspanou kartu (úspora paměti) ani rozpracovanou nelze skriptovat; zkusí se naposledy použité.
  const karty = (
    await api.tabs.query({ url: `${IC_OFFICE}/*`, discarded: false })
  )
    .filter((k) => k.status === "complete")
    .sort((a, b) => (b.lastAccessed ?? 0) - (a.lastAccessed ?? 0));
  // Zmrazená karta na pozadí nebo karta s otevřeným dialogem skript nespustí a čekalo by se
  // na ni donekonečna, proto se použije jen karta, která odpoví na krátký test.
  let chyba;
  for (const karta of karty) {
    try {
      if (!(await odpovida(karta.id))) continue;
      // Po zahájení zápisového běhu se žádná druhá karta nezkouší ani při ztrátě odpovědi.
      if (doplnitDoklady) return stahnoutVKarte(karta.id, od, doDne, true);
      return await stahnoutVKarte(karta.id, od, doDne, false, katalog, false, kontrolniSignal);
    } catch (e) {
      chyba = e;
    }
  }
  if (chyba) throw nedostalSe(chyba);
  return nacistVNoveKarte(od, doDne, doplnitDoklady, katalog, false, kontrolniSignal);
}

// Ověří, že karta spustí skript do 5 s. Chyba vložení (například chybějící oprávnění) se předá dál.
function odpovida(idKarty) {
  return Promise.race([
    api.scripting
      .executeScript({ target: { tabId: idKarty }, func: () => true })
      .then(([v]) => v?.result === true),
    new Promise((splnit) => setTimeout(() => splnit(false), 5_000)),
  ]);
}

const nedostalSe = (e) =>
  new Error(
    `Doplněk se nedostal do karty IC Office. Obnovte kartu IC Office, zkontrolujte, že má doplněk v prohlížeči povolený přístup k ic-office.eu, a zkuste to znovu. (${e.message})`,
  );

async function stahnoutVKarte(idKarty, od, doDne, doplnitDoklady, katalog = false, rozpracovanost = false, kontrolniSignal, volbyRozpracovanosti) {
  const args = rozpracovanost ? [volbyRozpracovanosti] : katalog ? [] : [od, doDne, EXPORTY, doplnitDoklady];
  const [vysledek] = await api.scripting.executeScript({
    target: { tabId: idKarty },
    func: rozpracovanost ? stahnoutRozpracovanost : katalog ? stahnoutKatalog : stahnoutExporty,
    args: kontrolniSignal ? [od, doDne, [kontrolniSignal], false, true] : args,
  });
  return (
    vysledek?.result ?? { ok: false, chyba: "Karta IC Office neodpověděla." }
  );
}

// Bez otevřené karty otevře IC Office na pozadí. Přihlášení si pamatuje prohlížeč; když chybí,
// karta zůstane otevřená a přepne se na ni, aby se uživatel mohl přihlásit. Jinak se zavře.
async function nacistVNoveKarte(od, doDne, doplnitDoklady, katalog = false, rozpracovanost = false, kontrolniSignal, volbyRozpracovanosti) {
  const karta = await api.tabs.create({
    url: `${IC_OFFICE}${rozpracovanost ? "/contracts/" : katalog ? "/warehouse/goods-search" : "/overview/"}`,
    active: false,
  });
  let ponechat = false;
  try {
    await nactena(karta.id);
    const v = await stahnoutVKarte(karta.id, od, doDne, doplnitDoklady, katalog, rozpracovanost, kontrolniSignal, volbyRozpracovanosti).catch((e) => {
      throw nedostalSe(e);
    });
    if (v.prihlasit) {
      ponechat = true;
      await api.tabs.update(karta.id, { active: true });
      return {
        ok: false,
        chyba:
          "Otevřel jsem IC Office v nové kartě, ale nejste v něm přihlášení. Přihlaste se v ní a zkuste to znovu.",
      };
    }
    return v;
  } finally {
    if (!ponechat) await api.tabs.remove(karta.id).catch(() => {});
  }
}

// Samostatné čtení seznamu a cen z jednoduchého přehledu zakázek. Na přání přidá položky
// z editace zakázky a nákupní cenu materiálu ze stejného výpočtu marže, jaký ukazuje IC Office.
// Všechny požadavky jsou GET; zakázky se nemění.
async function stahnoutRozpracovanost(volby) {
  const nakupniCeny = volby?.nakupniCeny === true;
  const sPolozkami = nakupniCeny || volby?.polozky === true;
  const puvod = "https://ic-office.eu";
  const seznam = "/contracts/";
  const stavy = new Map([
    ["0", "Nová"], ["1", "Schváleno"], ["2", null], ["3", "Přerušeno"],
    ["4", "Pracuje se"], ["5", null], ["12", "K fakturaci"],
  ]);
  const html = (s) => new DOMParser().parseFromString(s, "text/html");
  const text = (e) => e?.textContent?.replace(/\s+/g, " ").trim() ?? "";
  const nacistStranku = async (cesta, ajax = false) => {
    const odpoved = await fetch(puvod + cesta, {
      method: "GET",
      credentials: "same-origin",
      cache: "no-store",
      signal: AbortSignal.timeout(25_000),
      // Výpočet marže vrací IC Office jako JSON jen pro požadavek označený jako AJAX.
      ...(ajax ? { headers: { "X-Requested-With": "XMLHttpRequest" } } : {}),
    });
    const vratila = new URL(odpoved.url);
    if (!odpoved.ok || vratila.origin !== puvod) throw new Error("IC Office nevrátil požadovanou stránku.");
    if (vratila.pathname.startsWith("/login")) return null;
    if (vratila.pathname !== cesta.split("?")[0]) throw new Error("IC Office otevřel jinou stránku zakázek.");
    return odpoved;
  };

  const radky = new Map();
  const indexVytvoreni = [...document.querySelectorAll("#snippet--contracts thead tr:last-child > th")]
    .findIndex((bunka) => text(bunka) === "Vytvoření");
  const ulozitStranku = (dokument, strana, ocekavano) => {
    const telo = dokument.getElementById("snippet--contracts_tbody");
    const navigace = dokument.getElementById("snippet--contracts_pagitation");
    const m = /Stránka\s+(\d+)\s+z\s+(\d+)/i.exec(text(navigace));
    const pocet = m ? Number(m[2]) : 1;
    if (!telo || !navigace || (m && Number(m[1]) !== strana)
      || (strana > 1 && !m) || (ocekavano !== undefined && pocet !== ocekavano)
      || pocet > 500)
      throw new Error("Seznam zakázek má neúplné nebo změněné stránkování.");
    for (const r of telo.querySelectorAll(":scope > tr")) {
      const detail = r.querySelector("a.mmore");
      if (!detail && r.cells.length === 1 && r.cells[0].colSpan > 1 && /žádn|neobsahuje/i.test(text(r))) continue;
      const id = detail?.getAttribute("data-id");
      const stav = detail?.getAttribute("data-state");
      const cislo = text(r.cells[2]);
      const bunkaNazvu = r.cells[6];
      if (!id || !/^\d+$/.test(id) || !cislo || !bunkaNazvu || !stavy.has(stav) || radky.has(id))
        throw new Error("IC Office vrátil neúplný, opakovaný nebo neznámý záznam zakázky.");
      const zakazka = { cislo, nazev: text(bunkaNazvu), stav: stavy.get(stav) };
      const vytvoreno = /^(\d{1,2})\.\s*(\d{1,2})\.\s*(\d{4})(?:\s|$)/.exec(text(r.cells[indexVytvoreni]));
      if (indexVytvoreni >= 0) {
        zakazka.vytvoreno = vytvoreno ? `${vytvoreno[3]}-${vytvoreno[2].padStart(2, "0")}-${vytvoreno[1].padStart(2, "0")}` : "";
      }
      radky.set(id, zakazka);
    }
    return pocet;
  };

  const ceny = async (id, zakazka) => {
    const odpoved = await nacistStranku(`/record/moreprew/${id}`);
    const dokument = odpoved && html(await odpoved.text());
    const tabulka = dokument?.getElementById("table-items");
    const chyba = () => new Error(`U zakázky ${zakazka.cislo} se nepodařilo ověřit ceny bez DPH. V IC Office nastavte jednoduchý přehled zakázky a zkontrolujte její detail.`);
    if (!tabulka) throw chyba();
    const soucty = new Map();
    const popisDjm = "Drobný jednicový materiál";
    for (const hlavicka of tabulka.querySelectorAll("tr > th")) {
      const popis = text(hlavicka);
      if (!["Celkem", "Celkem za materiál", "Celkem za práci", popisDjm].includes(popis)) continue;
      const hodnota = text(hlavicka.nextElementSibling);
      const castka = Number(hodnota.replace(/\s/g, "").replace(",", "."));
      if (!/^-?(?:\d+|\d{1,3}(?: \d{3})+)(?:[,.]\d{1,2})?$/.test(hodnota)
        || !Number.isFinite(castka) || soucty.has(popis)) throw chyba();
      soucty.set(popis, castka);
    }
    // IC Office uvádí DJM samostatně a zahrnuje ho do celkové ceny zakázky.
    const material = (soucty.get("Celkem za materiál") ?? 0) + (soucty.get(popisDjm) ?? 0);
    const vykon = soucty.get("Celkem za práci") ?? 0;
    const celkem = soucty.get("Celkem");
    if (celkem === undefined
      || (!soucty.has("Celkem za materiál") && /Materiál\s*:/i.test(text(tabulka)))
      || (!soucty.has("Celkem za práci") && /Práce\s*:/i.test(text(tabulka)))
      || Math.abs(material + vykon - celkem) > 0.02)
      throw chyba();
    if (!sPolozkami) return { ...zakazka, material, vykon };
    const polozky = await polozkyZakazky(id, zakazka, soucty.get("Celkem za materiál") ?? 0, vykon);
    return { ...zakazka, material, vykon, polozky };
  };

  const castkaZPole = (hodnota) => {
    const t = String(hodnota ?? "").replace(/\s/g, "").replace(",", ".");
    return /^-?\d+(?:\.\d+)?$/.test(t) ? Number(t) : NaN;
  };
  const zaokrouhlit = (n) => Math.round(n * 100) / 100;
  const TYPY_POLOZEK = new Map([["0", "material"], ["1", "prace"]]);

  // Nákupní cena = prodejní cena bez slevy minus marže, kterou IC Office spočítá ze skladové karty.
  const nakupniCena = async (id, zakazka, p) => {
    const dotaz = new URLSearchParams({
      do: "computeMarginPopover", code: p.kod, war_id: p.skladId, count: String(p.pocet),
      price_pc: String(p.cenaMj), price_pc_vat: String(p.cenaMjSDph), discount: "", type: "0",
    });
    const chyba = () => new Error(`U zakázky ${zakazka.cislo} se nepodařilo ověřit nákupní cenu položky ${p.nazev}.`);
    const odpoved = await nacistStranku(`/record/edit/${id}?${dotaz}`, true);
    if (!odpoved) throw chyba();
    const obsah = await odpoved.json().catch(() => null);
    if (typeof obsah?.html !== "string") throw chyba();
    const radky = [...html(obsah.html).querySelectorAll("tr")]
      .filter((r) => text(r.querySelector("th")) === "Marže celkem bez DPH [Kč]");
    const hodnota = radky.length === 1 ? text(radky[0].querySelector("td")) : "";
    if (!/^-?(?:\d+|\d{1,3}(?: \d{3})+)(?:,\d{1,2})?$/.test(hodnota)) throw chyba();
    const nakup = zaokrouhlit(p.cenaMj * p.pocet - castkaZPole(hodnota));
    if (!Number.isFinite(nakup)) throw chyba();
    return nakup;
  };

  const polozkyZakazky = async (id, zakazka, materialBezDjm, prace) => {
    const odpoved = await nacistStranku(`/record/edit/${id}`);
    const dokument = odpoved && html(await odpoved.text());
    const chyba = () => new Error(`U zakázky ${zakazka.cislo} se nepodařilo načíst položky. Zkontrolujte zakázku v IC Office.`);
    if (!dokument) throw chyba();
    const hodnota = (nazev) => String(dokument.querySelector(`[name="${nazev}"]`)?.value ?? "").trim();
    const polozky = [];
    for (const prvek of dokument.querySelectorAll('[name^="gg_"]')) {
      const klic = /^gg_(\d+_\d+)$/.exec(prvek.getAttribute("name") ?? "")?.[1];
      if (!klic) continue;
      const nazev = String(prvek.value ?? "").replace(/\s+/g, " ").trim();
      const prodejText = hodnota(`pw_${klic}`);
      // Prázdný řádek pro novou položku nemá název ani cenu.
      if (!nazev && !prodejText) continue;
      const p = {
        typ: TYPY_POLOZEK.get(hodnota(`gt_${klic}`)),
        nazev,
        kod: hodnota(`go_${klic}`),
        pocet: castkaZPole(hodnota(`gs_${klic}`)),
        mj: hodnota(`gj_${klic}`),
        prodej: castkaZPole(prodejText),
        cenaMj: castkaZPole(hodnota(`gb_${klic}`)),
        cenaMjSDph: castkaZPole(hodnota(`gc_${klic}`)),
        skladId: hodnota(`gi_${klic}`),
      };
      if (!p.typ || !Number.isFinite(p.pocet) || !Number.isFinite(p.prodej)
        || !Number.isFinite(p.cenaMj) || !Number.isFinite(p.cenaMjSDph)) throw chyba();
      polozky.push(p);
    }
    const soucet = (typ) => zaokrouhlit(polozky.filter((p) => p.typ === typ).reduce((a, p) => a + p.prodej, 0));
    // Položky musí odpovídat součtům jednoduchého přehledu; jinak se sestava nevytvoří.
    if (Math.abs(soucet("material") - materialBezDjm) > 0.05 || Math.abs(soucet("prace") - prace) > 0.05) throw chyba();
    const vysledek = [];
    for (const p of polozky) {
      const polozka = { typ: p.typ, nazev: p.nazev, kod: p.kod, pocet: p.pocet, mj: p.mj, prodej: p.prodej };
      // Položka bez skladové karty nemá v IC Office nákupní cenu.
      if (nakupniCeny && p.typ === "material")
        polozka.nakup = /^[1-9]\d{0,19}$/.test(p.skladId) ? await nakupniCena(id, zakazka, p) : null;
      vysledek.push(polozka);
    }
    return vysledek;
  };

  try {
    if (location.origin !== puvod) throw new Error("Otevřete kartu IC Office.");
    if (location.pathname.startsWith("/login") || document.querySelector('input[type="password"]'))
      return { ok: false, prihlasit: true, chyba: "Přihlaste se do IC Office a zkuste to znovu." };
    if (location.pathname !== seznam || location.search || location.hash)
      throw new Error("IC Office otevřel jinou stránku zakázek.");
    const obdobi = document.querySelector("select#months");
    const filtrStavu = document.querySelector("#stateAll");
    const filtrySloupcu = [...document.querySelectorAll("#snippet--contracts thead tr:first-child :is(input,select)[name]")];
    if (!obdobi || obdobi.value !== "0" || document.querySelector("input#date")?.checked
      || !filtrStavu || filtrStavu.value || document.querySelector("input#search")?.value.trim()
      || document.querySelector("#afterDateFinish")?.checked || document.querySelector("#warehouseFilter")?.value
      || filtrySloupcu.some((filtr) => filtr.multiple
        ? [...filtr.selectedOptions].some((volba) => volba.value !== "")
        : filtr.value.trim() !== ""))
      throw new Error("V Evidenci zakázek IC Office nastavte období Všechny, zrušte ostatní filtry a zkuste to znovu.");
    const pocet = ulozitStranku(document, 1);
    for (let strana = 2; strana <= pocet; strana++) {
      const odpoved = await nacistStranku(`${seznam}?do=pagination&page=${strana}`);
      if (!odpoved) return { ok: false, prihlasit: true, chyba: "Přihlaste se do IC Office a zkuste to znovu." };
      ulozitStranku(html(await odpoved.text()), strana, pocet);
    }
    const otevrene = [...radky].filter(([, z]) => z.stav !== null);
    const zakazky = [];
    for (let i = 0; i < otevrene.length; i += 4) {
      const davka = await Promise.allSettled(otevrene.slice(i, i + 4).map(([id, z]) => ceny(id, z)));
      for (const v of davka) {
        if (v.status === "rejected") throw v.reason;
        zakazky.push(v.value);
      }
    }
    return { ok: true, zakazky };
  } catch (e) {
    return { ok: false, chyba: e.message };
  }
}

// Počká, až se karta dočte, nejdéle 30 s.
function nactena(idKarty) {
  return new Promise((splnit, selhat) => {
    const konec = () => {
      api.tabs.onUpdated.removeListener(zmena);
      clearTimeout(casovac);
    };
    const zmena = (id, info) => {
      if (id !== idKarty || info.status !== "complete") return;
      konec();
      splnit();
    };
    const casovac = setTimeout(() => {
      konec();
      selhat(new Error("IC Office se nepodařilo otevřít včas."));
    }, 30_000);
    api.tabs.onUpdated.addListener(zmena);
    // Karta se mohla dočíst dřív, než se přihlásil posluchač.
    api.tabs.get(idKarty).then((k) => {
      if (k.status !== "complete") return;
      konec();
      splnit();
    }, selhat);
  });
}

// Samostatný úplný katalog. Nemění období ani nevytváří skladové doklady.
// Funkce se vkládá do IC Office, proto nepoužívá proměnné pozadí doplňku.
async function stahnoutKatalog() {
  const puvod = "https://ic-office.eu";
  const spustit = async () => {
    const overitKatalog = async () => {
      const r = await fetch(`${puvod}/warehouse/goods-search`, { credentials: "same-origin" });
      if (!r.ok || (r.url && new URL(r.url).origin !== puvod)) throw new Error("Nelze ověřit katalog všech skladů IC Office.");
      const doc = new DOMParser().parseFromString(await r.text(), "text/html");
      if (doc.querySelector('input[type="password"]')) return false;
      const tabulka = doc.getElementById("database_warehouse");
      const hledani = doc.querySelector('input#search[type="text"]');
      const norm = (s) => (s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
      const sloupce = [...(tabulka?.querySelectorAll("thead th") ?? [])].map((h) => norm(h.textContent));
      if (!tabulka || !hledani || !["kod", "nazev", "mnozstvi", "sklad"].every((s) => sloupce.includes(s))) throw new Error("IC Office nevrátil rozpoznaný katalog všech skladů. Otevřete Sklady → Všechno zboží.");
      if ((hledani.getAttribute("value") ?? "").trim()) throw new Error("V IC Office je katalog filtrovaný. Ve Sklady → Všechno zboží vymažte hledání a potvrďte OK, pak načtení zopakujte.");
      return true;
    };
    if (!await overitKatalog()) return { ok: false, prihlasit: true, chyba: "Přihlaste se do IC Office a zkuste načtení katalogu znovu." };
    const url = `${puvod}/warehouse/?do=exportGoodsSearchExcel`;
    const r = await fetch(url, { credentials: "same-origin" });
    if (!r.ok || (r.url && r.url !== url)) throw new Error("IC Office nevrátil export katalogu; ověřte přihlášení.");
    const nazev = /filename="?([^";]+)/.exec(r.headers.get("content-disposition") ?? "")?.[1];
    if (!nazev || !/\.xlsx$/i.test(nazev) || /[\\/\r\n]/.test(nazev) || Number(r.headers.get("content-length")) > 50 * 1024 * 1024) throw new Error("IC Office nevrátil platný export Excel do 50 MiB.");
    const bajty = new Uint8Array(await r.arrayBuffer());
    if (bajty.length < 4 || bajty.length > 50 * 1024 * 1024 || bajty[0] !== 80 || bajty[1] !== 75 || bajty[2] !== 3 || bajty[3] !== 4) throw new Error("IC Office vrátil jiný obsah než soubor XLSX.");
    // Filtr se během stahování mohl změnit v jiné kartě; neúplný snímek nepředáme.
    if (!await overitKatalog()) throw new Error("Během načítání vypršelo přihlášení do IC Office.");
    let obsah = "";
    for (let i = 0; i < bajty.length; i += 0x8000) {
      const cast = [];
      // Indexy zachovávají kompatibilitu s Firefox Xray (bez cizího constructor).
      for (let j = i; j < Math.min(i + 0x8000, bajty.length); j++) cast.push(bajty[j]);
      obsah += String.fromCharCode(...cast);
    }
    return { ok: true, soubor: { nazev, data: btoa(obsah) } };
  };
  try {
    if (!globalThis.navigator?.locks?.request) throw new Error("Prohlížeč neposkytuje zámek pro bezpečné načtení. Aktualizujte prohlížeč.");
    // Firefox potřebuje callback v realmu stránky (Mozilla 1873028).
    // Exportujeme jen neveřejný callback; data a práce zůstávají v sandboxu doplňku.
    let vysledek, chyba;
    let selhalo = false;
    const seZamkem = (zamek) => {
      if (!zamek) {
        vysledek = { ok: false, chyba: "Načítání z IC Office už probíhá v jiné kartě." };
        return;
      }
      return new window.Promise((hotovo) => {
        void (async () => {
          try { vysledek = await spustit(); }
          catch (e) { chyba = e; selhalo = true; }
          finally { hotovo(); }
        })();
      });
    };
    const callback = typeof exportFunction === "function" ? exportFunction(seZamkem, window) : seZamkem;
    await navigator.locks.request("ucetni-sestavy-ic-office-import", { ifAvailable: true }, callback);
    if (selhalo) throw chyba;
    return vysledek;
  } catch (e) {
    return { ok: false, chyba: `Načtení katalogu IC Office selhalo: ${e.message}` };
  }
}

// Běží v kartě IC Office, proto musí být soběstačná. Nastaví zvolené období (RRRR-MM-DD),
// stáhne exporty a vrátí původní období, i když stahování selže.
async function stahnoutExporty(odIso, doIso, exporty, doplnitDoklady = false, pouzeExcel = false) {
  const puvod = "https://ic-office.eu";
  const cz = (d) => d.split("-").reverse().join(".");
  const od = cz(odIso);
  const doDne = cz(doIso);
  const text = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  const datum = (s, id) => {
    const m = /^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s|$)/.exec(s);
    if (!m) throw new Error(`Pohyb ${id}: skladový doklad má neplatné datum.`);
    const d = `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
    if (!Number.isFinite(Date.parse(`${d}T00:00:00Z`)) || !new Date(`${d}T00:00:00Z`).toISOString().startsWith(d)) throw new Error(`Pohyb ${id}: skladový doklad má neplatné datum.`);
    return d;
  };
  const vObdobi = (d) => d >= odIso && d <= doIso;
  const dokument = async (url, volby) => {
    const r = await fetch(url, { credentials: "same-origin", ...volby });
    if (!r.ok) throw new Error("IC Office nevrátil stránku skladových dokladů.");
    if (r.url && new URL(r.url, puvod).origin !== puvod) throw new Error("IC Office přesměroval požadavek mimo svůj web.");
    return new DOMParser().parseFromString(await r.text(), "text/html");
  };
  const nastavitObdobi = async (z, k) => {
    const r = await fetch("/overview/", {
      method: "POST", credentials: "same-origin",
      body: new URLSearchParams({ from: z, to: k, settings: "Filtrovat", _do: "settingsForm-submit" }),
    });
    if (!r.ok) throw new Error("Nepodařilo se nastavit nebo obnovit období Přehledů IC Office.");
  };
  const base64 = (bajty) => {
    let s = "";
    for (let i = 0; i < bajty.length; i += 0x8000) {
      // Firefox Xray nepovoluje subarray/slice, protože čtou cizí constructor.
      const cast = [];
      for (let j = i; j < Math.min(i + 0x8000, bajty.length); j++) cast.push(bajty[j]);
      s += String.fromCharCode(...cast);
    }
    return btoa(s);
  };
  const pdfOdkaz = (href, ocekavaneId) => {
    const u = new URL(href, puvod);
    const m = /^\/warehouse\/goods-move-list\/([1-9]\d*)$/.exec(u.pathname);
    // Iterátor URLSearchParams stránky není přes Firefox Xray iterovatelný.
    let pocetParametru = 0;
    u.searchParams.forEach(() => { pocetParametru++; });
    const zapnuto = (klic) => ["True", "1"].includes(u.searchParams.get(klic));
    if (u.origin !== puvod || u.username || u.password || u.hash || !m || (ocekavaneId && m[1] !== ocekavaneId)
      || !zapnuto("pdf") || !zapnuto("is_list") || pocetParametru !== 2)
      throw new Error("IC Office vrátil neplatný odkaz skladového PDF.");
    return { id: m[1], url: u.href };
  };
  const existujiciPdf = (doc, id) => {
    const odkazy = [...doc.querySelectorAll("a[href]")].filter((a) => /[?&]pdf=/.test(a.getAttribute("href") ?? ""));
    return odkazy.length ? pdfOdkaz(odkazy[0].getAttribute("href"), id) : null;
  };
  // Marker přežije ztrátu odpovědi i reload. Dokud server nepotvrdí správný doklad,
  // nesmí další běh znovu odeslat POST, ani když předchozí zápis na serveru ještě dobíhá.
  const klicCekajiciho = "ucetni-sestavy:nepotvrzeny-skladovy-pohyb:v1";
  const prectiCekajici = () => {
    let id;
    try { id = globalThis.localStorage.getItem(klicCekajiciho); } catch { throw new Error("Úložiště ochrany před opakováním zápisu není dostupné. Žádný nový skladový doklad nebyl vytvořen."); }
    if (id !== null && !/^[1-9]\d{0,19}$/.test(id)) throw new Error("Úložiště ochrany před opakováním zápisu má neplatný stav. Doplnění dokladů je zablokované; zkontrolujte doklady v IC Office.");
    return id;
  };
  const potvrditCekajici = (id) => {
    if (prectiCekajici() !== id) throw new Error("Změnil se stav ochrany před opakováním zápisu. Další zápisy byly zastaveny.");
    try { globalThis.localStorage.removeItem(klicCekajiciho); } catch { throw new Error("Nepodařilo se potvrdit stav uloženého dokladu. Další zápisy byly zastaveny."); }
    if (prectiCekajici() !== null) throw new Error("Nepodařilo se uvolnit ochranu potvrzeného dokladu. Další zápisy byly zastaveny.");
  };
  const overitCekajici = async () => {
    const id = prectiCekajici();
    if (id === null) return;
    const doc = await dokument(`/warehouse/goods-move-list/${id}`);
    if (!existujiciPdf(doc, id)) throw new Error(`Pohyb ${id}: předchozí zápis dosud není potvrzený. Další doklady nevytvářím. Dokončete nebo ověřte tento doklad přímo v IC Office a načtení spusťte znovu.`);
    potvrditCekajici(id);
  };
  const ulozitCekajici = (id) => {
    if (prectiCekajici() !== null) throw new Error("Zůstal nepotvrzený zápis skladového dokladu. Další zápisy byly zastaveny.");
    try { globalThis.localStorage.setItem(klicCekajiciho, id); } catch { throw new Error("Nelze uložit ochranu před opakováním zápisu. Žádný nový skladový doklad nebyl vytvořen."); }
    if (prectiCekajici() !== id) throw new Error("Nelze ověřit ochranu před opakováním zápisu. Žádný nový skladový doklad nebyl vytvořen.");
  };
  const vytvorit = async (id) => {
    await overitCekajici();
    const cesta = `/warehouse/goods-move-list/${id}`;
    const doc = await dokument(cesta);
    if (existujiciPdf(doc, id)) return;
    const form = doc.getElementById("frm-goodsListForm");
    if (!form || (form.getAttribute("method") ?? "").toLowerCase() !== "post" || new URL(form.getAttribute("action"), puvod).href !== `${puvod}/warehouse/goods-move-list`) throw new Error(`Pohyb ${id}: chybí ověřený formulář pro vytvoření dokladu.`);
    const body = new URLSearchParams();
    for (const prvek of form.querySelectorAll("input, select, textarea")) {
      if (!prvek.name || prvek.disabled || ["submit", "button", "reset", "file"].includes(prvek.type) || (["checkbox", "radio"].includes(prvek.type) && !prvek.checked)) continue;
      if (prvek.tagName === "SELECT" && prvek.multiple) {
        for (const o of prvek.options) if (o.selected) body.append(prvek.name, o.value);
      } else body.append(prvek.name, prvek.value);
    }
    if (body.get("id") !== id || !body.get("number")?.trim() || !body.get("date")?.trim() || !body.get("_do")) throw new Error(`Pohyb ${id}: chybí ID, číslo, datum nebo serverový výchozí údaj. Doklad nebyl vytvořen.`);
    if (!vObdobi(datum(body.get("date"), id))) throw new Error(`Pohyb ${id}: výchozí datum dokladu leží mimo zvolené období. Doklad nebyl vytvořen.`);
    body.set("odeslat", "Vytvořit");
    ulozitCekajici(id);
    let odpoved;
    try { odpoved = await dokument("/warehouse/goods-move-list", { method: "POST", body }); } catch { /* Výsledek zápisu je neurčitý; jedině čerstvé čtení, nikdy druhý POST. */ }
    if (odpoved && text(odpoved.body).includes("Doklad byl vygenerován.") && existujiciPdf(odpoved, id)) {
      potvrditCekajici(id);
      return;
    }
    const overeni = await dokument(cesta);
    if (!existujiciPdf(overeni, id)) throw new Error(`Pohyb ${id}: nelze potvrdit vytvoření dokladu. Další zápisy byly zastaveny; zkontrolujte pohyb v IC Office a import spusťte znovu.`);
    potvrditCekajici(id);
  };
  const vsechnyMesice = (doc) => {
    // DOMParser neprovede inicializaci filtru: bez selected vrací první měsíc, nikoli serverové „Všechny“.
    // Přijímáme jen známý přímý prefix a následné registrace handlerů; žádný skript nespouštíme.
    const skripty = [...doc.querySelectorAll("script")].map((s) => s.textContent ?? "").filter((s) => /inputDate|inputMonths|selectMonths|inputFrom|inputTo|inputSettings|\bmonths\b|#(?:date|from|to|settings)\b|["'](?:date|from|to|settings)["']/.test(s));
    if (skripty.length !== 1) return false;
    const vzor = (s) => new RegExp(`^\\s*${s.trim().split(/\s+/).map((t, i, casti) => `${i ? /[\w$]$/.test(casti[i - 1]) && /^[\w$]/.test(t) ? "\\s+" : "\\s*" : ""}${t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`).join("")}`);
    const prefix = vzor(`$(document).ready(function () {
      let inputDate = $("input#date"); let inputMonths = $("input#months");
      let selectMonths = $("select#months"); let inputFrom = $("input#from");
      let inputTo = $("input#to"); let inputSettings = $("input#settings");
      inputMonths.prop('checked', true); inputDate.prop('checked', false);
      selectMonths.prop('disabled', false); selectMonths.val("0");
      inputFrom.prop('disabled', true); inputTo.prop('disabled', true); inputSettings.prop('disabled', true);`);
    let zbytek = skripty[0];
    const zacatek = prefix.exec(zbytek);
    if (!zacatek) return false;
    zbytek = zbytek.slice(zacatek[0].length);
    const hlavicky = [
      "inputMonths.click(function (e) {", "inputDate.click(function (e) {", "selectMonths.change(function () {",
      '$("#moreModal").on("hide.bs.modal", function () {', '$("#isList").change(function () {',
      '$("#isDL").change(function () {', '$("#moveType").change(function () {',
      '$("input#search").on(\'keypress\', function (e) {', '$("button#search").click(function () {',
      '$("#goodsMoveListModal").on("hide.bs.modal", function () {',
    ];
    for (const hlavicka of hlavicky) {
      const shoda = vzor(hlavicka).exec(zbytek);
      if (!shoda) return false;
      let i = shoda[0].length, retezec = "", komentar = "";
      const zavorky = ["{"];
      for (; i < zbytek.length && zavorky.length; i++) {
        const c = zbytek[i], dalsi = zbytek[i + 1];
        if (retezec) { if (c === "\\") i++; else if (c === retezec) retezec = ""; continue; }
        if (komentar === "//") { if (c === "\n" || c === "\r") komentar = ""; continue; }
        if (komentar === "/*") { if (c === "*" && dalsi === "/") { komentar = ""; i++; } continue; }
        if (c === '"' || c === "'") { retezec = c; continue; }
        if (c === "/" && (dalsi === "/" || dalsi === "*")) { komentar = c + dalsi; i++; continue; }
        // Neznámá syntaxe (např. šablony či regex) se nesmí tvářit jako konec handleru.
        if (c === "`" || c === "/") return false;
        if ("{([".includes(c)) zavorky.push(c);
        else if ("})]".includes(c) && zavorky.pop() !== ({ "}": "{", ")": "(", "]": "[" })[c]) return false;
      }
      if (zavorky.length || retezec || komentar) return false;
      zbytek = zbytek.slice(i);
      const konec = /^\s*\);/.exec(zbytek);
      if (!konec) return false;
      zbytek = zbytek.slice(konec[0].length);
    }
    return /^\s*\}\);\s*$/.test(zbytek);
  };
  const doplnit = async () => {
    await overitCekajici();
    // IC Office si v relaci pamatuje poslední stránku předchozího průchodu.
    let url = `${puvod}/warehouse/goods-move?do=paginationGoodsMove&page=1`;
    const navstivene = new Set();
    const strany = new Set();
    const cekajici = new Map();
    let posledniStrana = 1;
    const pohyby = new Map();
    while (url) {
      if (navstivene.has(url) || navstivene.size >= 100) throw new Error("Neúplné nebo cyklické stránkování skladových pohybů.");
      navstivene.add(url);
      strany.add(Number(new URL(url).searchParams.get("page") ?? 1));
      const doc = await dokument(url);
      // Neměníme nezdokumentovaný filtr skladů. Zápisy povolíme jen nad prokazatelně úplným seznamem.
      const form = doc.getElementById("frm-settingsForm");
      const mesice = doc.querySelector('select[id="months"]');
      const radioDatum = doc.querySelector('input[id="date"]');
      const seznam = doc.getElementById("isList");
      const dl = doc.getElementById("isDL");
      const typ = doc.getElementById("moveType");
      const hledani = [...doc.querySelectorAll('input[type="text"], input[type="search"]')].filter((i) => !["from", "to"].includes(i.name));
      if (!form || !mesice || [...mesice.querySelectorAll("option[selected]")].some((o) => o.value !== "0") || !vsechnyMesice(doc) || !radioDatum || radioDatum.checked || !seznam || seznam.checked || !dl || dl.checked || !typ || typ.value !== "" || hledani.some((i) => i.value.trim())) throw new Error('Pro doplnění dokladů otevřete v IC Office Pohyby zboží, zrušte hledání a filtry, vyberte „Všechny“ a „Všechny pohyby“ a vypněte „S dokladem“ i „Dodací listy“.');
      const tbody = doc.getElementById("snippet--goods_tbody");
      if (!tbody) throw new Error("Chybí seznam skladových pohybů.");
      for (const radek of tbody.querySelectorAll("tr")) {
        const td = [...radek.querySelectorAll("td")];
        if (td.length === 1 && td[0].colSpan > 1) continue;
        if (td.length !== 11) throw new Error("Neznámá struktura skladových pohybů.");
        const a = td[10].querySelector("a.mmcolist");
        const id = a?.getAttribute("data-id");
        if (!/^[1-9]\d*$/.test(id ?? "")) throw new Error("Skladový pohyb nemá platné ID.");
        const d = datum(text(td[1]), id);
        if (pohyby.has(id)) throw new Error("Stránkování opakuje skladový pohyb; úplnost nelze ověřit.");
        if (!["Vytvořit", "Příjemka", "Výdejka"].includes(text(a))) throw new Error("Neznámý stav dokladu skladového pohybu.");
        pohyby.set(id, { d, chybi: text(a) === "Vytvořit" });
      }
      for (const a of doc.querySelectorAll("a[href]")) {
        const href = a.getAttribute("href");
        if (!href?.includes("paginationGoodsMove")) continue;
        const u = new URL(href, puvod);
        const parametry = [];
        u.searchParams.forEach((_, k) => { parametry.push(k); });
        if (u.origin !== puvod || u.username || u.password || u.hash || u.pathname !== "/warehouse/goods-move" || u.searchParams.get("do") !== "paginationGoodsMove" || !/^[1-9]\d*$/.test(u.searchParams.get("page") ?? "") || parametry.some((k) => !["do", "page"].includes(k)) || parametry.length !== 2) throw new Error("Neplatný odkaz stránkování skladu.");
        const cislo = Number(u.searchParams.get("page"));
        if (cislo > 100) throw new Error("Příliš mnoho stran skladových pohybů.");
        posledniStrana = Math.max(posledniStrana, cislo);
        // První stránka může být odkazována také jako page=1.
        if (cislo === 1) continue;
        u.search = new URLSearchParams({ do: "paginationGoodsMove", page: String(cislo) });
        if (!strany.has(cislo)) cekajici.set(cislo, u.href);
      }
      const [nasledujici] = [...cekajici].sort((a, b) => a[0] - b[0]);
      if (nasledujici) cekajici.delete(nasledujici[0]);
      url = nasledujici?.[1];
    }
    if (strany.size !== posledniStrana) throw new Error("Stránkování skladových pohybů vynechalo stránku. Žádný doklad nebyl vytvořen.");
    for (const [id, p] of pohyby) if (p.chybi && vObdobi(p.d)) await vytvorit(id);
  };
  const skladoveSoubory = async () => {
    // Přehled je prázdný, dokud IC Office přes toggle-load (ida=5) nevrátí Nette snippet.
    const odpoved = await fetch("/overview/?do=toggleLoad&ida=5", {
      credentials: "same-origin",
      headers: { "X-Requested-With": "XMLHttpRequest", Accept: "application/json" },
    });
    if (!odpoved.ok || (odpoved.url && new URL(odpoved.url, puvod).origin !== puvod)) throw new Error("IC Office nevrátil přehled vystavených výdejek a příjemek.");
    const data = await odpoved.json();
    const html = data?.snippets?.["snippet--privy_prew"];
    if (typeof html !== "string") throw new Error("IC Office nevrátil přehled vystavených výdejek a příjemek.");
    const doc = new DOMParser().parseFromString(html, "text/html");
    const tabulka = doc.getElementById("datatable_information_vypriskl");
    if (!tabulka) throw new Error("IC Office nevrátil přehled vystavených výdejek a příjemek.");
    const radky = [];
    const ids = new Set();
    for (const radek of tabulka.querySelectorAll("tbody tr")) {
      const td = [...radek.querySelectorAll("td")];
      if (td.length === 1 && td[0].colSpan > 1) continue;
      if (td.length !== 13) throw new Error("Neznámá struktura přehledu skladových dokladů.");
      const a = [...td[12].querySelectorAll("a[href]")].find((a) => /[?&]pdf=/.test(a.getAttribute("href") ?? ""));
      const pdf = pdfOdkaz(a?.getAttribute("href") ?? "");
      const d = datum(text(td[1]), pdf.id);
      if (!vObdobi(d)) throw new Error("IC Office vrátil skladový doklad za jiné období.");
      if (ids.has(pdf.id)) throw new Error("Přehled opakuje skladový doklad.");
      ids.add(pdf.id);
      const typ = text(td[11]);
      const cislo = text(td[2]);
      if (!["Příjem", "Výdej", "Vratka ze zakázky / prodeje"].includes(typ) || !cislo) throw new Error(`Pohyb ${pdf.id}: skladový doklad nemá číslo nebo známý typ.`);
      radky.push({ pdf, d, cislo, typ, hodnoty: [text(td[0]), pdf.id, cislo, d, typ, text(td[3]), text(td[4]), text(td[5]), text(td[6]), text(td[7]), text(td[8]), text(td[9]), text(td[10])] });
      if (radky.length > 1000) throw new Error("Příliš mnoho skladových dokladů; zvolte kratší období.");
    }
    const csvBunka = (s) => /[;"\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    const hlavicka = ["#", "ID pohybu", "Číslo dokladu", "Datum", "Typ", "Klient", "Přidal / Vydal", "Název", "Zakázka", "Faktura", "Objednávka", "Hodnota [bez DPH]", "Hodnota [s DPH]"];
    const csv = "\uFEFF" + [hlavicka, ...radky.map((r) => r.hodnoty)].map((r) => r.map(csvBunka).join(";")).join("\r\n") + "\r\n";
    const soubory = [{ nazev: `Prijemky_vydejky_${odIso}_${doIso}.csv`, data: base64(new TextEncoder().encode(csv)) }];
    const tiskovyPodklad = async (r) => {
      const url = new URL(r.pdf.url);
      url.searchParams.delete("pdf");
      const odpoved = await fetch(url.href, { credentials: "same-origin" });
      if (!odpoved.ok || (odpoved.url && odpoved.url !== url.href) || Number(odpoved.headers.get("content-length")) > 10 * 1024 * 1024) throw new Error("Tiskový podklad není dostupný.");
      const html = await odpoved.text();
      if (new TextEncoder().encode(html).length > 10 * 1024 * 1024) throw new Error("Tiskový podklad překročil 10 MiB.");
      const doc = new DOMParser().parseFromString(html, "text/html");
      const koreny = [...doc.body.children].filter((n) => n.tagName === "DIV");
      if (koreny.length !== 1) throw new Error("Neznámá struktura tiskového podkladu.");
      const koren = koreny[0];
      const nadpis = text(koren.firstElementChild);
      const ocekavanyNadpis = r.typ === "Výdej" ? "Skladová výdejka" : "Skladová příjemka";
      if (nadpis !== `${ocekavanyNadpis} č. ${r.cislo}`) throw new Error("Tiskový podklad má jiné číslo nebo typ dokladu.");
      const tabulky = [...koren.children].filter((n) => n.tagName === "TABLE");
      const bunky = (tr) => [...tr.children].map(text);
      const polozky = tabulky.filter((t) => JSON.stringify(bunky(t.rows[0])) === JSON.stringify(["Název", "Kód", "Množství", "MJ", "J.Cena", "Cena", "%DPH", "DPH", "Celkem"]));
      if (polozky.length !== 1 || polozky[0].rows.length < 2 || [...polozky[0].rows].some((tr) => tr.cells.length !== 9)) throw new Error("Tiskový podklad nemá úplnou tabulku položek.");
      const datumRadky = tabulky.flatMap((t) => [...t.rows]).filter((tr) => text(tr.cells[0]) === "Datum příjemky/výdejky:");
      if (datumRadky.length !== 1 || datum(text(datumRadky[0].cells[1]), r.pdf.id) !== r.d) throw new Error("Tiskový podklad má jiné datum.");
      const soucty = tabulky.flatMap((t) => [...t.rows]).filter((tr) => tr.cells.length === 9 && text(tr.cells[0]) === "Celkem");
      const castka = (s) => {
        const c = s.replace(/\s/g, "").replace(",", ".");
        if (!/^-?\d+(?:\.\d{1,2})?$/.test(c)) throw new Error("Neplatný součet tiskového podkladu.");
        return Math.round(Number(c) * 100);
      };
      if (soucty.length !== 1 || castka(text(soucty[0].cells[5])) !== castka(r.hodnoty[11]) || castka(text(soucty[0].cells[8])) !== castka(r.hodnoty[12])) throw new Error("Součty tiskového podkladu nesouhlasí s přehledem.");
      const radkyPolozek = [...polozky[0].rows].slice(1);
      // Zobrazené řádky jsou zaokrouhlené na haléře, patička vychází z přesnějších hodnot.
      const tolerance = Math.ceil(radkyPolozek.length / 2);
      for (const sloupec of [5, 7, 8]) {
        const soucet = radkyPolozek.reduce((s, tr) => s + castka(text(tr.cells[sloupec])), 0);
        if (Math.abs(soucet - castka(text(soucty[0].cells[sloupec]))) > tolerance) throw new Error("Položkové částky tiskového podkladu nesouhlasí se součty.");
      }
      // Rekonstrukce pouze textu a tabulek. Žádné původní atributy, skripty či vzdálené zdroje.
      const escape = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
      const serializovat = (n) => {
        if (n.nodeType === 3) return escape(n.textContent ?? "");
        if (n.nodeType !== 1) return "";
        const tag = n.tagName.toLowerCase();
        if (["script", "style", "iframe", "object", "embed", "svg", "math", "template"].includes(tag)) return "";
        const obsah = [...n.childNodes].map(serializovat).join("");
        if (!["div", "p", "span", "b", "strong", "i", "em", "table", "thead", "tbody", "tfoot", "tr", "td", "th", "br"].includes(tag)) return obsah;
        if (tag === "br") return "<br>";
        let atributy = tag === "table" ? ' border="1"' : "";
        if (tag === "td" || tag === "th") for (const a of ["colspan", "rowspan"]) {
          const v = n.getAttribute(a);
          if (v && /^[1-9]\d{0,2}$/.test(v)) atributy += ` ${a}="${v}"`;
        }
        return `<${tag}${atributy}>${obsah}</${tag}>`;
      };
      return new TextEncoder().encode(`<!doctype html><html lang="cs"><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'"><title>Skladový doklad ${r.pdf.id}</title></head><body><p>Tiskový podklad z IC Office. Originální PDF není dostupné (HTTP 500). ID pohybu: ${r.pdf.id}.</p>${serializovat(koren)}</body></html>`);
    };
    let celkem = 0;
    for (const r of radky) {
      const odpoved = await fetch(r.pdf.url, { credentials: "same-origin" });
      const oznaceni = `Pohyb ${r.pdf.id}, doklad ${r.cislo} (${r.d})`;
      if (odpoved.url && odpoved.url !== r.pdf.url) throw new Error(`${oznaceni}: PDF přesměrováno mimo očekávaný doklad.`);
      if (odpoved.status === 500) {
        try {
          const bajty = await tiskovyPodklad(r);
          celkem += bajty.length;
          if (bajty.length > 10 * 1024 * 1024 || celkem > 100 * 1024 * 1024) throw new Error("Podklady překročily limit velikosti.");
          soubory.push({ nazev: `Skladovy_doklad_${r.pdf.id}.html`, data: base64(bajty) });
          continue;
        } catch (e) { throw new Error(`${oznaceni}: PDF selhalo (HTTP 500) a nelze ověřit náhradní tiskový podklad. ${e.message}`); }
      }
      if (!odpoved.ok) throw new Error(`${oznaceni}: nelze stáhnout PDF (HTTP ${odpoved.status}).`);
      const delka = Number(odpoved.headers.get("content-length"));
      if (delka > 10 * 1024 * 1024) throw new Error(`${oznaceni}: skladové PDF překročilo velikost 10 MiB.`);
      const bajty = new Uint8Array(await odpoved.arrayBuffer());
      celkem += bajty.length;
      if (bajty.length < 8 || bajty.length > 10 * 1024 * 1024 || celkem > 100 * 1024 * 1024 || [37, 80, 68, 70, 45].some((b, i) => bajty[i] !== b)) throw new Error(`${oznaceni}: neplatné nebo příliš velké PDF.`);
      soubory.push({ nazev: `Skladovy_doklad_${r.pdf.id}.pdf`, data: base64(bajty) });
    }
    return soubory;
  };
  const spustit = async () => {
    const prehled = await dokument("/overview/");
    if (!prehled.getElementById("frm-settingsForm")) return { ok: false, prihlasit: true, chyba: "IC Office není přihlášený. Přihlaste se v jeho kartě a zkuste to znovu." };
    const puvodniOd = prehled.getElementById("from")?.value;
    const puvodniDo = prehled.getElementById("to")?.value;
    if (!puvodniOd || !puvodniDo) throw new Error("Nelze uložit původní období Přehledů IC Office; import nebyl zahájen.");
    try {
      if (doplnitDoklady) await doplnit();
      await nastavitObdobi(od, doDne);
      const soubory = [];
      for (const signal of exporty) {
        const cesta = `/overview/?do=${signal}`;
        const odpoved = await fetch(cesta, { credentials: "same-origin" });
        const nazev = /filename="?([^";]+)/.exec(odpoved.headers.get("content-disposition") ?? "")?.[1];
        if (!odpoved.ok || !nazev) {
          if (pouzeExcel) throw new Error("IC Office neposkytl soubor Excel za zvolené období. Ověřte dostupnost exportu v jeho Přehledech.");
          throw new Error(`IC Office nevrátil export ${signal}.`);
        }
        if (!nazev.includes(`_${odIso}_${doIso}.`)) throw new Error(`IC Office vrátil export za jiné období: ${nazev}`);
        if (pouzeExcel && ((odpoved.url && odpoved.url !== puvod + cesta) || !/\.xlsx$/i.test(nazev)
          || /[\\/\r\n]/.test(nazev) || Number(odpoved.headers.get("content-length")) > 50 * 1024 * 1024))
          throw new Error("IC Office nevrátil platný export Excel do 50 MiB.");
        const bajty = new Uint8Array(await odpoved.arrayBuffer());
        if (pouzeExcel && (bajty.length > 50 * 1024 * 1024 || [80, 75, 3, 4].some((bajt, i) => bajty[i] !== bajt)))
          throw new Error("IC Office vrátil jiný obsah než platný soubor XLSX do 50 MiB.");
        soubory.push({ nazev, data: base64(bajty) });
      }
      if (!pouzeExcel) soubory.push(...await skladoveSoubory());
      return { ok: true, soubory };
    } finally {
      if (puvodniOd && puvodniDo && (puvodniOd !== od || puvodniDo !== doDne)) await nastavitObdobi(puvodniOd, puvodniDo);
    }
  };
  try {
    // Originový zámek koordinuje i více karet/instalací; neukládá data a po běhu se uvolní.
    if (globalThis.navigator?.locks?.request) {
      // Firefox potřebuje callback v realmu stránky (Mozilla 1873028).
      // Exportujeme jen neveřejný callback; data a práce zůstávají v sandboxu doplňku.
      let vysledek, chyba;
      let selhalo = false;
      const seZamkem = (zamek) => {
        if (!zamek) {
          vysledek = { ok: false, chyba: "Načítání z IC Office už probíhá v jiné kartě." };
          return;
        }
        return new window.Promise((hotovo) => {
          void (async () => {
            try { vysledek = await spustit(); }
            catch (e) { chyba = e; selhalo = true; }
            finally { hotovo(); }
          })();
        });
      };
      const callback = typeof exportFunction === "function" ? exportFunction(seZamkem, window) : seZamkem;
      await navigator.locks.request("ucetni-sestavy-ic-office-import", { ifAvailable: true }, callback);
      if (selhalo) throw chyba;
      return vysledek;
    }
    if (pouzeExcel || doplnitDoklady) throw new Error("Prohlížeč neposkytuje zámek pro bezpečné nastavení období. Aktualizujte prohlížeč.");
    return await spustit();
  } catch (e) {
    return { ok: false, chyba: `Spojení s IC Office selhalo: ${e.message}` };
  }
}

// Plán automatického odeslání účetní. Stránka sestav předá čas; doplněk ji po něm jednou denně
// otevře na pozadí. Co a zda odeslat (pracovní den, už odesláno) rozhodne stránka sama a ohlásí
// výsledek: po úspěchu se karta zavře, s chybou zůstane otevřená, aby ji uživatel viděl.
// Bez ověřitelné identity firmy se nesmí spustit ani dříve uložený plán.
const AUTOMAT_POZASTAVEN = true;
const BUDIK = "odeslani-ucetni";
const STRANKA_AUTOMATU = `${POVOLENY_PUVOD}/sestavy/?auto=odeslat#export`;
const dvoj = (n) => String(n).padStart(2, "0");

api.runtime.onMessage.addListener((zprava, odesilatel) => {
  if (!zeSestav(odesilatel)) return;
  if (zprava?.typ === "plan") void ulozitPlan(zprava);
  if (zprava?.typ === "automat-hotovo")
    void dokoncitAutomat(zprava.ok === true, odesilatel.tab?.id);
});
api.runtime.onStartup.addListener(() => void nastavitBudik());
api.runtime.onInstalled.addListener(() => void nastavitBudik());
api.alarms.onAlarm.addListener((a) => {
  if (a.name === BUDIK) void zkontrolovatPlan();
});

async function ulozitPlan(z) {
  const plan = {
    zapnuto: !AUTOMAT_POZASTAVEN && z.zapnuto === true,
    cas: /^([01]\d|2[0-3]):[0-5]\d$/.test(z.cas) ? z.cas : "07:00",
  };
  await api.storage.local.set({ plan });
  await nastavitBudik();
}

// Budík každých 15 minut přežije restart prohlížeče; po startu se zmeškaný čas dožene.
async function nastavitBudik() {
  const { plan } = await api.storage.local.get("plan");
  if (AUTOMAT_POZASTAVEN || !plan?.zapnuto) return api.alarms.clear(BUDIK);
  if (!(await api.alarms.get(BUDIK)))
    await api.alarms.create(BUDIK, { delayInMinutes: 1, periodInMinutes: 15 });
}

async function zkontrolovatPlan() {
  const { plan, spusteno } = await api.storage.local.get(["plan", "spusteno"]);
  if (AUTOMAT_POZASTAVEN || !plan?.zapnuto) return;
  const ted = new Date();
  const dnes = `${ted.getFullYear()}-${dvoj(ted.getMonth() + 1)}-${dvoj(ted.getDate())}`;
  if (`${dvoj(ted.getHours())}:${dvoj(ted.getMinutes())}` < plan.cas || spusteno === dnes)
    return;
  // Zapíše se před otevřením, aby další budík stránku ten den znovu neotevřel.
  await api.storage.local.set({ spusteno: dnes });
  const karta = await api.tabs.create({ url: STRANKA_AUTOMATU, active: false });
  await api.storage.session.set({ kartaAutomatu: karta.id });
}

async function dokoncitAutomat(ok, idKarty) {
  const { kartaAutomatu } = await api.storage.session.get("kartaAutomatu");
  if (!ok || idKarty == null || idKarty !== kartaAutomatu) return;
  await api.storage.session.remove("kartaAutomatu");
  await api.tabs.remove(idKarty).catch(() => {});
}
