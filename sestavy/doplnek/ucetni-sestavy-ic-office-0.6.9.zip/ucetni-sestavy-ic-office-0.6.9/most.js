const api = globalThis.browser ?? globalThis.chrome;
// Most mezi stránkou Účetních sestav a doplňkem. Stránka smí požádat o období nebo katalog,
// předat plán odesílání a ohlásit jeho výsledek; adresy exportů a cíl stahování určuje doplněk sám.
const ZDROJ = "ic-office-doplnek";

function oznamit() {
  window.postMessage(
    {
      zdroj: ZDROJ,
      typ: "pripraven",
      verze: api.runtime.getManifest().version,
    },
    location.origin,
  );
}

window.addEventListener("message", (u) => {
  if (u.source !== window || u.origin !== location.origin) return;
  const z = u.data;
  if (z?.zdroj !== "ucetni-sestavy") return;
  if (z.typ === "zjistit") oznamit();
  if (z.typ === "plan" || z.typ === "automat-hotovo") {
    api.runtime
      .sendMessage({ typ: z.typ, zapnuto: z.zapnuto, cas: z.cas, ok: z.ok })
      .catch(() => {});
    return;
  }
  const typy = {
    nacist: "vysledek",
    "nacist-katalog": "vysledek-katalog",
    "nacist-rozpracovanost": "vysledek-rozpracovanost",
    "nacist-kontrolni-export": "vysledek-kontrolni-export",
  };
  if (!Object.hasOwn(typy, z.typ)) return;
  const odpovedet = (v) =>
    window.postMessage(
      { ...v, zdroj: ZDROJ, typ: typy[z.typ], id: z.id },
      location.origin,
    );
  const zprava = { typ: z.typ };
  if (z.typ === "nacist") {
    Object.assign(zprava, { od: z.od, do: z.do, doplnitDoklady: z.doplnitDoklady === true && z.automaticky !== true, automaticky: z.automaticky === true });
  } else if (z.typ === "nacist-rozpracovanost") {
    Object.assign(zprava, { polozky: z.polozky === true, nakupniCeny: z.nakupniCeny === true });
  } else if (z.typ === "nacist-kontrolni-export") {
    Object.assign(zprava, { od: z.od, do: z.do, druh: z.druh });
  }
  api.runtime
    .sendMessage(zprava)
    .then(odpovedet, (e) =>
      odpovedet({ ok: false, chyba: `Doplněk selhal: ${e?.message ?? e}` }),
    );
});

oznamit();
