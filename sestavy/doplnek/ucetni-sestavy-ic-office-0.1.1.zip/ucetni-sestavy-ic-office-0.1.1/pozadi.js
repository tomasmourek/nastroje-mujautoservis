// Stáhne exporty za zvolený měsíc z otevřené a přihlášené karty IC Office a vrátí je stránce sestav.
// Heslo ani data nikam neukládá; stahuje se pod přihlášením uživatele přímo z karty IC Office.
const IC_OFFICE = "https://ic-office.eu";
const POVOLENY_PUVOD = "https://nastroje.mujautoservis.eu";

// Signály tlačítek „Export Excel“ na stránce Přehledy (/overview/). Pořadí odpovídá druhům v sestavách:
// faktury, položky faktur, pokladna, naskladněné zboží, vydané zboží, mechanici.
const EXPORTY = [
  "exportInvoicesExcel",
  "exportInvoicesItemsExcel",
  "exportCashboxExcel",
  "exportGoodsImportExcel",
  "exportGoodsMinusExcel",
  "exportMechanicsItemsContracts",
];

let bezi = false;

chrome.runtime.onMessage.addListener((zprava, odesilatel, odpovedet) => {
  if (zprava?.typ !== "nacist") return;
  if (odesilatel.origin !== POVOLENY_PUVOD) {
    odpovedet({
      ok: false,
      chyba: "Žádost nepřišla ze stránky Účetních sestav.",
    });
    return;
  }
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(zprava.mesic)) {
    odpovedet({ ok: false, chyba: "Neplatný měsíc." });
    return;
  }
  // Druhý souběžný běh by v IC Office přepsal období prvnímu.
  if (bezi) {
    odpovedet({ ok: false, chyba: "Načítání z IC Office už probíhá." });
    return;
  }
  bezi = true;
  nacist(zprava.mesic)
    .then(odpovedet, (e) => odpovedet({ ok: false, chyba: e.message }))
    .finally(() => {
      bezi = false;
    });
  return true;
});

async function nacist(mesic) {
  // Uspanou kartu (úspora paměti) ani rozpracovanou nelze skriptovat; zkusí se naposledy použité.
  const karty = (
    await chrome.tabs.query({ url: `${IC_OFFICE}/*`, discarded: false })
  )
    .filter((k) => k.status === "complete")
    .sort((a, b) => (b.lastAccessed ?? 0) - (a.lastAccessed ?? 0));
  if (!karty.length) {
    throw new Error(
      "Otevřete IC Office v jiné kartě tohoto prohlížeče, přihlaste se a zkuste to znovu.",
    );
  }
  // Chyba vložení skriptu nastane dřív, než se v IC Office cokoli změní, takže lze zkusit další kartu.
  let chyba;
  for (const karta of karty) {
    try {
      const [vysledek] = await chrome.scripting.executeScript({
        target: { tabId: karta.id },
        func: stahnoutExporty,
        args: [mesic, EXPORTY],
      });
      return (
        vysledek?.result ?? {
          ok: false,
          chyba: "Karta IC Office neodpověděla.",
        }
      );
    } catch (e) {
      chyba = e;
    }
  }
  throw new Error(
    `Doplněk se nedostal do karty IC Office. Obnovte kartu IC Office, zkontrolujte, že má doplněk v Chrome povolený přístup k ic-office.eu, a zkuste to znovu. (${chyba.message})`,
  );
}

// Běží v kartě IC Office, proto musí být soběstačná. Nastaví období měsíce, stáhne exporty
// a vrátí původní období, i když stahování selže.
async function stahnoutExporty(mesic, exporty) {
  const [rok, m] = mesic.split("-").map(Number);
  const dvoj = (n) => String(n).padStart(2, "0");
  const od = `01.${dvoj(m)}.${rok}`;
  const doDne = `${new Date(rok, m, 0).getDate()}.${dvoj(m)}.${rok}`;
  const iso = (d) => d.split(".").reverse().join("-");
  const nastavitObdobi = (z, k) =>
    fetch("/overview/", {
      method: "POST",
      credentials: "same-origin",
      body: new URLSearchParams({
        from: z,
        to: k,
        settings: "Filtrovat",
        _do: "settingsForm-submit",
      }),
    });
  const base64 = (bajty) => {
    let s = "";
    for (let i = 0; i < bajty.length; i += 0x8000) {
      s += String.fromCharCode(...bajty.subarray(i, i + 0x8000));
    }
    return btoa(s);
  };

  try {
    const prehled = new DOMParser().parseFromString(
      await (await fetch("/overview/", { credentials: "same-origin" })).text(),
      "text/html",
    );
    if (!prehled.getElementById("frm-settingsForm")) {
      return {
        ok: false,
        chyba:
          "IC Office není přihlášený. Přihlaste se v jeho kartě a zkuste to znovu.",
      };
    }
    const puvodniOd = prehled.getElementById("from")?.value;
    const puvodniDo = prehled.getElementById("to")?.value;

    await nastavitObdobi(od, doDne);
    try {
      const soubory = [];
      for (const signal of exporty) {
        const odpoved = await fetch(`/overview/?do=${signal}`, {
          credentials: "same-origin",
        });
        const nazev = /filename="?([^";]+)/.exec(
          odpoved.headers.get("content-disposition") ?? "",
        )?.[1];
        if (!odpoved.ok || !nazev) {
          return { ok: false, chyba: `IC Office nevrátil export ${signal}.` };
        }
        // IC Office píše období do názvu souboru; jiné období znamená, že se filtr nenastavil.
        if (!nazev.includes(`_${iso(od)}_${iso(doDne)}.`)) {
          return {
            ok: false,
            chyba: `IC Office vrátil export za jiné období: ${nazev}`,
          };
        }
        soubory.push({
          nazev,
          data: base64(new Uint8Array(await odpoved.arrayBuffer())),
        });
      }
      return { ok: true, soubory };
    } finally {
      if (puvodniOd && puvodniDo && (puvodniOd !== od || puvodniDo !== doDne)) {
        await nastavitObdobi(puvodniOd, puvodniDo);
      }
    }
  } catch (e) {
    return { ok: false, chyba: `Spojení s IC Office selhalo: ${e.message}` };
  }
}
