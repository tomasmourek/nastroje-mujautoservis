// Most mezi stránkou Účetních sestav a doplňkem. Stránka smí jen požádat o načtení měsíce;
// adresy exportů a cíl stahování určuje doplněk sám.
const ZDROJ = "ic-office-doplnek";

function oznamit() {
  window.postMessage(
    {
      zdroj: ZDROJ,
      typ: "pripraven",
      verze: chrome.runtime.getManifest().version,
    },
    location.origin,
  );
}

window.addEventListener("message", (u) => {
  if (u.source !== window || u.origin !== location.origin) return;
  const z = u.data;
  if (z?.zdroj !== "ucetni-sestavy") return;
  if (z.typ === "zjistit") oznamit();
  if (z.typ !== "nacist" || typeof z.mesic !== "string") return;
  const odpovedet = (v) =>
    window.postMessage(
      { zdroj: ZDROJ, typ: "vysledek", id: z.id, ...v },
      location.origin,
    );
  chrome.runtime
    .sendMessage({ typ: "nacist", mesic: z.mesic })
    .then(odpovedet, (e) =>
      odpovedet({ ok: false, chyba: `Doplněk selhal: ${e?.message ?? e}` }),
    );
});

oznamit();
