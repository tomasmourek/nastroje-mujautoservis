const api = globalThis.browser ?? globalThis.chrome;
// Most mezi stránkou Účetních sestav a doplňkem. Stránka smí jen požádat o načtení období,
// předat plán odesílání a ohlásit jeho výsledek; adresy exportů a cíl stahování určuje doplněk sám.
const ZDROJ = "ic-office-doplnek";

function oznamit() {
  window.postMessage(
    {
      zdroj: ZDROJ,
      typ: "pripraven",
      verze: api.runtime.getManifest().version,
    },
    location.origin,
  );
}

window.addEventListener("message", (u) => {
  if (u.source !== window || u.origin !== location.origin) return;
  const z = u.data;
  if (z?.zdroj !== "ucetni-sestavy") return;
  if (z.typ === "zjistit") oznamit();
  if (z.typ === "plan" || z.typ === "automat-hotovo") {
    api.runtime
      .sendMessage({ typ: z.typ, zapnuto: z.zapnuto, cas: z.cas, ok: z.ok })
      .catch(() => {});
    return;
  }
  if (z.typ !== "nacist") return;
  const odpovedet = (v) =>
    window.postMessage(
      { zdroj: ZDROJ, typ: "vysledek", id: z.id, ...v },
      location.origin,
    );
  api.runtime
    .sendMessage({ typ: "nacist", od: z.od, do: z.do, doplnitDoklady: z.doplnitDoklady === true && z.automaticky !== true, automaticky: z.automaticky === true })
    .then(odpovedet, (e) =>
      odpovedet({ ok: false, chyba: `Doplněk selhal: ${e?.message ?? e}` }),
    );
});

oznamit();
