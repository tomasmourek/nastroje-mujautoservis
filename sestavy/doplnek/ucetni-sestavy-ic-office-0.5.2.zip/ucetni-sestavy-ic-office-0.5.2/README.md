# Doplněk: načtení z IC Office (verze 0.5.2)

Doplněk pro Chrome, Edge a Firefox 140+, který z otevřené a přihlášené karty IC Office stáhne šest exportů, přehled skladových dokladů a jejich původní PDF za zvolené období, od jednoho dne po celý měsíc nebo delší rozsah, a předá je Účetním sestavám na `https://nastroje.mujautoservis.eu/sestavy/`. V sestavách se pak na obrazovce Načtení objeví pole Od a Do a tlačítko „Načíst z IC Office“.

## Instalace (ručně, bez obchodu)

ZIP ke stažení je na obrazovce Načtení v sestavách; po rozbalení vznikne složka `ucetni-sestavy-ic-office-<verze>`.

Při aktualizaci nejprve ve správě doplňků odeberte starou verzi a potom načtěte novou. Ponechte aktivní jen jeden doplněk, jinak mohou oba současně zpracovat žádost o import.

1. Otevřete `chrome://extensions` (v Edge `edge://extensions`).
2. Zapněte Režim pro vývojáře.
3. Klikněte na Načíst rozbalené a vyberte tuto složku (v repozitáři `doplnek`, ze ZIPu rozbalenou složku).
4. Otevřete sestavy. IC Office nemusí být otevřený, stačí, když si prohlížeč pamatuje přihlášení.

## Firefox 140 a novější

Stejný ZIP rozbalte. Otevřete `about:debugging#/runtime/this-firefox`, klikněte na Načíst dočasný doplněk a vyberte `manifest.json` z rozbalené složky. Pak obnovte sestavy a přihlaste se do IC Office ve stejném Firefoxu; přihlášení z Chrome se nepřenáší.

Dočasný doplněk se po ukončení Firefoxu odstraní. Trvalá běžná instalace není zatím dostupná: balíček musí podepsat Mozilla. Podpis, distribuce přes AMO ani skutečný import ve Firefoxu zatím nejsou doložené. Manifest před případným podáním na AMO musí doplnit odpovídající deklaraci přenosu dat.

## Co dělá

- Použije naposledy použitou kartu IC Office, která do 5 s odpoví na krátký test; zmrazené karty na pozadí a karty s otevřeným dialogem přeskočí. Když žádná vhodná není, otevře IC Office v nové kartě na pozadí a po načtení ji zavře. Když v ní uživatel není přihlášený, kartu nechá otevřenou, přepne se na ni a požádá o přihlášení.
- V kartě IC Office načte stránku Přehledy, zapamatuje si nastavené období, nastaví zvolené období a stáhne exporty `exportInvoicesExcel`, `exportInvoicesItemsExcel`, `exportCashboxExcel`, `exportGoodsImportExcel`, `exportGoodsMinusExcel` a `exportMechanicsItemsContracts`.
- Navíc vyčte panel „Vystavené výdejky a příjemky u skladů“ do UTF-8 CSV s BOM, číslem dokladu a stabilním ID pohybu. Každé příjemce/výdejce přiloží původní PDF jako `Skladovy_doklad_<ID_pohybu>.pdf`. Prázdné období vrátí CSV jen s hlavičkou. Ověří ID, období, typ, unikátnost dokladů a podpis `%PDF-`; PDF má nejvýše 10 MiB, celá dávka PDF nejvýše 100 MB a 1000 dokladů. Při chybě nevrací neúplnou dávku.
- Ověří, že IC Office vrátil soubor za požadované období (datum je v názvu souboru), a nakonec vrátí původní období.
- Soubory předá jen stránce sestav. Nikam jinam je neposílá a neukládá obsah dokladů ani heslo. Před vytvořením dokladu do úložiště IC Office uloží pouze ID pohybu pro ochranu před opakováním neurčitého zápisu.
- Automatické odeslání účetní je ve stránce sestav pozastavené: exportní protokol IC Office neposkytuje ověřitelnou identitu firmy a naposledy použitá karta může patřit jiné firmě. Doplněk od verze 0.4.0 nespouští ani dříve uložený plán a vypne jeho budík; stránka při registraci posílá vypnutý plán. Případná starší již otevřená automatická karta nenačte exporty ani neodešle podklady. Ruční načtení a výslovné odeslání zůstává dostupné; uživatel musí ověřit firmu i adresáta.
- Při výslovném zaškrtnutí doplnění dokladů stránka předá `doplnitDoklady: true` (výchozí hodnota je `false`). Automatický požadavek doklady nikdy nevytváří. Doplněk projde všechny stránky Pohybů zboží a v požadovaném období vytvoří pouze chybějící doklady. Skladový filtr musí být bez hledání, „Všechny“, „Všechny pohyby“, bez „S dokladem“ i „Dodací listy“; jinak doplnění odmítne, aby nevynechal část pohybů. Filtr skladů sám nemění.
- Každý zápis předchází čerstvé načtení pohybu. Doplněk použije výhradně číslo, datum a ostatní výchozí hodnoty serveru. Existující doklad neupravuje. Před POST uloží a přečtením ověří technický marker pouze s ID pohybu. POST neopakuje: při přerušení spojení ověří výsledek čtením, a pokud jej nepotvrdí, zastaví další zápisy. Marker přežije reload i další import; každý nový zapisující běh nejprve ověří správný doklad v IC Office a bez potvrzeného PDF neodešle žádný další POST. Marker odstraní pouze po potvrzení PDF. Nedostupné nebo chybné úložiště zápisy zablokuje; běžné načtení již vystavených dokladů funguje dál. Již vytvořené doklady v IC Office zůstanou, i když pozdější stahování selže; nový import je rozpozná a znovu nevytvoří.
- Běh chrání také Web Lock sdílený mezi kartami stejného originu; při zámku jiné karty požadavek odmítne. Bez podpory zámku doplnění nepovolí. Ztráta odpovědi zapisující karty nespustí běh v jiné kartě. Zámek nekoordinuje jiné prohlížeče, profily ani ruční souběžnou práci jiného uživatele v IC Office.
- Stránka sestav smí požádat jen o období (platná data ve tvaru RRRR-MM-DD, začátek nejpozději v den konce). Adresy exportů jsou pevně v `pozadi.js`, žádost odjinud než z `nastroje.mujautoservis.eu` doplněk odmítne a souběžné načítání nepustí.

## Technické úložiště ochrany zápisu

Pouze při výslovném doplnění chybějících dokladů se v `localStorage` originu `https://ic-office.eu` používá klíč `ucetni-sestavy:nepotvrzeny-skladovy-pohyb:v1`. Hodnotou je jediné číselné ID pohybu, bez kontaktů, částek, hesel nebo obsahu dokladu. Slouží výhradně k zabránění druhému POST při ztracené odpovědi serveru. Nemá časovou expiraci: odstraní se až po prokázání PDF příslušného dokladu. Při nepotvrzeném výsledku je nutné doklad ověřit či dokončit přímo v IC Office a načíst znovu; marker se při neúspěchu automaticky nemaže. Skutečné chování tohoto úložiště v instalovaném doplňku zatím nebylo živě ověřeno.

## Ověření 0.5.0

Syntetické testy pokrývají stránkování a období, existující doklad, opakované načtení, ztrátu odpovědi po POST bez opakování zápisu, částečné selhání, nesprávné ID/URL, CSV s BOM a uvozovkami, neplatné PDF a obsazený zámek. Další testy ověřují přetrvání nepotvrzeného zápisu přes nový kontext, zákaz druhého POST při opožděném dokončení serveru, pozdější potvrzení a obnovení zápisů i bezpečné odmítnutí při nedostupném, nefunkčním nebo chybném úložišti; read-only import úložiště nepotřebuje. Nenahrazují skutečný import s instalovanou verzí 0.5.0. Web Locks: [dokumentace Mozilly](https://developer.mozilla.org/en-US/docs/Web/API/Web_Locks_API).

## Omezení

- Verze 0.5.2 rozpoznává známou inicializaci filtru „Všechny“ přímo v HTML skriptu IC Office, protože DOMParser skript neprovádí. Skript nespouští; neznámé nebo rozporné nastavení dál blokuje vystavování. Sestavy zároveň zachovávají české desetinné částky a počáteční nuly čísel dokladů při čtení CSV. Skutečné ověření obou oprav zatím čeká na aktualizaci produkce a instalovaného doplňku.

- Verze 0.5.1 opravuje skutečně zjištěné selhání 0.5.0: IC Office vrací seznam skladových dokladů až dodatečným AJAX požadavkem při rozbalení přehledu. Doplněk načítá tento přehled přes stejný požadavek; vadná nebo chybějící odpověď nepředá částečnou dávku. Regresní testy modelují prázdnou úvodní sekci a samostatnou odpověď se seznamem.

- Verze 0.4.1 opravuje chybu Firefoxu `Permission denied to access property "constructor"` při převodu staženého souboru na base64. Cílený test simuluje zakázaný přístup k `constructor`; skutečný import ve Firefoxu po opravě ještě nebyl ověřen.

- Faktury IC Office filtruje podle data vytvoření. Přepínač „Filtr podle datumu DUZP“ na stránce Přehledy nemá v IC Office funkční skript, proto ho doplněk nepoužívá.
- Doplněk závisí na podobě stránky Přehledy v IC Office; když ji Inter Cars změní, je potřeba ho upravit.
- Funguje jen na produkční adrese sestav, ne na místním vývojovém serveru.
