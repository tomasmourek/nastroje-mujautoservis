// Stáhne exporty za zvolené období z otevřené a přihlášené karty IC Office a vrátí je stránce sestav.
// Heslo ani data nikam neukládá; stahuje se pod přihlášením uživatele přímo z karty IC Office.
const IC_OFFICE = "https://ic-office.eu";
const POVOLENY_PUVOD = "https://nastroje.mujautoservis.eu";

// Signály tlačítek „Export Excel“ na stránce Přehledy (/overview/). Pořadí odpovídá druhům v sestavách:
// faktury, položky faktur, pokladna, naskladněné zboží, vydané zboží, mechanici.
const EXPORTY = [
  "exportInvoicesExcel",
  "exportInvoicesItemsExcel",
  "exportCashboxExcel",
  "exportGoodsImportExcel",
  "exportGoodsMinusExcel",
  "exportMechanicsItemsContracts",
];

let bezi = false;

chrome.runtime.onMessage.addListener((zprava, odesilatel, odpovedet) => {
  if (zprava?.typ !== "nacist") return;
  if (odesilatel.origin !== POVOLENY_PUVOD) {
    odpovedet({
      ok: false,
      chyba: "Žádost nepřišla ze stránky Účetních sestav.",
    });
    return;
  }
  if (!platneObdobi(zprava.od, zprava.do)) {
    odpovedet({ ok: false, chyba: "Neplatné období." });
    return;
  }
  // Druhý souběžný běh by v IC Office přepsal období prvnímu.
  if (bezi) {
    odpovedet({ ok: false, chyba: "Načítání z IC Office už probíhá." });
    return;
  }
  bezi = true;
  nacist(zprava.od, zprava.do)
    .then(odpovedet, (e) => odpovedet({ ok: false, chyba: e.message }))
    .finally(() => {
      bezi = false;
    });
  return true;
});

// Období ve tvaru RRRR-MM-DD, skutečná data a začátek nejpozději v den konce.
function platneObdobi(od, doDne) {
  const datum = (d) =>
    typeof d === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(d) &&
    new Date(`${d}T00:00:00Z`).toISOString().startsWith(d);
  return datum(od) && datum(doDne) && od <= doDne;
}

async function nacist(od, doDne) {
  // Uspanou kartu (úspora paměti) ani rozpracovanou nelze skriptovat; zkusí se naposledy použité.
  const karty = (
    await chrome.tabs.query({ url: `${IC_OFFICE}/*`, discarded: false })
  )
    .filter((k) => k.status === "complete")
    .sort((a, b) => (b.lastAccessed ?? 0) - (a.lastAccessed ?? 0));
  // Zmrazená karta na pozadí nebo karta s otevřeným dialogem skript nespustí a čekalo by se
  // na ni donekonečna, proto se použije jen karta, která odpoví na krátký test.
  let chyba;
  for (const karta of karty) {
    try {
      if (!(await odpovida(karta.id))) continue;
      return await stahnoutVKarte(karta.id, od, doDne);
    } catch (e) {
      chyba = e;
    }
  }
  if (chyba) throw nedostalSe(chyba);
  return nacistVNoveKarte(od, doDne);
}

// Ověří, že karta spustí skript do 5 s. Chyba vložení (například chybějící oprávnění) se předá dál.
function odpovida(idKarty) {
  return Promise.race([
    chrome.scripting
      .executeScript({ target: { tabId: idKarty }, func: () => true })
      .then(([v]) => v?.result === true),
    new Promise((splnit) => setTimeout(() => splnit(false), 5_000)),
  ]);
}

const nedostalSe = (e) =>
  new Error(
    `Doplněk se nedostal do karty IC Office. Obnovte kartu IC Office, zkontrolujte, že má doplněk v Chrome povolený přístup k ic-office.eu, a zkuste to znovu. (${e.message})`,
  );

async function stahnoutVKarte(idKarty, od, doDne) {
  const [vysledek] = await chrome.scripting.executeScript({
    target: { tabId: idKarty },
    func: stahnoutExporty,
    args: [od, doDne, EXPORTY],
  });
  return (
    vysledek?.result ?? { ok: false, chyba: "Karta IC Office neodpověděla." }
  );
}

// Bez otevřené karty otevře IC Office na pozadí. Přihlášení si pamatuje prohlížeč; když chybí,
// karta zůstane otevřená a přepne se na ni, aby se uživatel mohl přihlásit. Jinak se zavře.
async function nacistVNoveKarte(od, doDne) {
  const karta = await chrome.tabs.create({
    url: `${IC_OFFICE}/overview/`,
    active: false,
  });
  let ponechat = false;
  try {
    await nactena(karta.id);
    const v = await stahnoutVKarte(karta.id, od, doDne).catch((e) => {
      throw nedostalSe(e);
    });
    if (v.prihlasit) {
      ponechat = true;
      await chrome.tabs.update(karta.id, { active: true });
      return {
        ok: false,
        chyba:
          "Otevřel jsem IC Office v nové kartě, ale nejste v něm přihlášení. Přihlaste se v ní a zkuste to znovu.",
      };
    }
    return v;
  } finally {
    if (!ponechat) await chrome.tabs.remove(karta.id).catch(() => {});
  }
}

// Počká, až se karta dočte, nejdéle 30 s.
function nactena(idKarty) {
  return new Promise((splnit, selhat) => {
    const konec = () => {
      chrome.tabs.onUpdated.removeListener(zmena);
      clearTimeout(casovac);
    };
    const zmena = (id, info) => {
      if (id !== idKarty || info.status !== "complete") return;
      konec();
      splnit();
    };
    const casovac = setTimeout(() => {
      konec();
      selhat(new Error("IC Office se nepodařilo otevřít včas."));
    }, 30_000);
    chrome.tabs.onUpdated.addListener(zmena);
    // Karta se mohla dočíst dřív, než se přihlásil posluchač.
    chrome.tabs.get(idKarty).then((k) => {
      if (k.status !== "complete") return;
      konec();
      splnit();
    }, selhat);
  });
}

// Běží v kartě IC Office, proto musí být soběstačná. Nastaví zvolené období (RRRR-MM-DD),
// stáhne exporty a vrátí původní období, i když stahování selže.
async function stahnoutExporty(odIso, doIso, exporty) {
  const cz = (d) => d.split("-").reverse().join(".");
  const od = cz(odIso);
  const doDne = cz(doIso);
  const nastavitObdobi = (z, k) =>
    fetch("/overview/", {
      method: "POST",
      credentials: "same-origin",
      body: new URLSearchParams({
        from: z,
        to: k,
        settings: "Filtrovat",
        _do: "settingsForm-submit",
      }),
    });
  const base64 = (bajty) => {
    let s = "";
    for (let i = 0; i < bajty.length; i += 0x8000) {
      s += String.fromCharCode(...bajty.subarray(i, i + 0x8000));
    }
    return btoa(s);
  };

  try {
    const prehled = new DOMParser().parseFromString(
      await (await fetch("/overview/", { credentials: "same-origin" })).text(),
      "text/html",
    );
    if (!prehled.getElementById("frm-settingsForm")) {
      return {
        ok: false,
        prihlasit: true,
        chyba:
          "IC Office není přihlášený. Přihlaste se v jeho kartě a zkuste to znovu.",
      };
    }
    const puvodniOd = prehled.getElementById("from")?.value;
    const puvodniDo = prehled.getElementById("to")?.value;

    await nastavitObdobi(od, doDne);
    try {
      const soubory = [];
      for (const signal of exporty) {
        const odpoved = await fetch(`/overview/?do=${signal}`, {
          credentials: "same-origin",
        });
        const nazev = /filename="?([^";]+)/.exec(
          odpoved.headers.get("content-disposition") ?? "",
        )?.[1];
        if (!odpoved.ok || !nazev) {
          return { ok: false, chyba: `IC Office nevrátil export ${signal}.` };
        }
        // IC Office píše období do názvu souboru; jiné období znamená, že se filtr nenastavil.
        if (!nazev.includes(`_${odIso}_${doIso}.`)) {
          return {
            ok: false,
            chyba: `IC Office vrátil export za jiné období: ${nazev}`,
          };
        }
        soubory.push({
          nazev,
          data: base64(new Uint8Array(await odpoved.arrayBuffer())),
        });
      }
      return { ok: true, soubory };
    } finally {
      if (puvodniOd && puvodniDo && (puvodniOd !== od || puvodniDo !== doDne)) {
        await nastavitObdobi(puvodniOd, puvodniDo);
      }
    }
  } catch (e) {
    return { ok: false, chyba: `Spojení s IC Office selhalo: ${e.message}` };
  }
}

// Plán automatického odeslání účetní. Stránka sestav předá čas; doplněk ji po něm jednou denně
// otevře na pozadí. Co a zda odeslat (pracovní den, už odesláno) rozhodne stránka sama a ohlásí
// výsledek: po úspěchu se karta zavře, s chybou zůstane otevřená, aby ji uživatel viděl.
const BUDIK = "odeslani-ucetni";
const STRANKA_AUTOMATU = `${POVOLENY_PUVOD}/sestavy/?auto=odeslat#export`;
const dvoj = (n) => String(n).padStart(2, "0");

chrome.runtime.onMessage.addListener((zprava, odesilatel) => {
  if (odesilatel.origin !== POVOLENY_PUVOD) return;
  if (zprava?.typ === "plan") void ulozitPlan(zprava);
  if (zprava?.typ === "automat-hotovo")
    void dokoncitAutomat(zprava.ok === true, odesilatel.tab?.id);
});
chrome.runtime.onStartup.addListener(() => void nastavitBudik());
chrome.runtime.onInstalled.addListener(() => void nastavitBudik());
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === BUDIK) void zkontrolovatPlan();
});

async function ulozitPlan(z) {
  const plan = {
    zapnuto: z.zapnuto === true,
    cas: /^([01]\d|2[0-3]):[0-5]\d$/.test(z.cas) ? z.cas : "07:00",
  };
  await chrome.storage.local.set({ plan });
  await nastavitBudik();
}

// Budík každých 15 minut přežije restart prohlížeče; po startu se zmeškaný čas dožene.
async function nastavitBudik() {
  const { plan } = await chrome.storage.local.get("plan");
  if (!plan?.zapnuto) return chrome.alarms.clear(BUDIK);
  if (!(await chrome.alarms.get(BUDIK)))
    await chrome.alarms.create(BUDIK, { delayInMinutes: 1, periodInMinutes: 15 });
}

async function zkontrolovatPlan() {
  const { plan, spusteno } = await chrome.storage.local.get(["plan", "spusteno"]);
  if (!plan?.zapnuto) return;
  const ted = new Date();
  const dnes = `${ted.getFullYear()}-${dvoj(ted.getMonth() + 1)}-${dvoj(ted.getDate())}`;
  if (`${dvoj(ted.getHours())}:${dvoj(ted.getMinutes())}` < plan.cas || spusteno === dnes)
    return;
  // Zapíše se před otevřením, aby další budík stránku ten den znovu neotevřel.
  await chrome.storage.local.set({ spusteno: dnes });
  const karta = await chrome.tabs.create({ url: STRANKA_AUTOMATU, active: false });
  await chrome.storage.session.set({ kartaAutomatu: karta.id });
}

async function dokoncitAutomat(ok, idKarty) {
  const { kartaAutomatu } = await chrome.storage.session.get("kartaAutomatu");
  if (!ok || idKarty == null || idKarty !== kartaAutomatu) return;
  await chrome.storage.session.remove("kartaAutomatu");
  await chrome.tabs.remove(idKarty).catch(() => {});
}
