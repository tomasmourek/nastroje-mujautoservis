# Doplněk: načtení z IC Office (prototyp 0.2.2)

Doplněk pro Chrome a Edge, který z otevřené a přihlášené karty IC Office stáhne šest exportů za zvolené období, od jednoho dne po celý měsíc nebo delší rozsah, a předá je Účetním sestavám na `https://nastroje.mujautoservis.eu/sestavy/`. V sestavách se pak na obrazovce Načtení objeví pole Od a Do a tlačítko „Načíst z IC Office“.

## Instalace (ručně, bez obchodu)

ZIP ke stažení je na obrazovce Načtení v sestavách; po rozbalení vznikne složka `ucetni-sestavy-ic-office-<verze>`.

1. Otevřete `chrome://extensions` (v Edge `edge://extensions`).
2. Zapněte Režim pro vývojáře.
3. Klikněte na Načíst rozbalené a vyberte tuto složku (v repozitáři `doplnek`, ze ZIPu rozbalenou složku).
4. Otevřete sestavy. IC Office nemusí být otevřený, stačí, když si prohlížeč pamatuje přihlášení.

## Co dělá

- Použije naposledy použitou kartu IC Office, která do 5 s odpoví na krátký test; zmrazené karty na pozadí a karty s otevřeným dialogem přeskočí. Když žádná vhodná není, otevře IC Office v nové kartě na pozadí a po načtení ji zavře. Když v ní uživatel není přihlášený, kartu nechá otevřenou, přepne se na ni a požádá o přihlášení.
- V kartě IC Office načte stránku Přehledy, zapamatuje si nastavené období, nastaví zvolené období a stáhne exporty `exportInvoicesExcel`, `exportInvoicesItemsExcel`, `exportCashboxExcel`, `exportGoodsImportExcel`, `exportGoodsMinusExcel` a `exportMechanicsItemsContracts`.
- Ověří, že IC Office vrátil soubor za požadované období (datum je v názvu souboru), a nakonec vrátí původní období.
- Soubory předá jen stránce sestav. Nikam jinam je neposílá a nic neukládá; heslo nevidí.
- Stránka sestav smí požádat jen o období (platná data ve tvaru RRRR-MM-DD, začátek nejpozději v den konce). Adresy exportů jsou pevně v `pozadi.js`, žádost odjinud než z `nastroje.mujautoservis.eu` doplněk odmítne a souběžné načítání nepustí.

## Omezení

- Faktury IC Office filtruje podle data vytvoření. Přepínač „Filtr podle datumu DUZP“ na stránce Přehledy nemá v IC Office funkční skript, proto ho doplněk nepoužívá.
- Doplněk závisí na podobě stránky Přehledy v IC Office; když ji Inter Cars změní, je potřeba ho upravit.
- Funguje jen na produkční adrese sestav, ne na místním vývojovém serveru.
