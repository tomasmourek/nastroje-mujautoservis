const api = globalThis.browser ?? globalThis.chrome;
// Stáhne exporty za zvolené období z otevřené a přihlášené karty IC Office a vrátí je stránce sestav.
// Doklady ani heslo neukládá; před zápisem uchová v IC Office pouze ID nepotvrzeného pohybu.
const IC_OFFICE = "https://ic-office.eu";
const POVOLENY_PUVOD = "https://nastroje.mujautoservis.eu";

// Signály tlačítek „Export Excel“ na stránce Přehledy (/overview/). Pořadí odpovídá druhům v sestavách:
// faktury, položky faktur, pokladna, naskladněné zboží, vydané zboží, mechanici.
const EXPORTY = [
  "exportInvoicesExcel",
  "exportInvoicesItemsExcel",
  "exportCashboxExcel",
  "exportGoodsImportExcel",
  "exportGoodsMinusExcel",
  "exportMechanicsItemsContracts",
];

let bezi = false;

// Firefox nemusí vyplnit origin. URL dodává prohlížeč, nikdy samotná zpráva stránky.
// Přijímáme pouze hlavní rámec sestav; případný neprůhledný či cizí origin odmítneme.
function zeSestav(odesilatel) {
  try {
    const url = new URL(odesilatel.url);
    return (
      url.origin === POVOLENY_PUVOD &&
      url.pathname.startsWith("/sestavy/") &&
      odesilatel.frameId === 0 &&
      (odesilatel.origin === undefined || odesilatel.origin === POVOLENY_PUVOD)
    );
  } catch {
    return false;
  }
}

api.runtime.onMessage.addListener((zprava, odesilatel, odpovedet) => {
  if (zprava?.typ !== "nacist") return;
  if (!zeSestav(odesilatel)) {
    odpovedet({
      ok: false,
      chyba: "Žádost nepřišla ze stránky Účetních sestav.",
    });
    return;
  }
  if (!platneObdobi(zprava.od, zprava.do)) {
    odpovedet({ ok: false, chyba: "Neplatné období." });
    return;
  }
  // Druhý souběžný běh by v IC Office přepsal období prvnímu.
  if (bezi) {
    odpovedet({ ok: false, chyba: "Načítání z IC Office už probíhá." });
    return;
  }
  bezi = true;
  nacist(zprava.od, zprava.do, zprava.doplnitDoklady === true && zprava.automaticky !== true)
    .then(odpovedet, (e) => odpovedet({ ok: false, chyba: e.message }))
    .finally(() => {
      bezi = false;
    });
  return true;
});

// Období ve tvaru RRRR-MM-DD, skutečná data a začátek nejpozději v den konce.
function platneObdobi(od, doDne) {
  const datum = (d) =>
    typeof d === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(d) &&
    Number.isFinite(Date.parse(`${d}T00:00:00Z`)) &&
    new Date(`${d}T00:00:00Z`).toISOString().startsWith(d);
  return datum(od) && datum(doDne) && od <= doDne;
}

async function nacist(od, doDne, doplnitDoklady = false) {
  // Uspanou kartu (úspora paměti) ani rozpracovanou nelze skriptovat; zkusí se naposledy použité.
  const karty = (
    await api.tabs.query({ url: `${IC_OFFICE}/*`, discarded: false })
  )
    .filter((k) => k.status === "complete")
    .sort((a, b) => (b.lastAccessed ?? 0) - (a.lastAccessed ?? 0));
  // Zmrazená karta na pozadí nebo karta s otevřeným dialogem skript nespustí a čekalo by se
  // na ni donekonečna, proto se použije jen karta, která odpoví na krátký test.
  let chyba;
  for (const karta of karty) {
    try {
      if (!(await odpovida(karta.id))) continue;
      // Po zahájení zápisového běhu se žádná druhá karta nezkouší ani při ztrátě odpovědi.
      if (doplnitDoklady) return stahnoutVKarte(karta.id, od, doDne, true);
      return await stahnoutVKarte(karta.id, od, doDne, false);
    } catch (e) {
      chyba = e;
    }
  }
  if (chyba) throw nedostalSe(chyba);
  return nacistVNoveKarte(od, doDne, doplnitDoklady);
}

// Ověří, že karta spustí skript do 5 s. Chyba vložení (například chybějící oprávnění) se předá dál.
function odpovida(idKarty) {
  return Promise.race([
    api.scripting
      .executeScript({ target: { tabId: idKarty }, func: () => true })
      .then(([v]) => v?.result === true),
    new Promise((splnit) => setTimeout(() => splnit(false), 5_000)),
  ]);
}

const nedostalSe = (e) =>
  new Error(
    `Doplněk se nedostal do karty IC Office. Obnovte kartu IC Office, zkontrolujte, že má doplněk v prohlížeči povolený přístup k ic-office.eu, a zkuste to znovu. (${e.message})`,
  );

async function stahnoutVKarte(idKarty, od, doDne, doplnitDoklady) {
  const [vysledek] = await api.scripting.executeScript({
    target: { tabId: idKarty },
    func: stahnoutExporty,
    args: [od, doDne, EXPORTY, doplnitDoklady],
  });
  return (
    vysledek?.result ?? { ok: false, chyba: "Karta IC Office neodpověděla." }
  );
}

// Bez otevřené karty otevře IC Office na pozadí. Přihlášení si pamatuje prohlížeč; když chybí,
// karta zůstane otevřená a přepne se na ni, aby se uživatel mohl přihlásit. Jinak se zavře.
async function nacistVNoveKarte(od, doDne, doplnitDoklady) {
  const karta = await api.tabs.create({
    url: `${IC_OFFICE}/overview/`,
    active: false,
  });
  let ponechat = false;
  try {
    await nactena(karta.id);
    const v = await stahnoutVKarte(karta.id, od, doDne, doplnitDoklady).catch((e) => {
      throw nedostalSe(e);
    });
    if (v.prihlasit) {
      ponechat = true;
      await api.tabs.update(karta.id, { active: true });
      return {
        ok: false,
        chyba:
          "Otevřel jsem IC Office v nové kartě, ale nejste v něm přihlášení. Přihlaste se v ní a zkuste to znovu.",
      };
    }
    return v;
  } finally {
    if (!ponechat) await api.tabs.remove(karta.id).catch(() => {});
  }
}

// Počká, až se karta dočte, nejdéle 30 s.
function nactena(idKarty) {
  return new Promise((splnit, selhat) => {
    const konec = () => {
      api.tabs.onUpdated.removeListener(zmena);
      clearTimeout(casovac);
    };
    const zmena = (id, info) => {
      if (id !== idKarty || info.status !== "complete") return;
      konec();
      splnit();
    };
    const casovac = setTimeout(() => {
      konec();
      selhat(new Error("IC Office se nepodařilo otevřít včas."));
    }, 30_000);
    api.tabs.onUpdated.addListener(zmena);
    // Karta se mohla dočíst dřív, než se přihlásil posluchač.
    api.tabs.get(idKarty).then((k) => {
      if (k.status !== "complete") return;
      konec();
      splnit();
    }, selhat);
  });
}

// Běží v kartě IC Office, proto musí být soběstačná. Nastaví zvolené období (RRRR-MM-DD),
// stáhne exporty a vrátí původní období, i když stahování selže.
async function stahnoutExporty(odIso, doIso, exporty, doplnitDoklady = false) {
  const puvod = "https://ic-office.eu";
  const cz = (d) => d.split("-").reverse().join(".");
  const od = cz(odIso);
  const doDne = cz(doIso);
  const text = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  const datum = (s) => {
    const m = /^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s|$)/.exec(s);
    if (!m) throw new Error("Skladový doklad má neplatné datum.");
    const d = `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
    if (!Number.isFinite(Date.parse(`${d}T00:00:00Z`)) || !new Date(`${d}T00:00:00Z`).toISOString().startsWith(d)) throw new Error("Skladový doklad má neplatné datum.");
    return d;
  };
  const vObdobi = (d) => d >= odIso && d <= doIso;
  const dokument = async (url, volby) => {
    const r = await fetch(url, { credentials: "same-origin", ...volby });
    if (!r.ok) throw new Error("IC Office nevrátil stránku skladových dokladů.");
    if (r.url && new URL(r.url, puvod).origin !== puvod) throw new Error("IC Office přesměroval požadavek mimo svůj web.");
    return new DOMParser().parseFromString(await r.text(), "text/html");
  };
  const nastavitObdobi = async (z, k) => {
    const r = await fetch("/overview/", {
      method: "POST", credentials: "same-origin",
      body: new URLSearchParams({ from: z, to: k, settings: "Filtrovat", _do: "settingsForm-submit" }),
    });
    if (!r.ok) throw new Error("Nepodařilo se nastavit nebo obnovit období Přehledů IC Office.");
  };
  const base64 = (bajty) => {
    let s = "";
    for (let i = 0; i < bajty.length; i += 0x8000) {
      // Firefox Xray nepovoluje subarray/slice, protože čtou cizí constructor.
      const cast = [];
      for (let j = i; j < Math.min(i + 0x8000, bajty.length); j++) cast.push(bajty[j]);
      s += String.fromCharCode(...cast);
    }
    return btoa(s);
  };
  const pdfOdkaz = (href, ocekavaneId) => {
    const u = new URL(href, puvod);
    const m = /^\/warehouse\/goods-move-list\/([1-9]\d*)$/.exec(u.pathname);
    if (u.origin !== puvod || u.username || u.password || u.hash || !m || (ocekavaneId && m[1] !== ocekavaneId) || u.searchParams.get("pdf") !== "True" || u.searchParams.get("is_list") !== "True" || [...u.searchParams.keys()].some((k) => !["pdf", "is_list"].includes(k)) || [...u.searchParams].length !== 2) throw new Error("IC Office vrátil neplatný odkaz skladového PDF.");
    return { id: m[1], url: u.href };
  };
  const existujiciPdf = (doc, id) => {
    const odkazy = [...doc.querySelectorAll("a[href]")].filter((a) => /[?&]pdf=/.test(a.getAttribute("href") ?? ""));
    return odkazy.length ? pdfOdkaz(odkazy[0].getAttribute("href"), id) : null;
  };
  // Marker přežije ztrátu odpovědi i reload. Dokud server nepotvrdí správný doklad,
  // nesmí další běh znovu odeslat POST, ani když předchozí zápis na serveru ještě dobíhá.
  const klicCekajiciho = "ucetni-sestavy:nepotvrzeny-skladovy-pohyb:v1";
  const prectiCekajici = () => {
    let id;
    try { id = globalThis.localStorage.getItem(klicCekajiciho); } catch { throw new Error("Úložiště ochrany před opakováním zápisu není dostupné. Žádný nový skladový doklad nebyl vytvořen."); }
    if (id !== null && !/^[1-9]\d{0,19}$/.test(id)) throw new Error("Úložiště ochrany před opakováním zápisu má neplatný stav. Doplnění dokladů je zablokované; zkontrolujte doklady v IC Office.");
    return id;
  };
  const potvrditCekajici = (id) => {
    if (prectiCekajici() !== id) throw new Error("Změnil se stav ochrany před opakováním zápisu. Další zápisy byly zastaveny.");
    try { globalThis.localStorage.removeItem(klicCekajiciho); } catch { throw new Error("Nepodařilo se potvrdit stav uloženého dokladu. Další zápisy byly zastaveny."); }
    if (prectiCekajici() !== null) throw new Error("Nepodařilo se uvolnit ochranu potvrzeného dokladu. Další zápisy byly zastaveny.");
  };
  const overitCekajici = async () => {
    const id = prectiCekajici();
    if (id === null) return;
    const doc = await dokument(`/warehouse/goods-move-list/${id}`);
    if (!existujiciPdf(doc, id)) throw new Error(`Pohyb ${id}: předchozí zápis dosud není potvrzený. Další doklady nevytvářím. Dokončete nebo ověřte tento doklad přímo v IC Office a načtení spusťte znovu.`);
    potvrditCekajici(id);
  };
  const ulozitCekajici = (id) => {
    if (prectiCekajici() !== null) throw new Error("Zůstal nepotvrzený zápis skladového dokladu. Další zápisy byly zastaveny.");
    try { globalThis.localStorage.setItem(klicCekajiciho, id); } catch { throw new Error("Nelze uložit ochranu před opakováním zápisu. Žádný nový skladový doklad nebyl vytvořen."); }
    if (prectiCekajici() !== id) throw new Error("Nelze ověřit ochranu před opakováním zápisu. Žádný nový skladový doklad nebyl vytvořen.");
  };
  const vytvorit = async (id) => {
    await overitCekajici();
    const cesta = `/warehouse/goods-move-list/${id}`;
    const doc = await dokument(cesta);
    if (existujiciPdf(doc, id)) return;
    const form = doc.getElementById("frm-goodsListForm");
    if (!form || (form.getAttribute("method") ?? "").toLowerCase() !== "post" || new URL(form.getAttribute("action"), puvod).href !== `${puvod}/warehouse/goods-move-list`) throw new Error(`Pohyb ${id}: chybí ověřený formulář pro vytvoření dokladu.`);
    const body = new URLSearchParams();
    for (const prvek of form.querySelectorAll("input, select, textarea")) {
      if (!prvek.name || prvek.disabled || ["submit", "button", "reset", "file"].includes(prvek.type) || (["checkbox", "radio"].includes(prvek.type) && !prvek.checked)) continue;
      if (prvek.tagName === "SELECT" && prvek.multiple) {
        for (const o of prvek.options) if (o.selected) body.append(prvek.name, o.value);
      } else body.append(prvek.name, prvek.value);
    }
    if (body.get("id") !== id || !body.get("number")?.trim() || !body.get("date")?.trim() || !body.get("_do")) throw new Error(`Pohyb ${id}: chybí ID, číslo, datum nebo serverový výchozí údaj. Doklad nebyl vytvořen.`);
    if (!vObdobi(datum(body.get("date")))) throw new Error(`Pohyb ${id}: výchozí datum dokladu leží mimo zvolené období. Doklad nebyl vytvořen.`);
    body.set("odeslat", "Vytvořit");
    ulozitCekajici(id);
    let odpoved;
    try { odpoved = await dokument("/warehouse/goods-move-list", { method: "POST", body }); } catch { /* Výsledek zápisu je neurčitý; jedině čerstvé čtení, nikdy druhý POST. */ }
    if (odpoved && text(odpoved.body).includes("Doklad byl vygenerován.") && existujiciPdf(odpoved, id)) {
      potvrditCekajici(id);
      return;
    }
    const overeni = await dokument(cesta);
    if (!existujiciPdf(overeni, id)) throw new Error(`Pohyb ${id}: nelze potvrdit vytvoření dokladu. Další zápisy byly zastaveny; zkontrolujte pohyb v IC Office a import spusťte znovu.`);
    potvrditCekajici(id);
  };
  const doplnit = async () => {
    await overitCekajici();
    let url = `${puvod}/warehouse/goods-move`;
    const navstivene = new Set();
    const strany = new Set();
    const cekajici = new Map();
    let posledniStrana = 1;
    const pohyby = new Map();
    while (url) {
      if (navstivene.has(url) || navstivene.size >= 100) throw new Error("Neúplné nebo cyklické stránkování skladových pohybů.");
      navstivene.add(url);
      strany.add(Number(new URL(url).searchParams.get("page") ?? 1));
      const doc = await dokument(url);
      // Neměníme nezdokumentovaný filtr skladů. Zápisy povolíme jen nad prokazatelně úplným seznamem.
      const form = doc.getElementById("frm-settingsForm");
      const mesice = doc.querySelector('select[id="months"]');
      const radioDatum = doc.querySelector('input[id="date"]');
      const seznam = doc.getElementById("isList");
      const dl = doc.getElementById("isDL");
      const typ = doc.getElementById("moveType");
      const hledani = [...doc.querySelectorAll('input[type="text"], input[type="search"]')].filter((i) => !["from", "to"].includes(i.name));
      if (!form || !mesice || mesice.value !== "0" || !radioDatum || radioDatum.checked || !seznam || seznam.checked || !dl || dl.checked || !typ || typ.value !== "" || hledani.some((i) => i.value.trim())) throw new Error('Pro doplnění dokladů otevřete v IC Office Pohyby zboží, zrušte hledání a filtry, vyberte „Všechny“ a „Všechny pohyby“ a vypněte „S dokladem“ i „Dodací listy“.');
      const tbody = doc.getElementById("snippet--goods_tbody");
      if (!tbody) throw new Error("Chybí seznam skladových pohybů.");
      for (const radek of tbody.querySelectorAll("tr")) {
        const td = [...radek.querySelectorAll("td")];
        if (td.length === 1 && td[0].colSpan > 1) continue;
        if (td.length !== 11) throw new Error("Neznámá struktura skladových pohybů.");
        const d = datum(text(td[1]));
        const a = td[10].querySelector("a.mmcolist");
        const id = a?.getAttribute("data-id");
        if (!/^[1-9]\d*$/.test(id ?? "")) throw new Error("Skladový pohyb nemá platné ID.");
        if (pohyby.has(id)) throw new Error("Stránkování opakuje skladový pohyb; úplnost nelze ověřit.");
        if (!["Vytvořit", "Příjemka", "Výdejka"].includes(text(a))) throw new Error("Neznámý stav dokladu skladového pohybu.");
        pohyby.set(id, { d, chybi: text(a) === "Vytvořit" });
      }
      for (const a of doc.querySelectorAll("a[href]")) {
        const href = a.getAttribute("href");
        if (!href?.includes("paginationGoodsMove")) continue;
        const u = new URL(href, puvod);
        if (u.origin !== puvod || u.username || u.password || u.hash || u.pathname !== "/warehouse/goods-move" || u.searchParams.get("do") !== "paginationGoodsMove" || !/^[1-9]\d*$/.test(u.searchParams.get("page") ?? "") || [...u.searchParams.keys()].some((k) => !["do", "page"].includes(k)) || [...u.searchParams].length !== 2) throw new Error("Neplatný odkaz stránkování skladu.");
        const cislo = Number(u.searchParams.get("page"));
        if (cislo > 100) throw new Error("Příliš mnoho stran skladových pohybů.");
        posledniStrana = Math.max(posledniStrana, cislo);
        // První stránka může být odkazována také jako page=1.
        if (cislo === 1) continue;
        u.search = new URLSearchParams({ do: "paginationGoodsMove", page: String(cislo) });
        if (!strany.has(cislo)) cekajici.set(cislo, u.href);
      }
      const [nasledujici] = [...cekajici].sort((a, b) => a[0] - b[0]);
      if (nasledujici) cekajici.delete(nasledujici[0]);
      url = nasledujici?.[1];
    }
    if (strany.size !== posledniStrana) throw new Error("Stránkování skladových pohybů vynechalo stránku. Žádný doklad nebyl vytvořen.");
    for (const [id, p] of pohyby) if (p.chybi && vObdobi(p.d)) await vytvorit(id);
  };
  const skladoveSoubory = async () => {
    // Přehled je prázdný, dokud IC Office přes toggle-load (ida=5) nevrátí Nette snippet.
    const odpoved = await fetch("/overview/?do=toggleLoad&ida=5", {
      credentials: "same-origin",
      headers: { "X-Requested-With": "XMLHttpRequest", Accept: "application/json" },
    });
    if (!odpoved.ok || (odpoved.url && new URL(odpoved.url, puvod).origin !== puvod)) throw new Error("IC Office nevrátil přehled vystavených výdejek a příjemek.");
    const data = await odpoved.json();
    const html = data?.snippets?.["snippet--privy_prew"];
    if (typeof html !== "string") throw new Error("IC Office nevrátil přehled vystavených výdejek a příjemek.");
    const doc = new DOMParser().parseFromString(html, "text/html");
    const tabulka = doc.getElementById("datatable_information_vypriskl");
    if (!tabulka) throw new Error("IC Office nevrátil přehled vystavených výdejek a příjemek.");
    const radky = [];
    const ids = new Set();
    for (const radek of tabulka.querySelectorAll("tbody tr")) {
      const td = [...radek.querySelectorAll("td")];
      if (td.length === 1 && td[0].colSpan > 1) continue;
      if (td.length !== 13) throw new Error("Neznámá struktura přehledu skladových dokladů.");
      const d = datum(text(td[1]));
      if (!vObdobi(d)) throw new Error("IC Office vrátil skladový doklad za jiné období.");
      const a = [...td[12].querySelectorAll("a[href]")].find((a) => /[?&]pdf=/.test(a.getAttribute("href") ?? ""));
      const pdf = pdfOdkaz(a?.getAttribute("href") ?? "");
      if (ids.has(pdf.id)) throw new Error("Přehled opakuje skladový doklad.");
      ids.add(pdf.id);
      const typ = text(td[11]);
      const cislo = text(td[2]);
      if (!["Příjem", "Výdej"].includes(typ) || !cislo) throw new Error("Skladový doklad nemá číslo nebo známý typ.");
      radky.push({ pdf, d, cislo, typ, hodnoty: [text(td[0]), pdf.id, cislo, d, typ, text(td[3]), text(td[4]), text(td[5]), text(td[6]), text(td[7]), text(td[8]), text(td[9]), text(td[10])] });
      if (radky.length > 1000) throw new Error("Příliš mnoho skladových dokladů; zvolte kratší období.");
    }
    const csvBunka = (s) => /[;"\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    const hlavicka = ["#", "ID pohybu", "Číslo dokladu", "Datum", "Typ", "Klient", "Přidal / Vydal", "Název", "Zakázka", "Faktura", "Objednávka", "Hodnota [bez DPH]", "Hodnota [s DPH]"];
    const csv = "\uFEFF" + [hlavicka, ...radky.map((r) => r.hodnoty)].map((r) => r.map(csvBunka).join(";")).join("\r\n") + "\r\n";
    const soubory = [{ nazev: `Prijemky_vydejky_${odIso}_${doIso}.csv`, data: base64(new TextEncoder().encode(csv)) }];
    let celkem = 0;
    for (const r of radky) {
      const odpoved = await fetch(r.pdf.url, { credentials: "same-origin" });
      if (!odpoved.ok || (odpoved.url && odpoved.url !== r.pdf.url)) throw new Error(`Nelze stáhnout PDF skladového dokladu ${r.pdf.id}.`);
      const delka = Number(odpoved.headers.get("content-length"));
      if (delka > 10 * 1024 * 1024) throw new Error("Skladové PDF překročilo velikost 10 MiB.");
      const bajty = new Uint8Array(await odpoved.arrayBuffer());
      celkem += bajty.length;
      if (bajty.length < 8 || bajty.length > 10 * 1024 * 1024 || celkem > 100 * 1024 * 1024 || [37, 80, 68, 70, 45].some((b, i) => bajty[i] !== b)) throw new Error(`Neplatné nebo příliš velké PDF skladového dokladu ${r.pdf.id}.`);
      soubory.push({ nazev: `Skladovy_doklad_${r.pdf.id}.pdf`, data: base64(bajty) });
    }
    return soubory;
  };
  const spustit = async () => {
    const prehled = await dokument("/overview/");
    if (!prehled.getElementById("frm-settingsForm")) return { ok: false, prihlasit: true, chyba: "IC Office není přihlášený. Přihlaste se v jeho kartě a zkuste to znovu." };
    const puvodniOd = prehled.getElementById("from")?.value;
    const puvodniDo = prehled.getElementById("to")?.value;
    if (!puvodniOd || !puvodniDo) throw new Error("Nelze uložit původní období Přehledů IC Office; import nebyl zahájen.");
    try {
      if (doplnitDoklady) await doplnit();
      await nastavitObdobi(od, doDne);
      const soubory = [];
      for (const signal of exporty) {
        const odpoved = await fetch(`/overview/?do=${signal}`, { credentials: "same-origin" });
        const nazev = /filename="?([^";]+)/.exec(odpoved.headers.get("content-disposition") ?? "")?.[1];
        if (!odpoved.ok || !nazev) throw new Error(`IC Office nevrátil export ${signal}.`);
        if (!nazev.includes(`_${odIso}_${doIso}.`)) throw new Error(`IC Office vrátil export za jiné období: ${nazev}`);
        soubory.push({ nazev, data: base64(new Uint8Array(await odpoved.arrayBuffer())) });
      }
      soubory.push(...await skladoveSoubory());
      return { ok: true, soubory };
    } finally {
      if (puvodniOd && puvodniDo && (puvodniOd !== od || puvodniDo !== doDne)) await nastavitObdobi(puvodniOd, puvodniDo);
    }
  };
  try {
    // Originový zámek koordinuje i více karet/instalací; neukládá data a po běhu se uvolní.
    if (globalThis.navigator?.locks?.request) return await navigator.locks.request("ucetni-sestavy-ic-office-import", { ifAvailable: true }, (zamek) => zamek ? spustit() : { ok: false, chyba: "Načítání z IC Office už probíhá v jiné kartě." });
    if (doplnitDoklady) throw new Error("Prohlížeč neposkytuje zámek pro bezpečné doplnění dokladů. Aktualizujte prohlížeč.");
    return await spustit();
  } catch (e) {
    return { ok: false, chyba: `Spojení s IC Office selhalo: ${e.message}` };
  }
}

// Plán automatického odeslání účetní. Stránka sestav předá čas; doplněk ji po něm jednou denně
// otevře na pozadí. Co a zda odeslat (pracovní den, už odesláno) rozhodne stránka sama a ohlásí
// výsledek: po úspěchu se karta zavře, s chybou zůstane otevřená, aby ji uživatel viděl.
// Bez ověřitelné identity firmy se nesmí spustit ani dříve uložený plán.
const AUTOMAT_POZASTAVEN = true;
const BUDIK = "odeslani-ucetni";
const STRANKA_AUTOMATU = `${POVOLENY_PUVOD}/sestavy/?auto=odeslat#export`;
const dvoj = (n) => String(n).padStart(2, "0");

api.runtime.onMessage.addListener((zprava, odesilatel) => {
  if (!zeSestav(odesilatel)) return;
  if (zprava?.typ === "plan") void ulozitPlan(zprava);
  if (zprava?.typ === "automat-hotovo")
    void dokoncitAutomat(zprava.ok === true, odesilatel.tab?.id);
});
api.runtime.onStartup.addListener(() => void nastavitBudik());
api.runtime.onInstalled.addListener(() => void nastavitBudik());
api.alarms.onAlarm.addListener((a) => {
  if (a.name === BUDIK) void zkontrolovatPlan();
});

async function ulozitPlan(z) {
  const plan = {
    zapnuto: !AUTOMAT_POZASTAVEN && z.zapnuto === true,
    cas: /^([01]\d|2[0-3]):[0-5]\d$/.test(z.cas) ? z.cas : "07:00",
  };
  await api.storage.local.set({ plan });
  await nastavitBudik();
}

// Budík každých 15 minut přežije restart prohlížeče; po startu se zmeškaný čas dožene.
async function nastavitBudik() {
  const { plan } = await api.storage.local.get("plan");
  if (AUTOMAT_POZASTAVEN || !plan?.zapnuto) return api.alarms.clear(BUDIK);
  if (!(await api.alarms.get(BUDIK)))
    await api.alarms.create(BUDIK, { delayInMinutes: 1, periodInMinutes: 15 });
}

async function zkontrolovatPlan() {
  const { plan, spusteno } = await api.storage.local.get(["plan", "spusteno"]);
  if (AUTOMAT_POZASTAVEN || !plan?.zapnuto) return;
  const ted = new Date();
  const dnes = `${ted.getFullYear()}-${dvoj(ted.getMonth() + 1)}-${dvoj(ted.getDate())}`;
  if (`${dvoj(ted.getHours())}:${dvoj(ted.getMinutes())}` < plan.cas || spusteno === dnes)
    return;
  // Zapíše se před otevřením, aby další budík stránku ten den znovu neotevřel.
  await api.storage.local.set({ spusteno: dnes });
  const karta = await api.tabs.create({ url: STRANKA_AUTOMATU, active: false });
  await api.storage.session.set({ kartaAutomatu: karta.id });
}

async function dokoncitAutomat(ok, idKarty) {
  const { kartaAutomatu } = await api.storage.session.get("kartaAutomatu");
  if (!ok || idKarty == null || idKarty !== kartaAutomatu) return;
  await api.storage.session.remove("kartaAutomatu");
  await api.tabs.remove(idKarty).catch(() => {});
}
