// Texty jsou veřejná nápověda. Formuláře vyplňuje uživatel na příslušném webu.
(() => {
  const dis = "https://podpora.mojedane.gov.cz/cs/seznam-okruhu/danova-informacni-schranka-plus/prihlaseni-do-dis/";
  const eet = "https://podpora.mojedane.gov.cz/cs/seznam-okruhu/elektronicka-evidence-trzeb-2-0/";
  const jednotka = eet + "jak-zalozim-evidencni-jednotku-4764";
  const certifikat = eet + "jak-vygeneruji-pokladni-certifikat-4766";
  const icNapoveda = "https://ic-office.eu/help/eet";

  globalThis.ICOP2_EET_KROKY = Object.freeze([
    {
      id: "priprava",
      misto: "Příprava",
      titulek: "Připravte si přístupy",
      pokyn: "Budete potřebovat přístup do daňové schránky firmy, adresu provozovny a účet, který smí měnit nastavení vašeho servisu v IC Office. Nejprve vyřídíte registraci u Finanční správy. Potom přenesete do IC Office soubor s certifikátem a několik údajů.",
      kontrola: "Víte, za kterou firmu a provozovnu registraci vyřizujete. Pro evidenci budete používat IC Office. MOJE eet je samostatná pokladní aplikace státu.",
      pomoc: "Stav k 24. 11. 2026: provozovnu i certifikát lze připravit už teď. Finanční správa uvádí zahájení běžné evidence na 1. 1. 2027.",
      odkaz: "https://eet.gov.cz/cs/o-eet/jaky-je-harmonogram-eet-2-0",
      odkazText: "Harmonogram Finanční správy"
    },
    {
      id: "portal",
      misto: "MOJE daně",
      titulek: "Přihlaste se do Online finančního úřadu",
      pokyn: "Otevřete portál MOJE daně a klikněte na Online finanční úřad. Zvolte způsob, který používáte: Identita občana (například bankovní identita), Datové schránky nebo přístupové údaje přidělené Finanční správou. Přihlášení dokončete na stránce vybrané služby.",
      kontrola: "Po návratu na portál vidíte seznam daňových schránek DIS+. Pokud vidíte znovu úvodní stránku portálu, otevřete Online finanční úřad ještě jednou.",
      pomoc: "Přihlašovací údaje a ověřovací kód patří jen na stránku zvolené přihlašovací služby. Během přihlášení můžete tento návod nechat otevřený.",
      cil: "https://mojedane.gov.cz/",
      odkaz: dis + "jak-se-prihlasim-do-danove-informacni-sc-4580",
      odkazText: "Způsoby přihlášení do DIS+"
    },
    {
      id: "schranka",
      misto: "MOJE daně · DIS+",
      titulek: "Vyberte schránku svého servisu",
      pokyn: "DIS+ je daňová informační schránka. V seznamu klikněte na dlaždici podnikatele nebo společnosti, která provozuje váš servis. Je-li dostupných víc firem, ověřte název a identifikační údaje správné firmy.",
      kontrola: "Na otevřené stránce vidíte firmu nebo podnikatele, za něž chcete evidovat.",
      pomoc: "Pokud podnikáte vlastním jménem a osobní DIS+ otevíráte poprvé, zvolte Aktivovat osobní DIS+ a potvrďte. Pro vstup do svěřené firemní schránky osobní DIS+ aktivovat nemusíte. Chybí-li firma v seznamu, požádejte osobu, která vám uděluje přístup.",
      odkaz: dis + "prvni-prihlaseni-a-aktivace-dis-4588",
      odkazText: "První vstup a aktivace DIS+"
    },
    {
      id: "aktivace",
      misto: "MOJE daně · DIS+",
      titulek: "Aktivujte EET pro vybranou firmu",
      pokyn: "V horní části schránky klikněte na Aktivovat EET. V potvrzovacím okně znovu zkontrolujte firmu a zvolte Aktivovat EET. Po oznámení o úspěchu si přečtěte další pokyny a klikněte na Rozumím.",
      kontrola: "V horní nabídce otevřete Evidence tržeb. Pokud už je evidence aktivní, můžete touto záložkou pokračovat rovnou.",
      pomoc: "Pokud jste aktivaci dříve odložili, najdete ji také v záložce Evidence tržeb. Nevidíte-li nabídku ve svěřené schránce, požádejte o pomoc osobu, která vám udělila pověření.",
      odkaz: eet + "jak-aktivuji-elektronickou-evidenci-trze-4762",
      odkazText: "Aktivace EET včetně obrázků"
    },
    {
      id: "provozovna",
      misto: "DIS+ · Evidence tržeb",
      titulek: "Najděte nebo založte svoji provozovnu",
      pokyn: "V části Správa a nastavení otevřete Správa evidenčních jednotek. Evidenční jednotka je zde místo nebo způsob, kde přijímáte platby. Projděte seznam. Pokud v něm dílnu ještě nemáte, zvolte Nová evidenční jednotka.",
      kontrola: "Máte otevřený formulář nové jednotky, nebo jste našli existující jednotku se správnou adresou či označením.",
      pomoc: "Pokud už provozovna v seznamu je, poznamenejte si její přidělené číslo a pokračujte v návodu až ke kroku „Připravte pokladní certifikát“.",
      odkaz: jednotka,
      odkazText: "Založení evidenční jednotky"
    },
    {
      id: "cinnost",
      misto: "DIS+ · Nová evidenční jednotka",
      titulek: "Popište, kde a za koho přijímáte platby",
      pokyn: "Vyberte druh jednotky. Pro dílnu na stálé adrese se zpravidla hodí Pevná provozovna. Do pole pro převažující činnost začněte psát, co v dílně děláte, a vyberte odpovídající položku. Činnost lze najít i lupou. Pro vlastní přehled můžete dílnu pojmenovat.",
      kontrola: "Podle skutečného provozu jste odpověděli, zda zde přijímáte evidované tržby a zda svým jménem přijímáte peníze na účet jiného poplatníka.",
      pomoc: "Například servis, který zde přijímá evidované platby pouze za vlastní práci, u první otázky vybere Ano a u nepřímého zastoupení Ne. Pokud vybíráte také peníze na cizí účet, ověřte druhou odpověď s účetní.",
      odkaz: jednotka,
      odkazText: "Vysvětlení polí provozovny"
    },
    {
      id: "adresa",
      misto: "DIS+ · Nová evidenční jednotka",
      titulek: "Vyberte adresu dílny",
      pokyn: "U pevné provozovny otevřete Způsob vyplnění adresy a vyberte Zadat adresní údaje ručně. Vyplňte obec, PSČ, ulici a číslo domu. Pro českou adresu klikněte na Vyhledat v registru a u správné adresy na Vybrat.",
      kontrola: "Ve formuláři vidíte adresu místa, kde přijímáte platby. Ta se může lišit od sídla firmy.",
      pomoc: "Při více výsledcích porovnejte obec a číslo domu. U jiného druhu jednotky vyplňte údaj, který si portál vyžádá, například označení vozidla.",
      odkaz: jednotka,
      odkazText: "Jak zadat umístění jednotky"
    },
    {
      id: "cislo-jednotky",
      misto: "DIS+ · Správa evidenčních jednotek",
      titulek: "Uložte jednotku a poznamenejte si její číslo",
      pokyn: "Projděte zadané údaje a klikněte na Dokončit a přidat. V oznámení nebo v seznamu jednotek najděte číslo přidělené vaší provozovně. Zapište si ho pro nastavení IC Office.",
      kontrola: "V seznamu je právě vaše provozovna a znáte číslo, které jí přidělila Finanční správa.",
      pomoc: "Když oznámení zavřete, vraťte se do Správy evidenčních jednotek a otevřete příslušnou položku. Název dílny, IČO a číslo provozovny jsou různé údaje.",
      odkaz: jednotka,
      odkazText: "Přehled uložených jednotek"
    },
    {
      id: "certifikat",
      misto: "DIS+ · Pokladní certifikáty",
      titulek: "Připravte pokladní certifikát",
      pokyn: "Vraťte se do Evidence tržeb. V části Podpora pokladních zařízení vyberte Pokladní certifikáty. Pokud pro tuto pokladnu ještě nemáte použitelný certifikát, klikněte na Vytvořit nový pokladní certifikát. Můžete zadat e-mail pro upozornění a vlastní označení. Potvrďte vytvoření.",
      kontrola: "V přehledu vidíte požadovaný certifikát. Stav Připravuje se znamená, že žádost už byla přijata.",
      pomoc: "Počkejte na nabídku stažení nebo se později vraťte do přehledu. Pokud už máte platný certifikát pro tuto pokladnu, jeho soubor .p12 a heslo, můžete pokračovat rovnou do IC Office.",
      odkaz: certifikat,
      odkazText: "Vydání pokladního certifikátu"
    },
    {
      id: "soubor-heslo",
      misto: "Správa pokladních certifikátů EET",
      titulek: "Uložte soubor .p12 a jeho heslo",
      pokyn: "Zvolte Zobrazit heslo a stáhnout certifikát. Uložte zobrazené heslo, například do správce hesel. V počítači ověřte, že máte stažený soubor s příponou .p12. Teprve pak zaškrtněte potvrzení o bezpečném uložení a klikněte na Dokončit.",
      kontrola: "Certifikát má v seznamu stav Platný. Víte, kde najdete soubor i heslo právě k němu. Heslo budete potřebovat v IC Office.",
      pomoc: "Pokud okno se souborem nevidíte, otevřete v prohlížeči Stažené soubory. Na stránce certifikátu je i odkaz pro ruční stažení. Heslo se při převzetí zobrazuje jen jednou. Soubor ani heslo neposílejte podpoře.",
      odkaz: certifikat,
      odkazText: "Stažení souboru a uložení hesla"
    },
    {
      id: "ic-office",
      misto: "IC Office",
      titulek: "Otevřete nastavení EET v IC Office",
      pokyn: "Přejděte do svého servisu v IC Office. Vpravo nahoře otevřete Nastavení a vyberte EET 2.0. Pokud ještě není zapnuto, zaškrtněte Zapnout elektronickou evidenci tržeb (EET).",
      kontrola: "Vidíte formulář s výběrem certifikátu a údaji pokladny.",
      pomoc: "Pokud položku nastavení nevidíte, obraťte se na správce svého servisu. U již nastavené pokladny nejprve porovnejte provozovnu a označení zařízení s dosavadním nastavením.",
      cil: "https://ic-office.eu/settings/eet",
      odkaz: icNapoveda,
      odkazText: "Nápověda IC Office k EET"
    },
    {
      id: "vybrat-soubor",
      misto: "IC Office · Nastavení EET 2.0",
      titulek: "Vyberte certifikát a vložte jeho heslo",
      pokyn: "V poli Certifikát (*.p12) klikněte na výběr souboru. Otevřete složku, kam jste certifikát stáhli, označte soubor .p12 a potvrďte výběr. Do pole Heslo k certifikátu zadejte heslo získané při jeho stažení.",
      kontrola: "U pole vidíte jméno vybraného souboru. Heslo patří k tomuto konkrétnímu souboru.",
      pomoc: "Vybírejte přímo soubor .p12. Do pole pro heslo nepatří heslo ke vstupu do IC Office nebo k datové schránce. Oba údaje zadávejte výhradně do nastavení vašeho servisu.",
      odkaz: icNapoveda,
      odkazText: "Nápověda k nastavení pokladny"
    },
    {
      id: "oznaceni-pokladny",
      misto: "IC Office · Nastavení EET 2.0",
      titulek: "Vyplňte tři údaje o pokladně",
      pokyn: "Do pole Označení evidenční jednotky přepište číslo přidělené v DIS+. Do Označení pokladního zařízení zadejte vlastní označení této pokladny, například POKLADNA1. Do Počátečního pořadového čísla zadejte začátek vaší číselné řady.",
      kontrola: "Číslo jednotky souhlasí s provozovnou v DIS+. Pokladna má vlastní označení a víte, od kterého čísla má evidovat.",
      pomoc: "U zcela nové řady může být první číslo 1. Při převodu nebo výměně pokladny ověřte se správcem dosavadní označení a návaznost číslování.",
      odkaz: icNapoveda,
      odkazText: "Údaje pro IC Office"
    },
    {
      id: "ulozeni",
      misto: "IC Office · Nastavení EET 2.0",
      titulek: "Uložte nastavení",
      pokyn: "Zkontrolujte firmu, provozovnu, označení pokladny a číselnou řadu. Pak v IC Office klikněte na Uložit EET. Přečtěte zprávu po uložení a zkontrolujte, že zůstala nastavena správná provozovna a pokladna.",
      kontrola: "IC Office přijal nastavení bez ohlášené chyby. První skutečnou platbu ověříte až při běžném provozu.",
      pomoc: "Při chybě souboru nebo hesla znovu vyberte správný soubor a heslo z jeho vydání. Pokud chyba trvá, sdělte specialistovi IC Office text chyby bez hesla a bez přílohy s certifikátem.",
      odkaz: icNapoveda,
      odkazText: "Pomoc s nastavením IC Office"
    },
    {
      id: "prvni-trzba",
      misto: "IC Office · První skutečná tržba",
      titulek: "Až zákazník zaplatí, ověřte přijetí tržby",
      pokyn: "Podle harmonogramu začíná běžná evidence 1. 1. 2027. Od zahájení evidence při první skutečné platbě, která jí podléhá, postupujte v IC Office obvyklým způsobem a ověřte výsledek odeslání. Pro samotné nastavení žádnou cvičnou platbu nevytvářejte.",
      kontrola: "Přijetí tržby potvrzuje Finanční správa potvrzovacím kódem (POK). Uložené nastavení pokladny samo o sobě přijetí konkrétní platby nepotvrzuje.",
      pomoc: "Chybí-li potvrzení, zkontrolujte připojení a stav původní tržby v IC Office. Pro opakované odeslání téže tržby pokračujte s původním dokladem. S postupem v IC Office pomůže váš specialista.",
      odkaz: "https://eet.gov.cz/cs/zacinam-s-eet/evidence-trzeb-v-praxi",
      odkazText: "Jak poznat, že Finanční správa tržbu přijala"
    }
  ]);
})();
