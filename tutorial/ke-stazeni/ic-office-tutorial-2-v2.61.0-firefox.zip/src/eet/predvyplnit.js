// Nabídka pro jedinou kartu IC Office, kterou uživatel otevřel z průvodce.
(() => {
  'use strict';
  function spravnaStranka() {
    const url = new URL(location.href);
    return window === window.top && url.origin === 'https://ic-office.eu' && !url.username && !url.password
      && /^\/settings\/eet\/?$/.test(url.pathname);
  }
  if (!spravnaStranka() || globalThis.ICOP2_EET_PRENOS_PRIPRAVEN) return;
  globalThis.ICOP2_EET_PRENOS_PRIPRAVEN = true;
  const api = globalThis.browser || chrome;
  const zprava = (action, data = {}) => api.runtime.sendMessage({ ns: 'icop2', action, ...data });
  const poleCile = [
    { klic: 'provozovna', id: 'id_company', popis: 'Číslo provozovny' },
    { klic: 'pokladna', id: 'id_device', popis: 'Označení pokladny' }
  ];
  function platny(navrh) {
    return navrh?.ok && typeof navrh.predaniId === 'string' && navrh.predaniId.length > 0
      && Number.isFinite(navrh.vyprsi) && navrh.vyprsi > Date.now()
      && typeof navrh.provozovna === 'string' && /^[0-9]{0,128}$/.test(navrh.provozovna)
      && typeof navrh.pokladna === 'string' && navrh.pokladna === navrh.pokladna.trim()
      && navrh.pokladna.length <= 20 && !/[\u0000-\u001f\u007f-\u009f]/u.test(navrh.pokladna)
      && Boolean(navrh.provozovna || navrh.pokladna);
  }
  function formular() {
    const nalezene = document.querySelectorAll('#frm-eetFormCZ');
    if (nalezene.length === 1 && nalezene[0] instanceof HTMLFormElement) return nalezene[0];
  }
  function jednoPole(form, id, typ) {
    const shody = document.querySelectorAll('#' + id);
    const el = shody[0];
    if (shody.length === 1 && el instanceof HTMLInputElement && el.name === id && el.type === typ
      && el.form === form && form.contains(el) && form.elements.namedItem(id) === el) return el;
  }
  function viditelne(el) {
    if (!el.getClientRects().length || el.closest('[hidden], [inert], [aria-hidden="true"]')) return false;
    for (let predchudce = el; predchudce; predchudce = predchudce.parentElement) {
      const styl = getComputedStyle(predchudce);
      if (styl.display === 'none' || styl.visibility !== 'visible' || Number(styl.opacity) === 0) return false;
    }
    return true;
  }
  function dostupne(form, polozka, hodnota) {
    const el = jednoPole(form, polozka.id, 'text');
    if (!el || el.matches(':disabled') || el.readOnly || el.closest('[aria-disabled="true"]') || !viditelne(el)) return 'nedostupné';
    if (el.value !== '') return 'již vyplněné';
    if (el.maxLength >= 0 && hodnota.length > el.maxLength) return 'údaj je pro pole příliš dlouhý';
    return el;
  }
  function vytvor(tag, text) {
    const el = document.createElement(tag);
    if (text) el.textContent = text;
    return el;
  }
  function tlacitko(text, akce) {
    const el = vytvor('button', text);
    el.type = 'button';
    el.dataset.akce = akce;
    return el;
  }

  const styl = `:host { all: initial !important; display: block !important; margin: 12px 0 !important; color-scheme: light dark !important; }
    section { font: 16px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; color: #202733; background: #fff; border: 1px solid #c5cdd6; border-inline-start: 4px solid #ad1b2b; border-radius: 8px; padding: 14px 18px; max-width: 46em; overflow-wrap: anywhere; }
    h2 { font-size: 1.2em; line-height: 1.25; margin: 0 0 8px; } p { margin: 6px 0; }
    dl { margin: 10px 0; } dt { font-size: .85em; font-weight: 600; } dd { margin: 0 0 4px; }
    button { font: inherit; font-weight: 600; padding: 7px 12px; min-height: 42px; margin: 6px 8px 0 0; border-radius: 6px; border: 1px solid #adb8c3; color: inherit; background: transparent; cursor: pointer; }
    button[data-akce="predvyplnit"] { color: white; background: #ad1b2b; border-color: #ad1b2b; }
    button:focus-visible { outline: 3px solid #367bb3; outline-offset: 2px; } button:disabled { opacity: .65; }
    [role="status"]:empty { display: none; } [role="status"]:not(:empty) { font-weight: 600; }
    @media(prefers-color-scheme: dark) { section { color: #eef2f8; background: #232932; border-color: #687482; border-inline-start-color: #ff8893; } }
  `;
  function pripojStyl(stin) {
    if (typeof CSSStyleSheet === 'function' && 'adoptedStyleSheets' in stin && 'replaceSync' in CSSStyleSheet.prototype) {
      const list = new CSSStyleSheet();
      list.replaceSync(styl);
      stin.adoptedStyleSheets = [list];
    } else stin.append(vytvor('style', styl));
  }

  let generace = 0;
  let ukonci;
  async function nabidni() {
    const beh = ++generace;
    let navrh = await zprava('eetPrevzit');
    if (beh !== generace || !spravnaStranka() || !platny(navrh)) return;
    const { predaniId, vyprsi } = navrh;
    let vybrane = poleCile.filter(polozka => navrh[polozka.klic]);
    const host = vytvor('div');
    host.id = 'icop2-eet-predvyplneni';
    host.lang = 'cs';
    const stin = host.attachShadow({ mode: 'closed' });
    pripojStyl(stin);
    const nabidka = vytvor('section');
    nabidka.setAttribute('aria-label', 'IC Office Tutoriál – předvyplnění');
    const nadpis = vytvor('h2', 'Údaje z průvodce EET');
    const uvod = vytvor('p', 'Zkontrolujte, že jste ve správném servisu. Pokud je formulář zavřený, zaškrtněte v IC Office Zapnout elektronickou evidenci tržeb (EET).');
    const prehled = vytvor('dl');
    for (const polozka of vybrane) prehled.append(vytvor('dt', polozka.popis), vytvor('dd', navrh[polozka.klic]));
    navrh = null;
    const dalsi = vytvor('p', 'U pole Certifikát (ve formátu *.p12) zvolte Vybrat certifikát a sami vyberte svůj stažený soubor. Doplňte heslo k certifikátu, EIČ poplatníka a počáteční pořadové číslo. Údaje zkontrolujte a v IC Office zvolte Uložit EET.');
    const pouzit = tlacitko('Předvyplnit údaje', 'predvyplnit');
    const zrusit = tlacitko('Zrušit', 'zrusit');
    const stav = vytvor('p');
    stav.setAttribute('role', 'status');
    nabidka.append(nadpis, uvod, prehled, vytvor('p', 'Doplněk vloží údaje jen do prázdných polí.'), pouzit, zrusit, stav, dalsi);
    stin.append(nabidka);
    const form = formular();
    if (form) form.before(host);
    else document.body.prepend(host);

    let hotovo = false;
    let bezi = false;
    let cekaNaSmazani;
    const platnyBeh = () => beh === generace && spravnaStranka() && host.isConnected;
    function zavri() {
      if (beh === generace) generace++;
      clearInterval(hlidani);
      clearTimeout(platiDo);
      document.removeEventListener('visibilitychange', overPlatnost);
      prehled.replaceChildren();
      host.remove();
      ukonci = null;
    }
    const vyprselo = 'Návrh už není k dispozici. Vraťte se do návodu a znovu zvolte Pokračovat do IC Office.';
    function overPlatnost() {
      if (!platnyBeh()) zavri();
      else if (!hotovo && Date.now() >= vyprsi) konec(vyprselo, false);
    }
    const hlidani = setInterval(overPlatnost, 1000);
    const platiDo = setTimeout(overPlatnost, Math.max(0, vyprsi - Date.now()));
    document.addEventListener('visibilitychange', overPlatnost);
    ukonci = zavri;
    function konec(text, fokus = true) {
      hotovo = true;
      clearTimeout(platiDo);
      prehled.replaceChildren();
      stav.textContent = text;
      zrusit.textContent = 'Zavřít';
      nabidka.replaceChildren(nadpis, stav, dalsi, zrusit);
      if (fokus) zrusit.focus({ preventScroll: true });
    }
    async function smazNavrh(vysledek, zavrit) {
      if (zrusit.disabled) return;
      cekaNaSmazani = { vysledek, zavrit };
      konec(vysledek, false);
      zrusit.disabled = true;
      try {
        const potvrzeni = await zprava('eetUkoncitPredani', { predaniId });
        if (!potvrzeni?.ok) throw Error();
        if (!platnyBeh()) return;
        cekaNaSmazani = null;
        if (zavrit) zavri();
      } catch {
        if (!platnyBeh()) return;
        stav.textContent = vysledek + ' Dočasné údaje se nepodařilo smazat. Zkuste smazání znovu.';
        zrusit.textContent = 'Zkusit smazat znovu';
      } finally {
        zrusit.disabled = false;
        if (platnyBeh()) zrusit.focus({ preventScroll: true });
      }
    }
    function aktivniFormular() {
      const aktualni = formular();
      const prepinac = aktualni && jednoPole(aktualni, 'enableEET', 'checkbox');
      return prepinac?.checked && !prepinac.matches(':disabled') ? aktualni : null;
    }
    async function pockejNaRozbaleni() {
      // IC Office může zviditelnit pole až po obsluze přepínače nebo animaci.
      for (let pokus = 0; pokus < 10; pokus++) {
        const aktualni = aktivniFormular();
        if (!aktualni || !platnyBeh() || hotovo) return;
        if (vybrane.every(polozka => {
          const el = jednoPole(aktualni, polozka.id, 'text');
          return el && viditelne(el);
        })) return;
        await new Promise(resolve => setTimeout(resolve, 90));
      }
    }
    async function pouzij() {
      if (bezi || hotovo) return;
      bezi = true;
      pouzit.disabled = true;
      try {
        await pockejNaRozbaleni();
        if (!platnyBeh() || hotovo) return;
        const novy = await zprava('eetPrevzit');
        if (!platnyBeh() || hotovo) return;
        if (!platny(novy) || novy.predaniId !== predaniId) {
          konec(vyprselo);
          return;
        }
        const aktualni = aktivniFormular();
        if (!aktualni) {
          stav.textContent = 'V IC Office otevřete nastavení EET 2.0 a zaškrtněte Zapnout elektronickou evidenci tržeb (EET). Po rozbalení formuláře znovu zvolte Předvyplnit údaje.';
          return;
        }
        const vysledky = [];
        const zbyvajici = [];
        for (const polozka of vybrane) {
          const hodnota = novy[polozka.klic];
          const cil = dostupne(aktualni, polozka, hodnota);
          if (cil instanceof HTMLInputElement) {
            cil.value = hodnota;
            vysledky.push(polozka.popis + ' – doplněno.');
          } else {
            vysledky.push(polozka.popis + ' – ' + cil + '.');
            if (cil === 'nedostupné') zbyvajici.push(polozka);
          }
        }
        if (zbyvajici.length) {
          vybrane = zbyvajici;
          stav.textContent = vysledky.join(' ') + ' Až bude pole dostupné, zvolte Předvyplnit údaje znovu. Údaje můžete zadat také přímo v IC Office.';
          return;
        }
        await smazNavrh(vysledky.join(' '), false);
      } catch {
        if (platnyBeh() && !hotovo) stav.textContent = 'Návrh se nepodařilo ověřit. Zkuste to znovu nebo pokračujte ručně.';
      } finally {
        bezi = false;
        pouzit.disabled = false;
      }
    }
    stin.addEventListener('click', (e) => {
      if (!e.isTrusted || !platnyBeh()) { e.preventDefault(); e.stopImmediatePropagation(); return; }
      if (e.target === pouzit) pouzij();
      if (e.target === zrusit) {
        if (cekaNaSmazani) smazNavrh(cekaNaSmazani.vysledek, cekaNaSmazani.zavrit);
        else if (!hotovo) smazNavrh('Předvyplnění bylo zrušeno.', true);
        else zavri();
      }
    });
  }
  const start = () => nabidni().catch(() => {});
  start();
  window.addEventListener('pagehide', () => { generace++; ukonci?.(); });
  window.addEventListener('pageshow', e => { if (e.persisted && spravnaStranka()) start(); });
})();
