/* Jedno zobrazení kroku pro kartu rozšíření i panel nad úřední stránkou. */
(() => {
  'use strict';
  if (globalThis.ICOP2_EET_PRUVODCE) return;
  const klic = 'icop2:eet-krok';
  const kroky = globalThis.ICOP2_EET_KROKY;
  const styl = `.eet-kroky { color-scheme: light dark; --text: #202733; --slaby: #49586a; --lem: #c5cdd6; --tint: #f1f4f7; --accent: #ad1b2b; --hlavni: #ad1b2b; --odkaz: #195a96; --focus: #276eb0; color: var(--text); font: 16px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; overflow-wrap: anywhere; }
@media (prefers-color-scheme: dark) { .eet-kroky { --text: #eef2f8; --slaby: #c0ccd7; --lem: #515e6c; --tint: #303945; --accent: #ff8893; --hlavni: #aa2234; --odkaz: #a2cfff; --focus: #9bcaff; } }
.eet-kroky * { box-sizing: border-box; }
.eet-meta { display: flex; flex-wrap: wrap; gap: 3px 14px; align-items: baseline; font-size: .84em; font-weight: 650; color: var(--slaby); }
.eet-meta span:first-child { color: var(--accent); }
.eet-kroky h2, .eet-kroky h3 { margin: .42em 0 .55em; line-height: 1.16; font-size: 1.7em; letter-spacing: -.018em; color: var(--text); }
.eet-kroky p { margin: 0 0 .8em; white-space: pre-line; }
.eet-kroky a, .eet-kroky summary { color: var(--odkaz); text-underline-offset: .19em; }
.eet-kroky a { display: inline-block; }
.eet-kroky summary { width: fit-content; max-width: 100%; padding-block: 6px; cursor: pointer; font-weight: 600; }
.eet-kroky details p { margin: .5em 0; }
.eet-kontrola { margin: 1em 0 .55em; border-inline-start: 3px solid var(--accent); background: var(--tint); padding: 10px 14px; }
.eet-kontrola strong { font-size: .85em; }
.eet-kontrola p { margin: 3px 0 0; }
.eet-akce { display: flex; align-items: center; flex-wrap: wrap; gap: 8px; margin-top: 1.15em; }
.eet-akce p { flex-basis: 100%; margin: 0; }
.eet-akce button { font: inherit; font-weight: 600; cursor: pointer; border: 1px solid var(--lem); border-radius: 7px; min-height: 42px; padding: 7px 13px; color: var(--text); background: transparent; }
.eet-akce button:hover { background: var(--tint); }
.eet-akce button.eet-hlavni { background: var(--hlavni); border-color: var(--hlavni); color: #fff; }
.eet-akce button.eet-hlavni:hover { background: #891927; border-color: #891927; }
.eet-kroky :focus-visible { outline: 3px solid var(--focus); outline-offset: 2px; }
.eet-kroky .eet-chyba:not(:empty) { margin: .8em 0 0; color: var(--accent); }
.eet-kroky .eet-chyba:empty { display: none; }
.eet-predani { min-width: 0; margin: 1em 0; padding: 12px 14px; border: 1px solid var(--lem); border-radius: 8px; }
.eet-predani legend { padding: 0 4px; font-weight: 700; }
.eet-predani label { display: block; margin: .6em 0; font-weight: 600; }
.eet-predani input { display: block; width: 100%; min-height: 42px; margin-top: .2em; padding: 6px 9px; border: 1px solid var(--lem); border-radius: 5px; color: var(--text); background: var(--tint); font: inherit; }
.eet-predani .eet-akce { margin-top: .7em; }
.eet-predani [role=status]:not(:empty) { margin-top: .65em; }`;

  function vytvor(tag, text, trida) {
    const el = document.createElement(tag);
    if (text) el.textContent = text;
    if (trida) el.className = trida;
    return el;
  }
  function tlacitko(text, akce, trida) {
    const el = vytvor('button', text, trida);
    el.type = 'button';
    el.dataset.akce = akce;
    return el;
  }
  function odkaz(text, adresa) {
    const url = new URL(adresa);
    if (url.protocol !== 'https:' || url.username || url.password) throw new Error('Neplatný odkaz v návodu EET');
    const el = vytvor('a', text);
    el.href = url.href;
    el.target = '_blank';
    el.rel = 'noopener noreferrer';
    return el;
  }
  const stylyKorene = new WeakMap();
  function pridejStyl(koren, css) {
    const pouzite = stylyKorene.get(koren) || new Set();
    if (pouzite.has(css)) return;
    // Constructable stylesheet funguje v Shadow DOM i na stránce s přísnou CSP.
    if (typeof CSSStyleSheet !== 'undefined' && 'adoptedStyleSheets' in koren && 'replaceSync' in CSSStyleSheet.prototype) {
      const list = new CSSStyleSheet();
      list.replaceSync(css);
      koren.adoptedStyleSheets = [...koren.adoptedStyleSheets, list];
    } else {
      const el = vytvor('style', css);
      (koren.head || koren).append(el);
    }
    pouzite.add(css);
    stylyKorene.set(koren, pouzite);
  }
  function nacti() {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(klic, (data) => {
        if (chrome.runtime.lastError) reject(new Error('Čtení postupu selhalo'));
        else resolve(data?.[klic]);
      });
    });
  }
  function uloz(volba, ocekavany, cil) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ ns: 'icop2', action: 'eetPotvrdKrok', volba, ocekavany, cil }, (vysledek) => {
        if (chrome.runtime.lastError || !vysledek?.ok) reject(new Error('Uložení postupu selhalo'));
        else resolve(vysledek);
      });
    });
  }
  function pozice(id) {
    if (id === 'hotovo') return kroky.length;
    return Math.max(0, kroky.findIndex((krok) => krok.id === id));
  }

  function zobraz(obal, { plati = () => true, nadpis = 'h2' } = {}) {
    const koren = obal.getRootNode();
    pridejStyl(koren, styl);
    obal.classList.add('eet-kroky');
    const obsah = vytvor('div');
    const chyba = vytvor('p', '', 'eet-chyba');
    chyba.setAttribute('role', 'alert');
    obal.replaceChildren(obsah, chyba);
    let zavreno = false;
    let ulozeny = 0;
    let pohled = 0;
    let nacteno = false;
    let zapis = false;
    let obnovitZacatek = false;
    let zmeny = 0;
    let odber;
    // Rozepsané údaje jsou jen v této otevřené nápovědě, včetně přechodu mezi sousedními kroky.
    const navrh = { provozovna: '', pokladna: '' };
    let predavaSe = false;

    function nabidkaPredani() {
      const skupina = vytvor('fieldset', '', 'eet-predani');
      skupina.append(vytvor('legend', 'Přenos do IC Office'), vytvor('p', 'Zadejte údaje, které chcete přenést do nastavení vašeho servisu. Pokud je už máte v IC Office, nechte pole prázdná.'));
      const vstupy = {};
      for (const [klicPole, popis, maximum] of [['provozovna', 'Přidělené číslo provozovny', 128], ['pokladna', 'Vlastní označení pokladny', 20]]) {
        const label = vytvor('label', popis);
        const vstup = vytvor('input');
        vstup.id = 'eet-predat-' + klicPole;
        vstup.type = 'text';
        vstup.maxLength = maximum;
        vstup.autocomplete = 'off';
        vstup.spellcheck = false;
        if (klicPole === 'provozovna') vstup.inputMode = 'numeric';
        vstup.value = navrh[klicPole];
        vstup.addEventListener('input', () => { navrh[klicPole] = vstup.value; vstup.setCustomValidity(''); });
        label.append(vstup);
        skupina.append(label);
        vstupy[klicPole] = vstup;
      }
      skupina.append(vytvor('p', 'Můžete vyplnit i jediný údaj. V nové kartě pak zvolíte Předvyplnit údaje. S oběma poli prázdnými se otevře samotné nastavení.'));
      const akce = vytvor('div', '', 'eet-akce');
      const poslat = tlacitko('Pokračovat do IC Office', 'predat', 'eet-hlavni');
      const stav = vytvor('p');
      stav.setAttribute('role', 'status');
      poslat.addEventListener('click', async (e) => {
        if (!e.isTrusted || e.detail > 1 || !plati() || predavaSe) return;
        const provozovna = vstupy.provozovna.value.trim();
        const pokladna = vstupy.pokladna.value.trim();
        vstupy.provozovna.setCustomValidity(provozovna && !/^[0-9]{1,128}$/.test(provozovna) ? 'Zadejte číslo provozovny z DIS+ pouze číslicemi.' : '');
        vstupy.pokladna.setCustomValidity(pokladna.length > 20 || /[\u0000-\u001f\u007f-\u009f]/u.test(pokladna) ? 'Zadejte označení pokladny o nejvýše 20 běžných znacích.' : '');
        if (!vstupy.provozovna.reportValidity() || !vstupy.pokladna.reportValidity()) return;
        predavaSe = true;
        poslat.disabled = true;
        try {
          const odpoved = await (globalThis.browser || chrome).runtime.sendMessage({ ns: 'icop2', action: 'eetPredat', provozovna, pokladna });
          if (!odpoved?.ok) throw new Error();
          if (odpoved.prenosSelhal) {
            stav.textContent = 'IC Office se otevřel. Údaje se nepodařilo předat, vyplňte je přímo ve formuláři.';
            return;
          }
          for (const [jmeno, hodnota] of Object.entries({ provozovna, pokladna })) {
            if (navrh[jmeno].trim() !== hodnota) continue;
            navrh[jmeno] = '';
            const pole = obal.querySelector('#eet-predat-' + jmeno);
            if (pole) pole.value = '';
          }
          stav.textContent = 'IC Office se otevřel v nové kartě. Pokud vás po přihlášení vrátí na úvod, ve stejné kartě otevřete Nastavení a vyberte EET 2.0. K dalším pokynům se můžete vrátit sem.';
        } catch {
          stav.textContent = 'IC Office se nepodařilo otevřít. Zkuste to znovu nebo v IC Office otevřete Nastavení a vyberte EET 2.0.';
        } finally {
          predavaSe = false;
          poslat.disabled = false;
        }
      });
      akce.append(poslat);
      skupina.append(akce, stav);
      return skupina;
    }

    function vykresli(fokus = false) {
      if (zavreno || !plati()) return;
      const hotovo = pohled === kroky.length;
      const krok = kroky[pohled];
      const cast = vytvor('article');
      cast.dataset.krok = hotovo ? 'hotovo' : krok.id;
      const meta = vytvor('div', '', 'eet-meta');
      meta.append(vytvor('span', hotovo ? 'Poslední krok potvrzen' : 'Krok ' + (pohled + 1) + ' z ' + kroky.length));
      if (!hotovo) meta.append(vytvor('span', krok.misto));
      const titulek = vytvor(nadpis, hotovo ? 'Návodem jste prošli' : krok.titulek);
      titulek.tabIndex = -1;
      cast.append(meta, titulek);
      if (hotovo) {
        cast.append(vytvor('p', 'V doplňku jste si označili všechny kroky. Stav certifikátu ověříte v MOJE daně a nastavení pokladny v IC Office.'));
      } else {
        cast.append(vytvor('p', krok.pokyn, 'eet-pokyn'));
        const predani = krok.id === 'soubor-heslo' || krok.id === 'ic-office';
        if (krok.cil && !predani) cast.append(odkaz(krok.cilText || ('Otevřít ' + new URL(krok.cil).hostname + ' v nové kartě'), krok.cil));
        const kontrola = vytvor('div', '', 'eet-kontrola');
        kontrola.append(vytvor('strong', 'Jak poznáte výsledek'), vytvor('p', krok.kontrola));
        cast.append(kontrola);
        if (predani) cast.append(nabidkaPredani());
        if (krok.pomoc || krok.odkaz) {
          const detail = vytvor('details');
          detail.append(vytvor('summary', 'Potřebuji poradit'));
          if (krok.pomoc) detail.append(vytvor('p', krok.pomoc));
          if (krok.odkaz) detail.append(odkaz(krok.odkazText || 'Podrobný návod v nové kartě', krok.odkaz));
          cast.append(detail);
        }
      }
      const akce = vytvor('div', '', 'eet-akce');
      if (pohled > 0) akce.append(tlacitko('Zpět', 'zpet', 'eet-zpet'));
      if (hotovo) {
        if (obnovitZacatek) {
          const znovu = vytvor('p', 'Přejete si smazat označení kroků v návodu a začít od začátku?');
          akce.append(znovu, tlacitko('Ponechat postup', 'ponechat'), tlacitko('Začít znovu', 'potvrdit-znovu', 'eet-hlavni'));
        } else akce.append(tlacitko('Projít znovu', 'znovu'));
      } else if (pohled < ulozeny) {
        akce.append(tlacitko('Další krok', 'dalsi', 'eet-hlavni'));
      } else if (pohled > ulozeny) {
        akce.append(tlacitko('Předchozí kroky už mám hotové', 'navazat', 'eet-hlavni'),
          tlacitko('Zpět k rozpracovanému kroku', 'aktualni'));
      } else {
        akce.append(tlacitko(pohled === kroky.length - 1 ? 'Potvrdit poslední krok' : 'Mám hotovo, pokračovat', 'dalsi', 'eet-hlavni'));
      }
      cast.append(akce);
      obsah.replaceChildren(cast);
      if (fokus) {
        obal.scrollTop = 0;
        titulek.focus({ preventScroll: true });
        if (koren === document) titulek.scrollIntoView({ block: 'nearest' });
      }
    }
    function ukaz(index, fokus = true) {
      if (!nacteno || !Number.isInteger(index) || index < 0 || index > kroky.length) return;
      pohled = index;
      obnovitZacatek = false;
      vykresli(fokus);
    }
    function prijmi(id, fokus = false) {
      ulozeny = pozice(id);
      nacteno = true;
      ukaz(ulozeny, fokus);
    }
    async function potvrd(index, volba) {
      if (zapis || !plati()) return;
      zapis = true;
      const pred = zmeny;
      try {
        const odpoved = await uloz(volba, kroky[ulozeny]?.id || 'hotovo', kroky[index]?.id || 'hotovo');
        if (zavreno || !plati()) return;
        chyba.textContent = odpoved.soubeh ? 'Postup se mezitím změnil v jiné kartě. Pokračujte od zobrazeného kroku.' : '';
        if (pred === zmeny) prijmi(odpoved.krok, true);
        else ukaz(ulozeny, true);
      } catch {
        if (!zavreno) chyba.textContent = 'Postup se nepodařilo uložit. Zkuste krok potvrdit znovu.';
      } finally {
        zapis = false;
      }
    }
    function klik(e) {
      if (!e.isTrusted || !plati()) {
        e.preventDefault();
        e.stopImmediatePropagation();
        return;
      }
      const btn = e.target.closest('button[data-akce]');
      if (!btn || !obsah.contains(btn) || zapis) return;
      switch (btn.dataset.akce) {
        case 'zpet': ukaz(pohled - 1); break;
        case 'aktualni': ukaz(ulozeny); break;
        case 'dalsi': if (pohled < ulozeny) ukaz(pohled + 1); else potvrd(pohled + 1, 'dalsi'); break;
        case 'navazat': potvrd(pohled, 'navazat'); break;
        case 'znovu': obnovitZacatek = true; vykresli(); obsah.querySelector('[data-akce="ponechat"]')?.focus(); break;
        case 'potvrdit-znovu': potvrd(0, 'znovu'); break;
        case 'ponechat': ukaz(ulozeny); break;
      }
    }
    async function priprav() {
      const pred = zmeny;
      try {
        const id = await nacti();
        if (!zavreno && pred === zmeny) prijmi(id);
      } catch {
        if (zavreno) return;
        prijmi();
        chyba.textContent = 'Uložený postup nelze načíst. Zkuste návod znovu otevřít.';
      }
    }
    obal.addEventListener('click', klik, true);
    odber = (zmena, oblast) => {
      if (oblast !== 'local' || !Object.hasOwn(zmena, klic) || zavreno || !plati()) return;
      zmeny++;
      const id = zmena[klic].newValue;
      if (!nacteno || pozice(id) !== ulozeny) prijmi(id);
    };
    chrome.storage.onChanged.addListener(odber);
    priprav();
    return {
      ukaz,
      zrus() {
        zavreno = true;
        chrome.storage.onChanged.removeListener(odber);
        obal.removeEventListener('click', klik, true);
      }
    };
  }

  globalThis.ICOP2_EET_PRUVODCE = Object.freeze({ zobraz, pridejStyl, vytvor, tlacitko });
})();
