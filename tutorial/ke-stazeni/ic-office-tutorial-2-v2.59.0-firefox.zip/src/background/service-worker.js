// IC Office Tutoriál 2 — service worker
//
// Ve výchozím stavu nedělá NIC a neprovádí žádnou síťovou komunikaci.
//
// Jedinou výjimkou je odeslání žádosti o pomoc na hotline, a to jen tehdy,
// když je v src/content/tours.js vyplněný `PODPORA.endpoint`. Dokud je prázdný,
// obsluha níže se nikdy nespustí — content skript místo toho otevře
// předvyplněný e-mail. Odesílání běží tady (ne v content skriptu), aby bylo
// oprávnění k cizí adrese vidět v manifestu.
//
// Až endpoint budete mít, přidejte jeho původ do "host_permissions"
// v manifest.json — jinak fetch skončí chybou a průvodce se vrátí k e-mailu.
chrome.runtime.onInstalled.addListener(() => {
  // nic — veškerá logika běží v content skriptu, data v chrome.storage.local
});

// Stažení obsahu ze serveru (viz FORMAT.md §12). Vypnuté, dokud není v
// `tours.js` vyplněná `obsahUrl` a její původ v "host_permissions".
//
// Stahují se JEN DATA. Vzdálený kód je v Manifestu V3 zakázaný a v Chrome Web
// Store důvod k zamítnutí — formát obsahu je proto deklarativní.
//
// Stažený obsah se ukládá do cache a průvodce ji použije při dalším načtení
// stránky. Bez cache by průvodce nefungoval offline nebo když server mlčí.
const OBSAH_KEY = 'icop2:obsah';
const OBSAH_META = 'icop2:obsahMeta';
const OBSAH_FORMAT = 1;
const OBSAH_INTERVAL = 60 * 60 * 1000;   // nejvýš jednou za hodinu

function obsahPouzitelny(d) {
  return !!(d && typeof d === 'object' && d.format === OBSAH_FORMAT
    && Array.isArray(d.scenarios) && d.scenarios.length);
}

async function stahniObsah(url, vynutit) {
  if (!url) return { ok: false, duvod: 'adresa obsahu není nastavená' };
  const ulozeno = await chrome.storage.local.get([OBSAH_META]);
  const meta = ulozeno[OBSAH_META] || {};
  if (!vynutit && meta.kdy && Date.now() - meta.kdy < OBSAH_INTERVAL) {
    return { ok: true, zmena: false, duvod: 'čerstvé' };
  }
  const hlavicky = {};
  if (meta.etag) hlavicky['If-None-Match'] = meta.etag;
  const r = await fetch(url, { headers: hlavicky, cache: 'no-cache' });
  if (r.status === 304) {
    await chrome.storage.local.set({ [OBSAH_META]: Object.assign({}, meta, { kdy: Date.now() }) });
    return { ok: true, zmena: false, duvod: 'beze změny' };
  }
  if (!r.ok) return { ok: false, duvod: 'server odpověděl ' + r.status };
  const d = await r.json();
  if (!obsahPouzitelny(d)) return { ok: false, duvod: 'stažený obsah neodpovídá formátu ' + OBSAH_FORMAT };
  await chrome.storage.local.set({
    [OBSAH_KEY]: d,
    [OBSAH_META]: { kdy: Date.now(), etag: r.headers.get('ETag') || '', verze: d.version || '' }
  });
  return { ok: true, zmena: true, verze: d.version || '' };
}

// Každá živá prezentace patří jediné kartě. Pozadí zná skutečné ID karty
// i při duplikování stránky, kdy prohlížeč může zkopírovat sessionStorage.
const akcePrezentace = new Set([
  'demoBehStart', 'demoBehOver', 'demoBehSmaz',
  'demoTelefonNastav', 'demoTelefonCti', 'demoTelefonSmaz'
]);
const uuidBehu = /^[\da-f]{8}(?:-[\da-f]{4}){3}-[\da-f]{12}$/i;
const telefonPrezentace = /^\+?[1-9]\d{6,14}$/;
const docasneBehy = new Map();
let poradiBehu = Promise.resolve();

function vPoradiBehu(akce) {
  const vysledek = poradiBehu.then(akce);
  poradiBehu = vysledek.catch(() => {});
  return vysledek;
}

async function ulozBeh(klic, stav) {
  // storage.session je soukromá paměť rozšíření. Starší prostředí může
  // zapomenout běh při uspání pozadí, což automatické úkony bezpečně zastaví.
  const pamet = chrome.storage.session;
  if (stav) {
    if (pamet) await pamet.set({ [klic]: stav });
    else docasneBehy.set(klic, stav);
  } else {
    if (pamet) await pamet.remove(klic);
    else docasneBehy.delete(klic);
  }
}

function klicKarty(tabId) {
  return 'icop2:prezentace:' + tabId;
}

async function obsluzPrezentaci(msg, sender) {
  const tabId = sender.tab?.id;
  if (!Number.isInteger(tabId) || tabId < 0 || sender.frameId !== 0 ||
      !sender.url?.startsWith('https://ic-office.eu/') ||
      typeof msg.beh !== 'string' || !uuidBehu.test(msg.beh)) return { ok: false };

  const klic = klicKarty(tabId);
  const pamet = chrome.storage.session;
  const stav = pamet ? (await pamet.get(klic))[klic] : docasneBehy.get(klic);
  const plati = stav?.beh === msg.beh;
  if (msg.action === 'demoBehStart') {
    if (!plati) await ulozBeh(klic, { beh: msg.beh });
    return { ok: true };
  }
  if (msg.action === 'demoBehOver') return { ok: true, plati };
  if (!plati) return { ok: false, telefon: '' };

  switch (msg.action) {
    case 'demoBehSmaz':
      await ulozBeh(klic, null);
      break;
    case 'demoTelefonNastav':
      if (typeof msg.telefon !== 'string' || !telefonPrezentace.test(msg.telefon)) return { ok: false };
      await ulozBeh(klic, { beh: msg.beh, telefon: msg.telefon });
      break;
    case 'demoTelefonCti':
      return { ok: true, telefon: stav.telefon || '' };
    case 'demoTelefonSmaz':
      await ulozBeh(klic, { beh: msg.beh });
      break;
  }
  return { ok: true };
}

function zapomenKartu(tabId) {
  vPoradiBehu(() => ulozBeh(klicKarty(tabId), null)).catch(() => {});
}
chrome.tabs.onRemoved.addListener(zapomenKartu);
chrome.tabs.onUpdated.addListener((tabId, zmena) => {
  if (zmena.url && !zmena.url.startsWith('https://ic-office.eu/')) zapomenKartu(tabId);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.ns === 'icop2' && akcePrezentace.has(msg.action)) {
    vPoradiBehu(() => obsluzPrezentaci(msg, sender))
      .then(sendResponse, () => sendResponse({ ok: false }));
    return true;
  }
  if (msg && msg.ns === 'icop2' && msg.action === 'obsah') {
    stahniObsah(msg.url, !!msg.vynutit)
      .then((v) => sendResponse(v))
      .catch((e) => sendResponse({ ok: false, duvod: String(e && e.message) }));
    return true;
  }
  if (!msg || msg.ns !== 'icop2' || msg.action !== 'sos') return;
  if (!msg.endpoint) { sendResponse({ ok: false, duvod: 'endpoint není nastaven' }); return true; }
  fetch(msg.endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(msg.payload || {})
  })
    .then((r) => sendResponse({ ok: r.ok, status: r.status }))
    .catch((e) => sendResponse({ ok: false, duvod: String(e && e.message) }));
  return true;   // odpověď přijde asynchronně
});
